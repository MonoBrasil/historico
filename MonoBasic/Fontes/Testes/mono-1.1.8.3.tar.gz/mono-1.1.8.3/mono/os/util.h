#ifndef _MONO_OS_UTIL_H_
#define _MONO_OS_UTIL_H_ 1

void  mono_set_rootdir (void);

#endif
