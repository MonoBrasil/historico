class T {
	public static int Main () {
		int n = 0;
		while (n < 100000000) {
			++n;
		}
		return 0;
	}
}
