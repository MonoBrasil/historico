using System;

public class Test {

	public static int Main () {
		
		Console.WriteLine ("We can now write to the console");

		return 0;
	}
}


