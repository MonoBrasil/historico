#ifndef __MONO_URI_H
#define __MONO_URI_H

gchar * mono_escape_uri_string (const gchar *string);

#endif /* __MONO_URI_H */

