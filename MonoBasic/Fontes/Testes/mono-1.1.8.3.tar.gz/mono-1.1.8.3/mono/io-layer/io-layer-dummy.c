/*
 * io-layer-dummy.c:  Dummy file to fill the library on windows
 *
 * Author:
 *	Dick Porter (dick@ximian.com)
 *
 * (C) 2002 Ximian, Inc.
 */

extern char *_mono_iolayer_dummylib;
char *_mono_iolayer_dummylib="This is a dummy library that isn't needed on Windows";
