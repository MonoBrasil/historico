#ifndef _MONO_THREADPOOL_INTERNALS_H_
#define _MONO_THREADPOOL_INTERNALS_H_

void mono_thread_pool_remove_socket (int sock);
#endif
