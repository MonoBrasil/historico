#include "mini.h"

int
main (int argc, char* argv[])
{
	return mono_main (argc, argv);
}

