REM Target: library

Imports System

Public Class Dll1

Public Shared Sub OutInt(ByRef i As Integer)
    i = 123
End Sub

End Class


