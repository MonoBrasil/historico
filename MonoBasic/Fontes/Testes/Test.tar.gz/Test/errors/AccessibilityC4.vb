REM LineNo: 5
REM ExpectedError: BC31047
REM ErrorMessage: Protected types can only be declared inside of a class.

Protected Class C1
End Class

Module Accessibility
	Sub Main()
	End Sub
End Module

