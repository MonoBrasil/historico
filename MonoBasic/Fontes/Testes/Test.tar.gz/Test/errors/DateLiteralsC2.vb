REM LineNo: 7
REM ExpectedError: BC31085
REM ErrorMessage: Date constant is not valid.

Module DateLiterals
    Sub Main()
        Dim d As Date = # 12/40/2002 #
   End Sub
End Module

	
	
