REM LineNo: 12
REM ExpectedError: BC30081
REM ErrorMessage: 'If' must end with a matching 'End If'.

Imports System

Module ConditionalStatementsC2

    Sub Main()
        Dim i As Integer = 0

  	if true then

    End Sub

End Module
