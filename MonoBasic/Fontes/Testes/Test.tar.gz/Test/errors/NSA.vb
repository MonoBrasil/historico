REM LineNo: 4
REM ExpectedError: BC30420
REM ErrorMessage: 'Sub Main' was not found in 'NSA'.

Namespace nms1
    Public Class NSA
        Public z As Integer = 5
    End Class
End Namespace