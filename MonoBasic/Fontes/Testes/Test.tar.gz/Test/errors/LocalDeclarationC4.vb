REM LineNo: 10
REM ExpectedError: BC30182
REM ErrorMessage: Type expected.

Imports System

Module LocalDeclarationC2

    Sub main()
        Dim a5 As  
    End Sub

End Module