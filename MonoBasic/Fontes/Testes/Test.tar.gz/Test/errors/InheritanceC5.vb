REM LineNo: 5
REM ExpectedError: BC30280
REM ErrorMessage: Enum 'e' must contain at least one member.

public enum e
End enum

Module InheritanceC3
    Sub Main()
    End Sub
End Module
