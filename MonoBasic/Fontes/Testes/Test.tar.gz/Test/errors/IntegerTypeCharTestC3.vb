REM LineNo: 6
REM ExpectedError: BC30468
REM ErrorMessage: Type declaration characters are not valid in this context.

Imports System
Namespace IntegerTypeCharTest%
	Module M
		Sub Main()
		End Sub
	End Module
End Namespace
