REM LineNo: 8
REM ExpectedError: BC30037
REM ErrorMessage: Character is not valid.

Imports System
Namespace IntegerTypeCharTest
	Module M
		Sub [sub]%()
		End Sub
		Sub Main()
		End Sub
	End Module
End Namespace
