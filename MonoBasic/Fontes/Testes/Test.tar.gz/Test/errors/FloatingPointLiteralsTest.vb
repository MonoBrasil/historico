REM LineNo: 4
REM ExpectedError: BC30420
REM ErrorMessage: 'Sub Main' was not found in 'FloatingPointLiteralsTest'.

Module FloatingPointLiteralsTest
    
End Module
