REM LineNo: 4
REM ExpectedError: BC30737
REM ErrorMessage: No accessible 'Main' method with an appropriate signature was found in 'ModuleTestC5'.

Module M1
	Sub Main (argc as string)
	End Sub
End Module
