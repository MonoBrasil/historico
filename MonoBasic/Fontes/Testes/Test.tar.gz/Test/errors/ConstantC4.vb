REM LineNo: 6
REM ExpectedError: BC30302
REM ErrorMessage: Type character '%' cannot be used in a declaration with an explicit type.

Module ConstantC4
    Dim a% As Integer
    Sub main()
    End Sub
End Module
