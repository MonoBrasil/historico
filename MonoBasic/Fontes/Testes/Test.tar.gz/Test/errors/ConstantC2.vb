REM LineNo: 6
REM ExpectedError: BC30059
REM ErrorMessage: Constant expression is required.

Module ConstantC2
    Const a As Integer = New Integer()
    Sub Main()
    End Sub
End Module
