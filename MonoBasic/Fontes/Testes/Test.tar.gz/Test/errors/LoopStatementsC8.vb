REM LineNo: 12
REM ExpectedError: BC30090
REM ErrorMessage: 'End While' must be preceded by a matching 'While'

Imports System

Module LoopStatementsC8

    Sub main()

        Console.WriteLine("Hello World")
        End While

    End Sub

End Module