'Author:
'   V. Sudharsan (vsudharsan@novell.com)
'
' (C) 2005 Novell, Inc.

REM LineNo: 12
REM ExpectedError: BC30182
REM ErrorMessage:  Type expected.

Module M
	Sub Main()
		Const a AS = 10
	End sub
End Module
