REM LineNo: 17
REM ExpectedError: BC30311
REM ErrorMessage: Value of type 'Integer' cannot be converted to 'Date'.

REM LineNo: 17
REM ExpectedError: BC30035
REM ErrorMessage: Syntax error.

REM LineNo: 17
REM ExpectedError: BC30035
REM ErrorMessage: Syntax error.

Module DateLiterals
    Sub Main()
        Dim d As Date
	
	d = 23:05:07
   End Sub
End Module

	
	
