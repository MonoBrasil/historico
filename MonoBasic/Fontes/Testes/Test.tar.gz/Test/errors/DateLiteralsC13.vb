REM LineNo: 7
REM ExpectedError: BC31085
REM ErrorMessage: Date constant is not valid.

Module DateLiterals
    Sub Main()
        Dim d As Date = # 11/31/2002 #
   End Sub
End Module

	
	
