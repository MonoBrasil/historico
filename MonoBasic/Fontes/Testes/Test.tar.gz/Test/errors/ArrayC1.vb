REM LineNo: 8
REM ExpectedError: BC30638
REM ErrorMessage: Array bounds cannot appear in type specifiers.

Imports System

Module M
    Dim a as Long(5)

    Sub Main ()
    End Sub
End Module

