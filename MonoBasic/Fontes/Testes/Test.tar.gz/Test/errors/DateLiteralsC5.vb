REM LineNo: 9
REM ExpectedError: BC31085
REM ErrorMessage: Date constant is not valid.

Module DateLiterals
    Sub Main()
        Dim d As Date
	
	d = # 13:05:07 PM #
   End Sub
End Module

	
	
