REM LineNo: 7
REM ExpectedError: BC30037
REM ErrorMessage: Character is not valid.

Module M
	Sub Main()
		Dim c @
	End Sub
End Module
