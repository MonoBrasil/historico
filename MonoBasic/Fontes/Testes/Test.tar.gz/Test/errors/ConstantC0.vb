REM LineNo: 6
REM ExpectedError: BC30438
REM ErrorMessage: Constants must have a value.

Module ConstantC0
    Const a As Integer
    Sub main()
    End Sub
End Module
