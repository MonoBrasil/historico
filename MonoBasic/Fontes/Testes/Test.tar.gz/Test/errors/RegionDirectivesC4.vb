REM LineNo: 9
REM ExpectedError: BC30217
REM ErrorMessage: String constant expected.



Imports System
Module RegionDirectives
	#Region 
	Sub Main()
		
	End Sub
	#End Region
End Module
