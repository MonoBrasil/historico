REM LineNo: 5
REM ExpectedError: BC31089
REM ErrorMessage: Types declared 'Private' must be inside another type.

Private Class C2
End Class
