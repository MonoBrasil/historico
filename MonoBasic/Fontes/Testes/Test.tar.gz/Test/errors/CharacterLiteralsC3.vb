REM LineNo: 7
REM ExpectedError: BC30205
REM ErrorMessage: End of statement expected.

Module CharacterLiteralsC3
    Sub Main()
        Dim c As Char = ""x"
    End Sub
End Module
