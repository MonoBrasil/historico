REM LineNo: 8
REM ExpectedError: BC30203
REM ErrorMessage: Identifier expected.

Imports System
Module M
	Sub Main()
		Dim a As Integer _ Console.WriteLine(a)
	End Sub
End Module
