REM LineNo: 6
REM ExpectedError: BC30438
REM ErrorMessage: Constants must have a value.

Module ConstantC5
    Const a As Integer
    Sub main()
    End Sub
End Module
