/**********************************************\
* nGallery                                     *
*   SQL Server Data Layer                      *
*   Use this file to upgrade from v1.0 to v1.5 *
\**********************************************/

CREATE TABLE [dbo].[Rating] (
	[PictureID] [int] NOT NULL ,
	[rating1] [int] NOT NULL ,
	[rating2] [int] NOT NULL ,
	[rating3] [int] NOT NULL ,
	[rating4] [int] NOT NULL ,
	[rating5] [int] NOT NULL 
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[Rating] WITH NOCHECK ADD 
	CONSTRAINT [PK_Rating] PRIMARY KEY  CLUSTERED 
	(
		[PictureID]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[Rating] ADD 
	CONSTRAINT [DF_Rating_rating1] DEFAULT (0) FOR [rating1],
	CONSTRAINT [DF_Rating_rating2] DEFAULT (0) FOR [rating2],
	CONSTRAINT [DF_Rating_rating3] DEFAULT (0) FOR [rating3],
	CONSTRAINT [DF_Rating_rating4] DEFAULT (0) FOR [rating4],
	CONSTRAINT [DF_Rating_rating5] DEFAULT (0) FOR [rating5]
GO

ALTER TABLE Picture ADD PictureViewCount INT NOT NULL DEFAULT 0
GO

ALTER TABLE Album ADD ParentAlbumID INT NOT NULL DEFAULT 0
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ngCreateAlbum]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ngCreateAlbum]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ngUpdatePicture]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ngUpdatePicture]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ngGetAlbum]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ngGetAlbum]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ngGetAlbumPictures]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ngGetAlbumPictures]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ngGetAlbums]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ngGetAlbums]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ngGetNextActualAlbumID]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ngGetNextActualAlbumID]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ngGetNextActualPictureID]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ngGetNextActualPictureID]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE dbo.ngCreateAlbum
  @AlbumName varchar(50)=null,
  @AlbumDesc varchar(2500)=null,
  @ParentAlbumID int=0
AS

INSERT INTO Album (AlbumName, AlbumDesc, ParentAlbumID, AlbumCreateDate)
	VALUES (@AlbumName, @AlbumDesc, @ParentAlbumID, getdate())
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[ngCreateAlbum]  TO [public]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE dbo.ngGetAlbum
  @AlbumID int
AS

SELECT AlbumID,
  AlbumName,
  AlbumDesc,
  AlbumCreateDate,
  ParentAlbumID
 FROM Album
 WHERE AlbumID = @AlbumID
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[ngGetAlbum]  TO [public]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE dbo.ngGetAlbumPictures
  @AlbumID int
AS

SELECT
  PictureID,
  PictureTitle,
  PictureCaption,
  PictureFileName,
  PictureHighlight,
  PictureCreateDate,
  PictureViewCount
 FROM Picture
 WHERE PictureAlbumID = @AlbumID
 ORDER BY PictureCreateDate ASC

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[ngGetAlbumPictures]  TO [public]
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

CREATE PROC dbo.ngGetAlbums
AS

SELECT AlbumID,
	AlbumName,
	AlbumDesc,
	AlbumCreateDate,
	ParentAlbumID
FROM Album
ORDER BY AlbumName
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[ngGetAlbums]  TO [public]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE dbo.ngGetNextActualAlbumID
  @AlbumID int
AS

declare @NextID int
declare @AlbumName varchar(50)
set @AlbumName = (SELECT AlbumName FROM Album WHERE AlbumID = @AlbumID)

set @NextID = (SELECT top 1 AlbumID FROM Album WHERE AlbumName > @AlbumName ORDER BY AlbumName ASC)

SELECT isnull(@NextID, 0)
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[ngGetNextActualAlbumID]  TO [public]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE dbo.ngGetNextActualPictureID
  @AlbumID int,
  @PictureID int
AS

declare @NextID int
declare @CreateDate datetime
set @CreateDate = (SELECT PictureCreateDate FROM Picture WHERE PictureID = @PictureID)

set @NextID = (SELECT top 1 PictureID FROM Picture WHERE PictureAlbumID = @AlbumID AND PictureCreateDate > @CreateDate ORDER BY PictureCreateDate ASC)

SELECT isnull(@NextID, 0)
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[ngGetNextActualPictureID]  TO [public]
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS OFF 
GO

ALTER PROCEDURE dbo.ngGetPicture
  @PictureID int
AS

SELECT
  PictureID,
  PictureTitle,
  PictureCaption,
  PictureFileName,
  PictureHighlight,
  PictureCreateDate,
  PictureViewCount
 FROM Picture
 WHERE PictureID = @PictureID

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[ngGetPicture]  TO [public]
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE dbo.ngGetPictureRating
  @PictureID int
AS

declare @COUNT int
set @COUNT = (SELECT count(*) FROM Rating WHERE PictureID = @PictureID)

if @COUNT > 0
begin
	SELECT
		Rating1,
		Rating2,
		Rating3,
		Rating4,
		Rating5
	  FROM Rating
	  WHERE PictureID = @PictureID
end
else
begin
	SELECT 0, 0, 0, 0, 0
end
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[ngGetPictureRating]  TO [public]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE dbo.ngGetPreviousAlbumID
  @AlbumID int
AS

declare @PrevID int
declare @AlbumName varchar(50)
set @AlbumName = (SELECT AlbumName FROM Album WHERE AlbumID = @AlbumID)

set @PrevID = (SELECT top 1 AlbumID FROM Album WHERE AlbumName < @AlbumName ORDER BY AlbumName DESC)

SELECT isnull(@PrevID, 0)
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[ngGetPreviousAlbumID]  TO [public]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE dbo.ngGetPreviousPictureID
  @AlbumID int,
  @PictureID int
AS

declare @PrevID int
declare @CreateDate datetime
set @CreateDate = (SELECT PictureCreateDate FROM Picture WHERE PictureID = @PictureID)

set @PrevID = (SELECT top 1 PictureID FROM Picture WHERE PictureAlbumID = @AlbumID AND PictureCreateDate < @CreateDate ORDER BY PictureCreateDate DESC)

SELECT isnull(@PrevID, 0)
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[ngGetPreviousPictureID]  TO [public]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROC dbo.ngGetSubAlbums
  @ParentAlbumID int=0
AS

SELECT AlbumID,
	AlbumName,
	AlbumDesc,
	AlbumCreateDate,
	ParentAlbumID
FROM Album
WHERE ParentAlbumID = @ParentAlbumID
ORDER BY AlbumName
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[ngGetSubAlbums]  TO [public]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

ALTER PROCEDURE dbo.ngUpdateAlbum
  @AlbumID int,
  @AlbumName varchar(50)=null,
  @AlbumDesc varchar(2500)=null,
  @ParentAlbumID int=0
AS

UPDATE Album SET
  AlbumName = @AlbumName,
  AlbumDesc = @AlbumDesc,
  ParentAlbumID = @ParentAlbumID
 WHERE AlbumID = @AlbumID
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[ngUpdateAlbum]  TO [public]
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE dbo.ngUpdatePictureRating
  @PictureID int,
  @Rating1 int=0,
  @Rating2 int=0,
  @Rating3 int=0,
  @Rating4 int=0,
  @Rating5 int=0
AS

declare @COUNT int
set @COUNT = (SELECT count(*) FROM Rating WHERE PictureID = @PictureID)

if @COUNT = 0
begin
	INSERT INTO Rating (PictureID, Rating1, Rating2, Rating3, Rating4, Rating5)
	  VALUES (@PictureID, @Rating1, @Rating2, @Rating3, @Rating4, @Rating5)
end
else
begin
	UPDATE Rating SET
		Rating1 = @Rating1,
		Rating2 = @Rating2,
		Rating3 = @Rating3,
		Rating4 = @Rating4,
		Rating5 = @Rating5
	  WHERE PictureID = @PictureID
end
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[ngUpdatePictureRating]  TO [public]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE dbo.ngUpdateViewCount
  @AlbumID int,
  @PictureID int
AS

UPDATE Picture SET PictureViewCount = PictureViewCount + 1 WHERE PictureAlbumID = @AlbumID AND PictureID = @PictureID

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[ngUpdateViewCount]  TO [public]
GO

CREATE PROCEDURE dbo.ngUpdatePicture
  @PictureID int,
  @Title varchar(50)=null,
  @Caption varchar(2500)=null,
  @Highlight bit=0,
  @AlbumID int
AS

UPDATE Picture SET
  PictureTitle = @Title,
  PictureCaption = @Caption,
  PictureHighlight = @Highlight
 WHERE PictureID = @PictureID
  AND PictureAlbumID = @AlbumID
GO
