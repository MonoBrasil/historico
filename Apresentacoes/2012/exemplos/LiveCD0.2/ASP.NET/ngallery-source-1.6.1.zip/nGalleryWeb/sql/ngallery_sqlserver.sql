/**********************************************\
* nGallery                                     *
*   SQL Server Data Layer                      *
*   Use this file for a fresh install          *
\**********************************************/

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_Comment_Album]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[Comment] DROP CONSTRAINT FK_Comment_Album
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_Invitations_Album]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[Invitation] DROP CONSTRAINT FK_Invitations_Album
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK__Picture__Picture__79A81403]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[Picture] DROP CONSTRAINT FK__Picture__Picture__79A81403
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_Invitation_Contacts_Contact]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[Invitation_Contacts] DROP CONSTRAINT FK_Invitation_Contacts_Contact
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_Invitation_Contacts_Invitation]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[Invitation_Contacts] DROP CONSTRAINT FK_Invitation_Contacts_Invitation
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ngCreateAlbum]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ngCreateAlbum]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ngCreateComment]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ngCreateComment]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ngCreateContact]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ngCreateContact]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ngCreateInvitation]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ngCreateInvitation]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ngCreateInvitationContact]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ngCreateInvitationContact]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ngCreatePicture]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ngCreatePicture]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ngDeleteAlbum]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ngDeleteAlbum]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ngDeleteComment]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ngDeleteComment]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ngDeleteContact]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ngDeleteContact]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ngDeleteInvitation]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ngDeleteInvitation]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ngDeletePicture]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ngDeletePicture]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ngGetAlbum]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ngGetAlbum]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ngGetAlbumIDByName]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ngGetAlbumIDByName]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ngGetAlbumPictures]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ngGetAlbumPictures]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ngGetAlbums]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ngGetAlbums]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ngGetComment]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ngGetComment]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ngGetContact]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ngGetContact]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ngGetContactByGuid]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ngGetContactByGuid]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ngGetContacts]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ngGetContacts]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ngGetInvitationByGuid]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ngGetInvitationByGuid]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ngGetInvitationRecipients]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ngGetInvitationRecipients]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ngGetInvitations]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ngGetInvitations]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ngGetNextActualAlbumID]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ngGetNextActualAlbumID]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ngGetNextActualPictureID]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ngGetNextActualPictureID]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ngGetNextAlbumID]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ngGetNextAlbumID]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ngGetNextCommentID]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ngGetNextCommentID]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ngGetNextContactID]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ngGetNextContactID]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ngGetNextInvitationID]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ngGetNextInvitationID]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ngGetNextPictureID]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ngGetNextPictureID]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ngGetPicture]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ngGetPicture]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ngGetPictureComments]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ngGetPictureComments]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ngGetPictureRating]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ngGetPictureRating]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ngGetPreviousAlbumID]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ngGetPreviousAlbumID]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ngGetPreviousPictureID]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ngGetPreviousPictureID]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ngGetSubAlbums]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ngGetSubAlbums]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ngMarkInvitationRead]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ngMarkInvitationRead]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ngSetHighlightedPicture]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ngSetHighlightedPicture]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ngUpdateAlbum]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ngUpdateAlbum]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ngUpdateComment]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ngUpdateComment]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ngUpdateContact]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ngUpdateContact]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ngUpdatePicture]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ngUpdatePicture]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ngUpdatePictureRating]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ngUpdatePictureRating]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ngUpdateViewCount]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ngUpdateViewCount]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Album]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[Album]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Comment]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[Comment]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Contact]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[Contact]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Invitation]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[Invitation]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Invitation_Contacts]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[Invitation_Contacts]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Picture]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[Picture]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Rating]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[Rating]
GO

CREATE TABLE [dbo].[Album] (
	[AlbumID] [int] IDENTITY (1, 1) NOT NULL ,
	[AlbumName] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[AlbumDesc] [varchar] (2500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[AlbumCreateDate] [datetime] NULL ,
	[ParentAlbumID] [int] NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[Comment] (
	[CommentID] [int] IDENTITY (1, 1) NOT NULL ,
	[CommentFromName] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[CommentFromEmailAddr] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[CommentFromWebURL] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[CommentText] [varchar] (1000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[CommentDateSubmitted] [datetime] NULL ,
	[CommentAlbumID] [int] NOT NULL ,
	[CommentPictureID] [int] NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[Contact] (
	[ContactID] [int] IDENTITY (1, 1) NOT NULL ,
	[FirstName] [varchar] (25) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[MiddleName] [varchar] (25) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[LastName] [varchar] (25) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[NickName] [varchar] (25) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[EmailAddress] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[HomePhone] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[WorkPhone] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[MobilePhone] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Address1] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Address2] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[City] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[State] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Zip] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[WebsiteURL] [varchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[Invitation] (
	[InvitationID] [int] IDENTITY (1, 1) NOT NULL ,
	[AlbumID] [int] NOT NULL ,
	[Message] [text] COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[CreateDate] [datetime] NOT NULL 
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

CREATE TABLE [dbo].[Invitation_Contacts] (
	[InvitationID] [int] NOT NULL ,
	[ContactID] [int] NOT NULL ,
	[Guid] [varchar] (40) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[IsRead] [bit] NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[Picture] (
	[PictureID] [int] IDENTITY (1, 1) NOT NULL ,
	[PictureTitle] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[PictureCaption] [varchar] (2500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[PictureCreateDate] [datetime] NULL ,
	[PictureFileName] [varchar] (1000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[PictureHighlight] [bit] NULL ,
	[PictureAlbumID] [int] NOT NULL ,
	[PictureViewCount] [int] NOT NULL ,
	[PictureHeight] [int] NULL ,
	[PictureWidth] [int] NULL
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[Rating] (
	[PictureID] [int] NOT NULL ,
	[rating1] [int] NOT NULL ,
	[rating2] [int] NOT NULL ,
	[rating3] [int] NOT NULL ,
	[rating4] [int] NOT NULL ,
	[rating5] [int] NOT NULL 
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[Comment] WITH NOCHECK ADD 
	CONSTRAINT [PK_Comment] PRIMARY KEY  CLUSTERED 
	(
		[CommentAlbumID],
		[CommentPictureID],
		[CommentID]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[Contact] WITH NOCHECK ADD 
	CONSTRAINT [PK_Contact] PRIMARY KEY  CLUSTERED 
	(
		[ContactID]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[Invitation] WITH NOCHECK ADD 
	CONSTRAINT [PK_Invitations] PRIMARY KEY  CLUSTERED 
	(
		[InvitationID]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[Invitation_Contacts] WITH NOCHECK ADD 
	CONSTRAINT [PK_Invitation_Contacts] PRIMARY KEY  CLUSTERED 
	(
		[InvitationID],
		[ContactID]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[Rating] WITH NOCHECK ADD 
	CONSTRAINT [PK_Rating] PRIMARY KEY  CLUSTERED 
	(
		[PictureID]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[Album] ADD 
	CONSTRAINT [DF__Album__ParentAlb__173876EA] DEFAULT (0) FOR [ParentAlbumID],
	CONSTRAINT [PK__Album__76CBA758] PRIMARY KEY  NONCLUSTERED 
	(
		[AlbumID]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[Picture] ADD 
	CONSTRAINT [DF__Picture__Picture__164452B1] DEFAULT (0) FOR [PictureViewCount],
	CONSTRAINT [PK__Picture__78B3EFCA] PRIMARY KEY  NONCLUSTERED 
	(
		[PictureAlbumID],
		[PictureID]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[Rating] ADD 
	CONSTRAINT [DF_Rating_rating1] DEFAULT (0) FOR [rating1],
	CONSTRAINT [DF_Rating_rating2] DEFAULT (0) FOR [rating2],
	CONSTRAINT [DF_Rating_rating3] DEFAULT (0) FOR [rating3],
	CONSTRAINT [DF_Rating_rating4] DEFAULT (0) FOR [rating4],
	CONSTRAINT [DF_Rating_rating5] DEFAULT (0) FOR [rating5]
GO

ALTER TABLE [dbo].[Comment] ADD 
	CONSTRAINT [FK_Comment_Album] FOREIGN KEY 
	(
		[CommentAlbumID]
	) REFERENCES [dbo].[Album] (
		[AlbumID]
	)
GO

ALTER TABLE [dbo].[Invitation] ADD 
	CONSTRAINT [FK_Invitations_Album] FOREIGN KEY 
	(
		[AlbumID]
	) REFERENCES [dbo].[Album] (
		[AlbumID]
	)
GO

ALTER TABLE [dbo].[Invitation_Contacts] ADD 
	CONSTRAINT [FK_Invitation_Contacts_Contact] FOREIGN KEY 
	(
		[ContactID]
	) REFERENCES [dbo].[Contact] (
		[ContactID]
	),
	CONSTRAINT [FK_Invitation_Contacts_Invitation] FOREIGN KEY 
	(
		[InvitationID]
	) REFERENCES [dbo].[Invitation] (
		[InvitationID]
	)
GO

ALTER TABLE [dbo].[Picture] ADD 
	CONSTRAINT [FK__Picture__Picture__79A81403] FOREIGN KEY 
	(
		[PictureAlbumID]
	) REFERENCES [dbo].[Album] (
		[AlbumID]
	)
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO



CREATE PROCEDURE dbo.ngCreateAlbum
  @AlbumName varchar(50)=null,
  @AlbumDesc varchar(2500)=null,
  @ParentAlbumID int=0
AS

INSERT INTO Album (AlbumName, AlbumDesc, ParentAlbumID, AlbumCreateDate)
	VALUES (@AlbumName, @AlbumDesc, @ParentAlbumID, getdate())


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[ngCreateAlbum]  TO [public]
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS OFF 
GO



/****** Object:  Stored Procedure dbo.ngCreateComment    Script Date: 8/26/2003 12:44:49 PM ******/
CREATE PROCEDURE dbo.ngCreateComment
  @AlbumID int,
  @PictureID int,
  @FromName varchar(50)=null,
  @FromEmailAddr varchar(50)=null,
  @FromWebURL varchar(50)=null,
  @Text varchar(1000)=null
AS

INSERT INTO Comment (CommentAlbumID, CommentPictureID, CommentFromName,
	 CommentFromEmailAddr, CommentFromWebURL, CommentText, CommentDateSubmitted)
  VALUES (@AlbumID, @PictureID, @FromName, @FromEmailAddr, @FromWebURL, @Text, getdate())


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[ngCreateComment]  TO [public]
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE dbo.ngCreateContact
	@FirstName varchar(25),
	@MiddleName varchar(25),
	@LastName varchar(25),
	@NickName varchar(25),
	@EmailAddress varchar(50),
	@HomePhone varchar(20),
	@WorkPhone varchar(20),
	@MobilePhone varchar(20),
	@Address1 varchar(50),
	@Address2 varchar(50),
	@City varchar(50),
	@State varchar(50),
	@Zip varchar(10),
	@WebsiteURL varchar(100)
AS

INSERT INTO Contact (FirstName, MiddleName, LastName, NickName, EmailAddress, HomePhone, WorkPhone, MobilePhone, Address1, Address2, City, State, Zip, WebsiteURL)
	VALUES (@FirstName, @MiddleName, @LastName, @NickName, @EmailAddress, @HomePhone, @WorkPhone, @MobilePhone, @Address1, @Address2, @City, @State, @Zip, @WebsiteURL)
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[ngCreateContact]  TO [public]
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE dbo.ngCreateInvitation
	@AlbumID int,
	@Message text,
	@CreateDate datetime
AS

INSERT INTO Invitation (AlbumID, Message, CreateDate) VALUES (@AlbumID, @Message, @CreateDate)
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[ngCreateInvitation]  TO [public]
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE dbo.ngCreateInvitationContact
	@InvitationID int,
	@ContactID int,
	@GUID varchar(40)
AS

INSERT INTO Invitation_Contacts (InvitationID, ContactID, GUID, IsRead) VALUES (@InvitationID, @ContactID, @GUID, 0)
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[ngCreateInvitationContact]  TO [public]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO



/****** Object:  Stored Procedure dbo.ngCreatePicture    Script Date: 8/26/2003 12:44:50 PM ******/

CREATE PROCEDURE dbo.ngCreatePicture
  @Title varchar(50)=null,
  @Caption varchar(2500)=null,
  @FileName varchar(1000)=null,
  @Highlight bit=0,
  @AlbumID int,
  @Width int = 0,
  @Height int = 0
AS

INSERT INTO Picture (PictureTitle, PictureCaption, PictureFileName, PictureHighlight, PictureAlbumID, PictureCreateDate, PictureWidth, PictureHeight)
	VALUES (@Title, @Caption, @FileName, @Highlight, @AlbumID, getdate(), @Width, @Height)


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[ngCreatePicture]  TO [public]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO



/****** Object:  Stored Procedure dbo.ngDeleteAlbum    Script Date: 8/26/2003 12:44:50 PM ******/

CREATE PROCEDURE dbo.ngDeleteAlbum
  @AlbumID int
AS

DELETE FROM Album WHERE AlbumID = @AlbumID



GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[ngDeleteAlbum]  TO [public]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO



/****** Object:  Stored Procedure dbo.ngDeleteComment    Script Date: 8/26/2003 12:44:50 PM ******/
CREATE PROCEDURE dbo.ngDeleteComment
  @AlbumID int,
  @PictureID int,
  @CommentID int
AS

DELETE FROM Comment WHERE CommentAlbumID = @AlbumID AND CommentPictureID = @PictureID AND CommentID = @CommentID


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[ngDeleteComment]  TO [public]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE dbo.ngDeleteContact
	@ContactID int
AS

DELETE FROM Contact WHERE ContactID = @ContactID
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[ngDeleteContact]  TO [public]
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE dbo.ngDeleteInvitation
	@InvitationID int
AS

DELETE FROM Invitation_Contacts WHERE InvitationID = @InvitationID

DELETE FROM Invitation WHERE InvitationID = @InvitationID
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[ngDeleteInvitation]  TO [public]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO



/****** Object:  Stored Procedure dbo.ngDeletePicture    Script Date: 8/26/2003 12:44:50 PM ******/

CREATE PROCEDURE dbo.ngDeletePicture
  @AlbumID int,
  @PictureID int
AS

DELETE FROM Picture WHERE PictureAlbumID = @AlbumID AND PictureID = @PictureID



GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[ngDeletePicture]  TO [public]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO



CREATE PROCEDURE dbo.ngGetAlbum
  @AlbumID int
AS

SELECT AlbumID,
  AlbumName,
  AlbumDesc,
  AlbumCreateDate,
  ParentAlbumID
 FROM Album
 WHERE AlbumID = @AlbumID


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[ngGetAlbum]  TO [public]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


CREATE PROCEDURE [dbo].[ngGetAlbumIDByName]
  @AlbumName varchar(100)
AS

SELECT AlbumID FROM Album WHERE AlbumName = @AlbumName

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[ngGetAlbumIDByName]  TO [public]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO



CREATE PROCEDURE dbo.ngGetAlbumPictures
  @AlbumID int
AS

SELECT
  PictureID,
  PictureTitle,
  PictureCaption,
  PictureFileName,
  PictureHighlight,
  PictureCreateDate,
  PictureViewCount
 FROM Picture
 WHERE PictureAlbumID = @AlbumID
 ORDER BY PictureCreateDate ASC



GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[ngGetAlbumPictures]  TO [public]
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO



CREATE PROC dbo.ngGetAlbums
AS

SELECT AlbumID,
	AlbumName,
	AlbumDesc,
	AlbumCreateDate,
	ParentAlbumID
FROM Album
ORDER BY AlbumName


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[ngGetAlbums]  TO [public]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO



/****** Object:  Stored Procedure dbo.ngGetComment    Script Date: 8/26/2003 12:44:50 PM ******/
CREATE PROCEDURE dbo.ngGetComment
  @AlbumID int,
  @PictureID int,
  @CommentID int
AS

SELECT
	CommentID,
	CommentFromName,
	CommentFromEmailAddr,
	CommentFromWebURL,
	CommentText,
	CommentDateSubmitted
 FROM Comment
 WHERE CommentAlbumID = @AlbumID AND CommentPictureID = @PictureID AND CommentID = @CommentID


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[ngGetComment]  TO [public]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE dbo.ngGetContact
	@ContactID int
AS

SELECT ContactID, FirstName, MiddleName, LastName, NickName, EmailAddress, HomePhone, WorkPhone, MobilePhone,
	Address1, Address2, City, State, Zip, WebsiteURL
FROM Contact
WHERE ContactID = @ContactID
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[ngGetContact]  TO [public]
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE dbo.ngGetContactByGuid
	@GUID varchar(40)
AS

SELECT Contact.ContactID, FirstName, MiddleName, LastName, NickName, EmailAddress, HomePhone, WorkPhone, MobilePhone,
	Address1, Address2, City, State, Zip, WebsiteURL
FROM Contact
RIGHT JOIN Invitation_Contacts ON Invitation_Contacts.ContactID = Contact.ContactID
WHERE GUID = @GUID
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[ngGetContactByGuid]  TO [public]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE dbo.ngGetContacts AS

SELECT ContactID, FirstName, MiddleName, LastName, NickName, EmailAddress, HomePhone, WorkPhone, MobilePhone,
	Address1, Address2, City, State, Zip, WebsiteURL
FROM Contact
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[ngGetContacts]  TO [public]
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE dbo.ngGetInvitationByGuid
	@GUID varchar(40)
AS

SELECT Invitation.InvitationID, AlbumID, Message, CreateDate
FROM Invitation
RIGHT JOIN Invitation_Contacts ON Invitation_Contacts.InvitationID = Invitation.InvitationID
WHERE GUID = @GUID
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[ngGetInvitationByGuid]  TO [public]
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE dbo.ngGetInvitationRecipients
	@InvitationID int
AS

SELECT ContactID, GUID, IsRead FROM Invitation_Contacts WHERE InvitationID = @InvitationID
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[ngGetInvitationRecipients]  TO [public]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE dbo.ngGetInvitations AS

SELECT InvitationID, AlbumID, Message, CreateDate FROM Invitation
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[ngGetInvitations]  TO [public]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO



CREATE PROCEDURE dbo.ngGetNextActualAlbumID
  @AlbumID int
AS

declare @NextID int
declare @AlbumName varchar(50)
set @AlbumName = (SELECT AlbumName FROM Album WHERE AlbumID = @AlbumID)

set @NextID = (SELECT top 1 AlbumID FROM Album WHERE AlbumName > @AlbumName ORDER BY AlbumName ASC)

SELECT isnull(@NextID, 0)


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[ngGetNextActualAlbumID]  TO [public]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO



CREATE PROCEDURE dbo.ngGetNextActualPictureID
  @AlbumID int,
  @PictureID int
AS

declare @NextID int
set @NextID = (SELECT top 1 PictureID FROM Picture WHERE PictureAlbumID = @AlbumID AND PictureID > @PictureID ORDER BY PictureID ASC)

SELECT isnull(@NextID, 0)


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[ngGetNextActualPictureID]  TO [public]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO



/****** Object:  Stored Procedure dbo.ngGetNextAlbumID    Script Date: 8/26/2003 12:44:50 PM ******/

CREATE PROCEDURE dbo.ngGetNextAlbumID
AS

DECLARE @ID int
SET @ID = (SELECT ident_current('Album') + ident_seed('Album'))

if @ID = 2
begin
	DECLARE @Count int
	SET @Count = (SELECT count(AlbumID) FROM Album)
	if @Count = 0
	begin
		SET @ID = (SELECT @ID - ident_seed('Album'))
		SELECT @ID
	end
	else
	begin
		SELECT @ID
	end
end
else
begin
	SELECT @ID
end
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[ngGetNextAlbumID]  TO [public]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO



/****** Object:  Stored Procedure dbo.ngGetNextCommentID    Script Date: 8/26/2003 12:44:50 PM ******/
CREATE PROCEDURE dbo.ngGetNextCommentID
AS

DECLARE @ID int
SET @ID = (SELECT ident_current('Comment') + ident_seed('Comment'))

if @ID = 2
begin
	DECLARE @Count int
	SET @Count = (SELECT count(CommentID) FROM Comment)
	if @Count = 0
	begin
		SET @ID = (SELECT @ID - ident_seed('Comment'))
		SELECT @ID
	end
	else
	begin
		SELECT @ID
	end
end
else
begin
	SELECT @ID
end
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[ngGetNextCommentID]  TO [public]
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE dbo.ngGetNextContactID AS

DECLARE @ID int
SET @ID = (SELECT ident_current('Contact') + ident_seed('Contact'))

if @ID = 2
begin
	DECLARE @Count int
	SET @Count = (SELECT count(ContactID) FROM Contact)
	if @Count = 0
	begin
		SET @ID = (SELECT @ID - ident_seed('Contact'))
		SELECT @ID
	end
	else
	begin
		SELECT @ID
	end
end
else
begin
	SELECT @ID
end
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[ngGetNextContactID]  TO [public]
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE dbo.ngGetNextInvitationID AS

DECLARE @ID int
SET @ID = (SELECT ident_current('Invitation') + ident_seed('Invitation'))

if @ID = 2
begin
	DECLARE @Count int
	SET @Count = (SELECT count(InvitationID) FROM Invitation)
	if @Count = 0
	begin
		SET @ID = (SELECT @ID - ident_seed('Invitation'))
		SELECT @ID
	end
	else
	begin
		SELECT @ID
	end
end
else
begin
	SELECT @ID
end
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[ngGetNextInvitationID]  TO [public]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO



/****** Object:  Stored Procedure dbo.ngGetNextPictureID    Script Date: 8/26/2003 12:44:50 PM ******/

CREATE PROCEDURE dbo.ngGetNextPictureID
AS

DECLARE @ID int
SET @ID = (SELECT ident_current('Picture') + ident_seed('Picture'))

if @ID = 2
begin
	DECLARE @Count int
	SET @Count = (SELECT count(PictureID) FROM Picture)
	if @Count = 0
	begin
		SET @ID = (SELECT @ID - ident_seed('Picture'))
		SELECT @ID
	end
	else
	begin
		SELECT @ID
	end
end
else
begin
	SELECT @ID
end
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[ngGetNextPictureID]  TO [public]
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS OFF 
GO



CREATE PROCEDURE dbo.ngGetPicture
  @PictureID int
AS

SELECT
  PictureID,
  PictureTitle,
  PictureCaption,
  PictureFileName,
  PictureHighlight,
  PictureCreateDate,
  PictureViewCount
 FROM Picture
 WHERE PictureID = @PictureID



GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[ngGetPicture]  TO [public]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO



/****** Object:  Stored Procedure dbo.ngGetPictureComments    Script Date: 8/26/2003 12:44:50 PM ******/
CREATE PROCEDURE dbo.ngGetPictureComments
  @AlbumID int,
  @PictureID int
AS

SELECT
	CommentID,
	CommentFromName,
	CommentFromEmailAddr,
	CommentFromWebURL,
	CommentText,
	CommentDateSubmitted
 FROM Comment
 WHERE CommentAlbumID = @AlbumID AND CommentPictureID = @PictureID
 ORDER BY CommentDateSubmitted ASC


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[ngGetPictureComments]  TO [public]
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS OFF 
GO



CREATE PROCEDURE dbo.ngGetPictureRating
  @PictureID int
AS

declare @COUNT int
set @COUNT = (SELECT count(*) FROM Rating WHERE PictureID = @PictureID)

if @COUNT > 0
begin
	SELECT
		Rating1,
		Rating2,
		Rating3,
		Rating4,
		Rating5
	  FROM Rating
	  WHERE PictureID = @PictureID
end
else
begin
	SELECT 0, 0, 0, 0, 0
end

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[ngGetPictureRating]  TO [public]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO



CREATE PROCEDURE dbo.ngGetPreviousAlbumID
  @AlbumID int
AS

declare @PrevID int
declare @AlbumName varchar(50)
set @AlbumName = (SELECT AlbumName FROM Album WHERE AlbumID = @AlbumID)

set @PrevID = (SELECT top 1 AlbumID FROM Album WHERE AlbumName < @AlbumName ORDER BY AlbumName DESC)

SELECT isnull(@PrevID, 0)


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[ngGetPreviousAlbumID]  TO [public]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO



CREATE PROCEDURE dbo.ngGetPreviousPictureID
  @AlbumID int,
  @PictureID int
AS

declare @PrevID int
set @PrevID = (SELECT top 1 PictureID FROM Picture WHERE PictureAlbumID = @AlbumID AND PictureID < @PictureID ORDER BY PictureID DESC)

SELECT isnull(@PrevID, 0)


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[ngGetPreviousPictureID]  TO [public]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO



CREATE PROC dbo.ngGetSubAlbums
  @ParentAlbumID int=0
AS

SELECT AlbumID,
	AlbumName,
	AlbumDesc,
	AlbumCreateDate,
	ParentAlbumID
FROM Album
WHERE ParentAlbumID = @ParentAlbumID
ORDER BY AlbumName


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[ngGetSubAlbums]  TO [public]
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE dbo.ngMarkInvitationRead
	@Guid varchar(50)
AS

UPDATE Invitation_Contacts SET IsRead = 1 WHERE Guid = @Guid
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[ngMarkInvitationRead]  TO [public]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO



/****** Object:  Stored Procedure dbo.ngSetHighlightedPicture    Script Date: 8/26/2003 12:44:50 PM ******/

CREATE PROCEDURE dbo.ngSetHighlightedPicture
  @AlbumID int,
  @PictureID int
AS

-- unset any previously selected picture
UPDATE Picture SET PictureHighlight = 0 WHERE PictureAlbumID = @AlbumID AND PictureHighlight = 1

-- set the new picture
UPDATE Picture SET PictureHighlight = 1 WHERE PictureID = @PictureID AND PictureAlbumID = @AlbumID



GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[ngSetHighlightedPicture]  TO [public]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO



CREATE PROCEDURE dbo.ngUpdateAlbum
  @AlbumID int,
  @AlbumName varchar(50)=null,
  @AlbumDesc varchar(2500)=null,
  @ParentAlbumID int=0
AS

UPDATE Album SET
  AlbumName = @AlbumName,
  AlbumDesc = @AlbumDesc,
  ParentAlbumID = @ParentAlbumID
 WHERE AlbumID = @AlbumID


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[ngUpdateAlbum]  TO [public]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO



/****** Object:  Stored Procedure dbo.ngUpdateComment    Script Date: 8/26/2003 12:44:50 PM ******/
CREATE PROCEDURE dbo.ngUpdateComment
  @AlbumID int,
  @PictureID int,
  @CommentID int,
  @FromName varchar(50)=null,
  @FromEmailAddr varchar(50)=null,
  @FromWebURL varchar(50)=null,
  @Text varchar(1000)=null
AS

UPDATE Comment SET
	CommentFromName = @FromName,
	CommentFromEmailAddr = @FromEmailAddr,
	CommentFromWebURL = @FromWebURL,
	CommentText = @Text
 WHERE CommentAlbumID = @AlbumID
  AND CommentPictureID = @PictureID
  AND CommentID = @CommentID


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[ngUpdateComment]  TO [public]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE dbo.ngUpdateContact
	@ContactID int,
	@FirstName varchar(25),
	@MiddleName varchar(25),
	@LastName varchar(25),
	@NickName varchar(25),
	@EmailAddress varchar(50),
	@HomePhone varchar(20),
	@WorkPhone varchar(20),
	@MobilePhone varchar(20),
	@Address1 varchar(50),
	@Address2 varchar(50),
	@City varchar(50),
	@State varchar(50),
	@Zip varchar(10),
	@WebsiteURL varchar(100)
AS

UPDATE Contact SET
	FirstName = @FirstName,
	MiddleName = @MiddleName,
	LastName = @LastName,
	NickName = @NickName,
	EmailAddress = @EmailAddress,
	HomePhone = @HomePhone,
	WorkPhone = @WorkPhone,
	MobilePhone = @MobilePhone,
	Address1 = @Address1,
	Address2 = @Address2,
	City = @City,
	State = @State,
	Zip = @Zip,
	WebsiteURL = @WebsiteURL
WHERE ContactID = @ContactID
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[ngUpdateContact]  TO [public]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO



/****** Object:  Stored Procedure dbo.ngUpdatePicture    Script Date: 8/26/2003 12:44:50 PM ******/

CREATE PROCEDURE dbo.ngUpdatePicture
  @PictureID int,
  @FileName varchar(50),
  @Title varchar(50)=null,
  @Caption varchar(2500)=null,
  @Highlight bit=0,
  @AlbumID int,
  @Width int = 0,
  @Height int = 0
AS

UPDATE Picture SET
  PictureFileName = @FileName,
  PictureTitle = @Title,
  PictureCaption = @Caption,
  PictureHighlight = @Highlight,
  PictureWidth = @Width,
  PictureHeight = @Height
 WHERE PictureID = @PictureID
  AND PictureAlbumID = @AlbumID
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[ngUpdatePicture]  TO [public]
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS OFF 
GO



CREATE PROCEDURE dbo.ngUpdatePictureRating
  @PictureID int,
  @Rating1 int=0,
  @Rating2 int=0,
  @Rating3 int=0,
  @Rating4 int=0,
  @Rating5 int=0
AS

declare @COUNT int
set @COUNT = (SELECT count(*) FROM Rating WHERE PictureID = @PictureID)

if @COUNT = 0
begin
	INSERT INTO Rating (PictureID, Rating1, Rating2, Rating3, Rating4, Rating5)
	  VALUES (@PictureID, @Rating1, @Rating2, @Rating3, @Rating4, @Rating5)
end
else
begin
	UPDATE Rating SET
		Rating1 = @Rating1,
		Rating2 = @Rating2,
		Rating3 = @Rating3,
		Rating4 = @Rating4,
		Rating5 = @Rating5
	  WHERE PictureID = @PictureID
end


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[ngUpdatePictureRating]  TO [public]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO



CREATE PROCEDURE dbo.ngUpdateViewCount
  @AlbumID int,
  @PictureID int
AS

UPDATE Picture SET PictureViewCount = PictureViewCount + 1 WHERE PictureAlbumID = @AlbumID AND PictureID = @PictureID



GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[ngUpdateViewCount]  TO [public]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ngGetAlbumCount]') and xtype in (N'FN', N'IF', N'TF'))
drop function [dbo].[ngGetAlbumCount]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ngGetTotalPictureCount]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ngGetTotalPictureCount]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

CREATE FUNCTION dbo.ngGetAlbumCount (@AlbumID int)  
RETURNS int AS  
BEGIN 

declare @ChildID int
declare @Count int
set @Count = (select count(*) from Picture where PictureAlbumID = @AlbumID)

declare childs cursor for
	select AlbumID from Album where ParentAlbumID = @AlbumID

open childs

fetch next from childs into @ChildID

while @@FETCH_STATUS = 0
begin
	set @Count = @Count + dbo.ngGetAlbumCount(@ChildID)
	fetch next from childs into @ChildID
end
close childs
deallocate childs

return @Count

END

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[ngGetAlbumCount]  TO [public]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE dbo.ngGetTotalPictureCount
	@AlbumID int
AS

declare @ChildID int
declare @Count int
set @Count = (select count(*) from Picture where PictureAlbumID = @AlbumID)

declare childs cursor for
	select AlbumID from Album where ParentAlbumID = @AlbumID

open childs

fetch next from childs into @ChildID

while @@FETCH_STATUS = 0
begin
	set @Count = @Count + dbo.ngGetAlbumCount(@ChildID)
	fetch next from childs into @ChildID
end
close childs
deallocate childs

select @Count
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[ngGetTotalPictureCount]  TO [public]
GO

CREATE TABLE [dbo].[System_Variables] (
	[Name] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Value] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL 
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[System_Variables] WITH NOCHECK ADD 
	CONSTRAINT [PK_System_Variables] PRIMARY KEY  CLUSTERED 
	(
		[Name]
	)  ON [PRIMARY] 
GO

INSERT INTO [System_Variables] ([Name], [Value]) VALUES ('Version', '1.6.1')
GO