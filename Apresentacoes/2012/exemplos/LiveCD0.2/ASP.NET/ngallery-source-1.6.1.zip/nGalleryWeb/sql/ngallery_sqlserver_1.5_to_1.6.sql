/**********************************************\
* nGallery                                     *
*   SQL Server Data Layer                      *
*   Use this file to upgrade from v1.5 to v1.6 *
\**********************************************/

CREATE PROCEDURE [dbo].[ngGetAlbumIDByName]
  @AlbumName varchar(100)
AS

SELECT AlbumID FROM Album WHERE AlbumName = @AlbumName
GO

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[ngGetAlbumIDByName]  TO [public]
GO

ALTER TABLE [dbo].[Picture] ADD
	PictureWidth INT NULL,
	PictureHeight INT NULL
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ngUpdatePicture]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ngUpdatePicture]
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS OFF 
GO



/****** Object:  Stored Procedure dbo.ngUpdatePicture    Script Date: 8/26/2003 12:44:50 PM ******/

CREATE PROCEDURE dbo.ngUpdatePicture
  @PictureID int,
  @FileName varchar(50),
  @Title varchar(50)=null,
  @Caption varchar(2500)=null,
  @Highlight bit=0,
  @AlbumID int,
  @Width int = 0,
  @Height int = 0
AS

UPDATE Picture SET
  PictureFileName = @FileName,
  PictureTitle = @Title,
  PictureCaption = @Caption,
  PictureHighlight = @Highlight,
  PictureWidth = @Width,
  PictureHeight = @Height
 WHERE PictureID = @PictureID
  AND PictureAlbumID = @AlbumID
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[ngUpdatePicture]  TO [public]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_Invitation_Contacts_Invitation]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[Invitation_Contacts] DROP CONSTRAINT FK_Invitation_Contacts_Invitation
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[FK_Invitation_Contacts_Contact]') and OBJECTPROPERTY(id, N'IsForeignKey') = 1)
ALTER TABLE [dbo].[Invitation_Contacts] DROP CONSTRAINT FK_Invitation_Contacts_Contact
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ngCreateContact]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ngCreateContact]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ngCreateInvitation]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ngCreateInvitation]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ngCreateInvitationContact]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ngCreateInvitationContact]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ngDeleteContact]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ngDeleteContact]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ngDeleteInvitation]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ngDeleteInvitation]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ngGetContact]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ngGetContact]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ngGetContactByGuid]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ngGetContactByGuid]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ngGetContacts]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ngGetContacts]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ngGetInvitationByGuid]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ngGetInvitationByGuid]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ngGetInvitationRecipients]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ngGetInvitationRecipients]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ngGetInvitations]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ngGetInvitations]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ngGetNextAlbumID]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ngGetNextAlbumID]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ngGetNextCommentID]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ngGetNextCommentID]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ngGetNextContactID]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ngGetNextContactID]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ngGetNextInvitationID]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ngGetNextInvitationID]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ngGetNextPictureID]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ngGetNextPictureID]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ngMarkInvitationRead]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ngMarkInvitationRead]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ngUpdateContact]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ngUpdateContact]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Invitation]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[Invitation]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Contact]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[Contact]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Invitation_Contacts]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[Invitation_Contacts]
GO

CREATE TABLE [dbo].[Invitation] (
	[InvitationID] [int] IDENTITY (1, 1) NOT NULL ,
	[AlbumID] [int] NOT NULL ,
	[Message] [text] COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[CreateDate] [datetime] NOT NULL 
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

CREATE TABLE [dbo].[Contact] (
	[ContactID] [int] IDENTITY (1, 1) NOT NULL ,
	[FirstName] [varchar] (25) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[MiddleName] [varchar] (25) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[LastName] [varchar] (25) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[NickName] [varchar] (25) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[EmailAddress] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[HomePhone] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[WorkPhone] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[MobilePhone] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Address1] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Address2] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[City] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[State] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Zip] [varchar] (10) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[WebsiteURL] [varchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[Invitation_Contacts] (
	[InvitationID] [int] NOT NULL ,
	[ContactID] [int] NOT NULL ,
	[Guid] [varchar] (40) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[IsRead] [bit] NOT NULL 
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[Invitation] WITH NOCHECK ADD 
	CONSTRAINT [PK_Invitations] PRIMARY KEY  CLUSTERED 
	(
		[InvitationID]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[Contact] WITH NOCHECK ADD 
	CONSTRAINT [PK_Contact] PRIMARY KEY  CLUSTERED 
	(
		[ContactID]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[Invitation_Contacts] WITH NOCHECK ADD 
	CONSTRAINT [PK_Invitation_Contacts] PRIMARY KEY  CLUSTERED 
	(
		[InvitationID],
		[ContactID]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[Invitation] ADD 
	CONSTRAINT [FK_Invitations_Album] FOREIGN KEY 
	(
		[AlbumID]
	) REFERENCES [dbo].[Album] (
		[AlbumID]
	)
GO

ALTER TABLE [dbo].[Invitation_Contacts] ADD 
	CONSTRAINT [FK_Invitation_Contacts_Contact] FOREIGN KEY 
	(
		[ContactID]
	) REFERENCES [dbo].[Contact] (
		[ContactID]
	),
	CONSTRAINT [FK_Invitation_Contacts_Invitation] FOREIGN KEY 
	(
		[InvitationID]
	) REFERENCES [dbo].[Invitation] (
		[InvitationID]
	)
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ngCreatePicture]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ngCreatePicture]
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE dbo.ngCreatePicture
  @Title varchar(50)=null,
  @Caption varchar(2500)=null,
  @FileName varchar(1000)=null,
  @Highlight bit=0,
  @AlbumID int,
  @Width int = 0,
  @Height int = 0
AS

INSERT INTO Picture (PictureTitle, PictureCaption, PictureFileName, PictureHighlight, PictureAlbumID, PictureCreateDate, PictureWidth, PictureHeight)
	VALUES (@Title, @Caption, @FileName, @Highlight, @AlbumID, getdate(), @Width, @Height)

GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[ngCreatePicture]  TO [public]
GO
	
SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE dbo.ngCreateContact
	@FirstName varchar(25),
	@MiddleName varchar(25),
	@LastName varchar(25),
	@NickName varchar(25),
	@EmailAddress varchar(50),
	@HomePhone varchar(20),
	@WorkPhone varchar(20),
	@MobilePhone varchar(20),
	@Address1 varchar(50),
	@Address2 varchar(50),
	@City varchar(50),
	@State varchar(50),
	@Zip varchar(10),
	@WebsiteURL varchar(100)
AS

INSERT INTO Contact (FirstName, MiddleName, LastName, NickName, EmailAddress, HomePhone, WorkPhone, MobilePhone, Address1, Address2, City, State, Zip, WebsiteURL)
	VALUES (@FirstName, @MiddleName, @LastName, @NickName, @EmailAddress, @HomePhone, @WorkPhone, @MobilePhone, @Address1, @Address2, @City, @State, @Zip, @WebsiteURL)
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[ngCreateContact]  TO [public]
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE dbo.ngCreateInvitation
	@AlbumID int,
	@Message text,
	@CreateDate datetime
AS

INSERT INTO Invitation (AlbumID, Message, CreateDate) VALUES (@AlbumID, @Message, @CreateDate)
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[ngCreateInvitation]  TO [public]
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE dbo.ngCreateInvitationContact
	@InvitationID int,
	@ContactID int,
	@GUID varchar(40)
AS

INSERT INTO Invitation_Contacts (InvitationID, ContactID, GUID, IsRead) VALUES (@InvitationID, @ContactID, @GUID, 0)
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[ngCreateInvitationContact]  TO [public]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE dbo.ngDeleteContact
	@ContactID int
AS

DELETE FROM Contact WHERE ContactID = @ContactID
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[ngDeleteContact]  TO [public]
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE dbo.ngDeleteInvitation
	@InvitationID int
AS

DELETE FROM Invitation_Contacts WHERE InvitationID = @InvitationID

DELETE FROM Invitation WHERE InvitationID = @InvitationID
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[ngDeleteInvitation]  TO [public]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE dbo.ngGetContact
	@ContactID int
AS

SELECT ContactID, FirstName, MiddleName, LastName, NickName, EmailAddress, HomePhone, WorkPhone, MobilePhone,
	Address1, Address2, City, State, Zip, WebsiteURL
FROM Contact
WHERE ContactID = @ContactID
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[ngGetContact]  TO [public]
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE dbo.ngGetContactByGuid
	@GUID varchar(40)
AS

SELECT Contact.ContactID, FirstName, MiddleName, LastName, NickName, EmailAddress, HomePhone, WorkPhone, MobilePhone,
	Address1, Address2, City, State, Zip, WebsiteURL
FROM Contact
RIGHT JOIN Invitation_Contacts ON Invitation_Contacts.ContactID = Contact.ContactID
WHERE GUID = @GUID
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[ngGetContactByGuid]  TO [public]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE dbo.ngGetContacts AS

SELECT ContactID, FirstName, MiddleName, LastName, NickName, EmailAddress, HomePhone, WorkPhone, MobilePhone,
	Address1, Address2, City, State, Zip, WebsiteURL
FROM Contact
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[ngGetContacts]  TO [public]
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE dbo.ngGetInvitationByGuid
	@GUID varchar(40)
AS

SELECT Invitation.InvitationID, AlbumID, Message, CreateDate
FROM Invitation
RIGHT JOIN Invitation_Contacts ON Invitation_Contacts.InvitationID = Invitation.InvitationID
WHERE GUID = @GUID
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[ngGetInvitationByGuid]  TO [public]
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE dbo.ngGetInvitationRecipients
	@InvitationID int
AS

SELECT ContactID, GUID, IsRead FROM Invitation_Contacts WHERE InvitationID = @InvitationID
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[ngGetInvitationRecipients]  TO [public]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE dbo.ngGetInvitations AS

SELECT InvitationID, AlbumID, Message, CreateDate FROM Invitation
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[ngGetInvitations]  TO [public]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO



/****** Object:  Stored Procedure dbo.ngGetNextAlbumID    Script Date: 8/26/2003 12:44:50 PM ******/

CREATE PROCEDURE dbo.ngGetNextAlbumID
AS

DECLARE @ID int
SET @ID = (SELECT ident_current('Album') + ident_seed('Album'))

if @ID = 2
begin
	DECLARE @Count int
	SET @Count = (SELECT count(AlbumID) FROM Album)
	if @Count = 0
	begin
		SET @ID = (SELECT @ID - ident_seed('Album'))
		SELECT @ID
	end
	else
	begin
		SELECT @ID
	end
end
else
begin
	SELECT @ID
end
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[ngGetNextAlbumID]  TO [public]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO



/****** Object:  Stored Procedure dbo.ngGetNextCommentID    Script Date: 8/26/2003 12:44:50 PM ******/
CREATE PROCEDURE dbo.ngGetNextCommentID
AS

DECLARE @ID int
SET @ID = (SELECT ident_current('Comment') + ident_seed('Comment'))

if @ID = 2
begin
	DECLARE @Count int
	SET @Count = (SELECT count(CommentID) FROM Comment)
	if @Count = 0
	begin
		SET @ID = (SELECT @ID - ident_seed('Comment'))
		SELECT @ID
	end
	else
	begin
		SELECT @ID
	end
end
else
begin
	SELECT @ID
end
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[ngGetNextCommentID]  TO [public]
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE dbo.ngGetNextContactID AS

DECLARE @ID int
SET @ID = (SELECT ident_current('Contact') + ident_seed('Contact'))

if @ID = 2
begin
	DECLARE @Count int
	SET @Count = (SELECT count(ContactID) FROM Contact)
	if @Count = 0
	begin
		SET @ID = (SELECT @ID - ident_seed('Contact'))
		SELECT @ID
	end
	else
	begin
		SELECT @ID
	end
end
else
begin
	SELECT @ID
end
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[ngGetNextContactID]  TO [public]
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE dbo.ngGetNextInvitationID AS

DECLARE @ID int
SET @ID = (SELECT ident_current('Invitation') + ident_seed('Invitation'))

if @ID = 2
begin
	DECLARE @Count int
	SET @Count = (SELECT count(InvitationID) FROM Invitation)
	if @Count = 0
	begin
		SET @ID = (SELECT @ID - ident_seed('Invitation'))
		SELECT @ID
	end
	else
	begin
		SELECT @ID
	end
end
else
begin
	SELECT @ID
end
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[ngGetNextInvitationID]  TO [public]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO



/****** Object:  Stored Procedure dbo.ngGetNextPictureID    Script Date: 8/26/2003 12:44:50 PM ******/

CREATE PROCEDURE dbo.ngGetNextPictureID
AS

DECLARE @ID int
SET @ID = (SELECT ident_current('Picture') + ident_seed('Picture'))

if @ID = 2
begin
	DECLARE @Count int
	SET @Count = (SELECT count(PictureID) FROM Picture)
	if @Count = 0
	begin
		SET @ID = (SELECT @ID - ident_seed('Picture'))
		SELECT @ID
	end
	else
	begin
		SELECT @ID
	end
end
else
begin
	SELECT @ID
end
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[ngGetNextPictureID]  TO [public]
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE dbo.ngMarkInvitationRead
	@Guid varchar(50)
AS

UPDATE Invitation_Contacts SET IsRead = 1 WHERE Guid = @Guid
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[ngMarkInvitationRead]  TO [public]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE dbo.ngUpdateContact
	@ContactID int,
	@FirstName varchar(25),
	@MiddleName varchar(25),
	@LastName varchar(25),
	@NickName varchar(25),
	@EmailAddress varchar(50),
	@HomePhone varchar(20),
	@WorkPhone varchar(20),
	@MobilePhone varchar(20),
	@Address1 varchar(50),
	@Address2 varchar(50),
	@City varchar(50),
	@State varchar(50),
	@Zip varchar(10),
	@WebsiteURL varchar(100)
AS

UPDATE Contact SET
	FirstName = @FirstName,
	MiddleName = @MiddleName,
	LastName = @LastName,
	NickName = @NickName,
	EmailAddress = @EmailAddress,
	HomePhone = @HomePhone,
	WorkPhone = @WorkPhone,
	MobilePhone = @MobilePhone,
	Address1 = @Address1,
	Address2 = @Address2,
	City = @City,
	State = @State,
	Zip = @Zip,
	WebsiteURL = @WebsiteURL
WHERE ContactID = @ContactID
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[ngUpdateContact]  TO [public]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ngGetAlbumCount]') and xtype in (N'FN', N'IF', N'TF'))
drop function [dbo].[ngGetAlbumCount]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ngGetTotalPictureCount]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ngGetTotalPictureCount]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

CREATE FUNCTION dbo.ngGetAlbumCount (@AlbumID int)  
RETURNS int AS  
BEGIN 

declare @ChildID int
declare @Count int
set @Count = (select count(*) from Picture where PictureAlbumID = @AlbumID)

declare childs cursor for
	select AlbumID from Album where ParentAlbumID = @AlbumID

open childs

fetch next from childs into @ChildID

while @@FETCH_STATUS = 0
begin
	set @Count = @Count + dbo.ngGetAlbumCount(@ChildID)
	fetch next from childs into @ChildID
end
close childs
deallocate childs

return @Count

END

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[ngGetAlbumCount]  TO [public]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO

CREATE PROCEDURE dbo.ngGetTotalPictureCount
	@AlbumID int
AS

declare @ChildID int
declare @Count int
set @Count = (select count(*) from Picture where PictureAlbumID = @AlbumID)

declare childs cursor for
	select AlbumID from Album where ParentAlbumID = @AlbumID

open childs

fetch next from childs into @ChildID

while @@FETCH_STATUS = 0
begin
	set @Count = @Count + dbo.ngGetAlbumCount(@ChildID)
	fetch next from childs into @ChildID
end
close childs
deallocate childs

select @Count
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[ngGetTotalPictureCount]  TO [public]
GO
