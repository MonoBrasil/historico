/************************************************\
* nGallery                                       *
*   SQL Server Data Layer                        *
*   Use this file to upgrade from v1.6 to v1.6.1 *
\************************************************/

CREATE TABLE [dbo].[System_Variables] (
	[Name] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[Value] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL 
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[System_Variables] WITH NOCHECK ADD 
	CONSTRAINT [PK_System_Variables] PRIMARY KEY  CLUSTERED 
	(
		[Name]
	)  ON [PRIMARY] 
GO

INSERT INTO [System_Variables] ([Name], [Value]) VALUES ('Version', '1.6.1')
GO



if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ngGetPreviousPictureID]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ngGetPreviousPictureID]
GO

CREATE PROCEDURE dbo.ngGetPreviousPictureID
  @AlbumID int,
  @PictureID int
AS

declare @PrevID int
set @PrevID = (SELECT top 1 PictureID FROM Picture WHERE PictureAlbumID = @AlbumID AND PictureID < @PictureID ORDER BY PictureID DESC)

SELECT isnull(@PrevID, 0)


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[ngGetPreviousPictureID]  TO [public]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO



if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ngGetNextActualPictureID]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[ngGetNextActualPictureID]
GO

CREATE PROCEDURE dbo.ngGetNextActualPictureID
  @AlbumID int,
  @PictureID int
AS

declare @NextID int
set @NextID = (SELECT top 1 PictureID FROM Picture WHERE PictureAlbumID = @AlbumID AND PictureID > @PictureID ORDER BY PictureID ASC)

SELECT isnull(@NextID, 0)


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[ngGetNextActualPictureID]  TO [public]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS OFF 
GO
