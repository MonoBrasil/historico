using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.IO;
using System.Text;
using System.Security.Cryptography;
using System.Configuration;

namespace nGallery.admin
{
	/// <summary>
	/// Summary description for addBulkPicture.
	/// </summary>
	public class addBulkPicture : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.Button btnAddPictures;
		protected System.Web.UI.WebControls.DropDownList dlFolders;
		protected ArrayList _validFiles = new ArrayList();
		protected System.Web.UI.WebControls.CheckBox chkCaptionFileName;
		protected System.Web.UI.WebControls.CheckBox chkTitleFileName;
		protected System.Web.UI.WebControls.CheckBox chkDeleteDir;
		protected System.Web.UI.WebControls.Literal litStatus;
		protected System.Web.UI.WebControls.Literal litExistingFiles;
		protected System.Web.UI.WebControls.ListBox listFiles;
		protected MetaBuilders.WebControls.MasterPages.Content SubNavContent;
		protected MetaBuilders.WebControls.MasterPages.Content LeftNavContent;
		protected MetaBuilders.WebControls.MasterPages.Content ComplexContent;
		protected MetaBuilders.WebControls.MasterPages.ContentContainer MPContainer;
		protected int _albumID;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			if (Request.QueryString["albumID"] != null)
			{
				try
				{
					_albumID = int.Parse(Request.QueryString["albumID"]);
				}
				catch
				{
					throw new Exception("Invalid ID passed for album ID. Please use querystring name albumID, and a valid integer.");
				}
			}


			if (!this.IsPostBack)
			{
				LoadFolders();
				listFiles.Items.Add(new ListItem("No files available...", "NONE"));
			}
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.dlFolders.SelectedIndexChanged += new System.EventHandler(this.dlFolders_SelectedIndexChanged);
			this.btnAddPictures.Click += new System.EventHandler(this.btnAddPictures_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void LoadFolders()
		{
			string[] directories = Directory.GetDirectories(Server.MapPath("../upload"));


			dlFolders.Items.Clear();
			if (directories.Length == 0)
			{
				dlFolders.Items.Add(new ListItem("No folders uploaded...", "0"));
				btnAddPictures.Enabled = false;
			}
			else
			{
			
				dlFolders.Items.Add(new ListItem("Choose one...", "CHOOSE"));
				dlFolders.SelectedIndex = 0;
				
				for (int i = 0; i < directories.Length; i++)
				{
					string[] directoryPieces = directories[i].Split(System.IO.Path.DirectorySeparatorChar);

					dlFolders.Items.Add(new ListItem(directoryPieces[directoryPieces.Length - 1], directories[i]));
				}

			}
		}

		private void dlFolders_SelectedIndexChanged(object sender, System.EventArgs e)
		{

			UpdateFileList();

		}

		private void UpdateFileList()
		{
			litStatus.Text = "";
			listFiles.Items.Clear();
			litExistingFiles.Text = "";

			if (dlFolders.Items[dlFolders.SelectedIndex].Value == "CHOOSE" ||
				dlFolders.Items[dlFolders.SelectedIndex].Value == "0")
			{
				listFiles.Items.Add(new ListItem("No files available...", "NONE"));
				return;
			}

			StringBuilder fileOutput = new StringBuilder();
			string[] files = Directory.GetFiles(dlFolders.Items[dlFolders.SelectedIndex].Value);


			if (files.Length == 0)
			{
				listFiles.Items.Add(new ListItem("No files available...", "NONE"));
			}
			else
			{

				for (int i = 0; i < files.Length; i++)
				{
					string[] filePieces = files[i].Split(System.IO.Path.DirectorySeparatorChar);
					string fileType		= nGallery.Lib.Util.DeriveFileType(files[i]);

					if (nGallery.Lib.Util.IsValidImageFile(fileType))
					{
						string currentFileName = filePieces[filePieces.Length - 1];
						int pictureID = GetPictureID(currentFileName);
						

						if (pictureID != 0)
						{
							string fullFilePath = Server.MapPath("../photos") + "/" + _albumID + "/" + pictureID;
							if (File.Exists(fullFilePath))
							{
								litExistingFiles.Text = litExistingFiles.Text +
									"<font color=\"red\">" + currentFileName + "</font><br>";
							}
							else
							{	
								listFiles.Items.Add(new ListItem(currentFileName, files[i]));
							}
						}
						else
						{
							listFiles.Items.Add(new ListItem(currentFileName, files[i]));
						}

			
					}
				}

				if (listFiles.Items.Count == 0)
				{
					listFiles.Items.Add(new ListItem("No files available...", "NONE"));
				}
			}
		}

		private int GetPictureID(string fileName)
		{
			nGallery.Lib.BL galleryBL = new nGallery.Lib.BL(Server.MapPath(nGallery.Lib.Configuration.Instance().DataDirectory), Server.MapPath(nGallery.Lib.Configuration.Instance().PhotosDirectory));
			Lib.PictureCollection pictures = galleryBL.GetAlbumPictures(_albumID);


			for (int j = 0; j < pictures.Count; j++)
			{
				if (pictures[j].FileName.Trim() == fileName.Trim())
				{
					return pictures[j].ID;
				}
			}
			return 0;

		}

		private void btnAddPictures_Click(object sender, System.EventArgs e)
		{
			if (dlFolders.Items[dlFolders.SelectedIndex].Value == "CHOOSE") 
			{
				litStatus.Text = "<font color=\"red\">Please choose a folder to upload.</font>";
				return;
			}

			if (listFiles.Items[0].Value == "NONE")
			{
				litStatus.Text = "<font color=\"red\">The current folder has no files to add.</font>";
				return;
			}

			if (CalcSelectedItemCount(listFiles) == 0)
			{
				litStatus.Text = "<font color=\"red\">You must choose at least one file to add.</font>";
				return;
			}

			nGallery.Lib.BL galleryBL = new nGallery.Lib.BL(Server.MapPath(nGallery.Lib.Configuration.Instance().DataDirectory), Server.MapPath(nGallery.Lib.Configuration.Instance().PhotosDirectory));

			_validFiles = (ArrayList) ViewState["ValidFiles"];

			
			for (int i = 0; i < listFiles.Items.Count; i++)
			{

				if (listFiles.Items[i].Selected)
				{
					string fileValue = listFiles.Items[i].Value;
					string fileName = nGallery.Lib.Util.DeriveFileName(fileValue);
					string targetFileName;
					

					fileName += "." + nGallery.Lib.Util.DeriveFileType(fileValue);

					
					nGallery.Lib.Picture newPicture = new nGallery.Lib.Picture();
					
					newPicture.ID		= galleryBL.GetNextPictureID(_albumID);
					newPicture.FileName = fileName;
					newPicture.CreateDate = System.IO.File.GetLastWriteTime(fileValue);
					
					targetFileName = Server.MapPath("../photos") + System.IO.Path.DirectorySeparatorChar + _albumID + System.IO.Path.DirectorySeparatorChar + newPicture.ID;
					
					if (chkDeleteDir.Checked)
					{
						File.Move(fileValue, targetFileName);
					}
					else
					{
						File.Copy(fileValue, targetFileName);
					}

					if (chkCaptionFileName.Checked)
					{
						newPicture.Caption = fileName;
					}

					if (chkTitleFileName.Checked)
					{
						newPicture.Title = fileName;
					}

					galleryBL.CreatePicture(_albumID, newPicture, null);

					nGallery.Lib.PhotoCache photoCache = new nGallery.Lib.PhotoCache(_albumID, newPicture.ID, Server.MapPath(nGallery.Lib.Configuration.Instance().PhotosDirectory));
					photoCache.GetThumbnail();

				}
			}

			if (chkDeleteDir.Checked)
			{
				Directory.Delete(dlFolders.Items[dlFolders.SelectedIndex].Value, true);
				LoadFolders();
			}

			litStatus.Text = "<font color=\"red\">Photos added!</font>";
			UpdateFileList();

		}

		private string GenerateUniqueFileName(string fileName)
		{
			MD5 md5				= new MD5CryptoServiceProvider();
			StreamReader reader	= new StreamReader(fileName);
			System.Guid g		= new System.Guid((System.Byte[])md5.ComputeHash(reader.BaseStream));


			reader.Close();

			return g.ToString();
		}

		private int CalcSelectedItemCount(ListBox listToCheck)
		{
			int selectedCount = 0;


			for (int i = 0; i < listToCheck.Items.Count; i++)
			{
				selectedCount += (listToCheck.Items[i].Selected ? 1 : 0);
			}

			return selectedCount;
		}

	}
}
