using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace nGallery.admin
{
	/// <summary>
	/// Summary description for dataConfig.
	/// </summary>
	public class dataConfig : System.Web.UI.Page
	{
		protected Label lblStatusMessages;
		protected ListBox ddDataStoreType;
		protected TextBox txtConnectionString;
		protected Button btnUpdate;

		private void Page_Load(object sender, System.EventArgs e)
		{
			string currentDataStoreType = "";

			if (!this.IsPostBack)
			{
				currentDataStoreType = nGallery.Lib.Configuration.Instance().DatastoreType;

				txtConnectionString.Text = nGallery.Lib.Configuration.Instance().ConnectionString;
			}

			ListItem liXML = new ListItem("XML", "XML");
			liXML.Selected = (currentDataStoreType == "XML" ? true : false);

			ListItem liSQLServer = new ListItem("MS SQL Server", "SQLServer");
			liSQLServer.Selected = (currentDataStoreType == "SQLServer" ? true : false);

			ddDataStoreType.Items.Add(liXML);
			ddDataStoreType.Items.Add(liSQLServer);

			ddDataStoreType.Rows = 1;
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);
			btnUpdate.Click += new EventHandler(btnUpdate_Click);
		}
		#endregion

		private void btnUpdate_Click(object sender, EventArgs e)
		{
			if (ddDataStoreType.SelectedValue == "SQLServer" &&
				txtConnectionString.Text.Trim() == "")
			{
				lblStatusMessages.ForeColor = Color.Red;
				lblStatusMessages.Text = "<b>When specifying a data store type of \"MS SQL Server\" you must supply a \"Connection String\".";
				
				return;
			}

			nGallery.Lib.Configuration.Instance().DatastoreType = ddDataStoreType.SelectedValue;
			nGallery.Lib.Configuration.Instance().ConnectionString = txtConnectionString.Text;

			nGallery.Lib.Configuration.Save();


			lblStatusMessages.ForeColor = Color.Blue;
			lblStatusMessages.Text = "<b>Configuration updated!</b><br /><br />";
		}
	}
}
