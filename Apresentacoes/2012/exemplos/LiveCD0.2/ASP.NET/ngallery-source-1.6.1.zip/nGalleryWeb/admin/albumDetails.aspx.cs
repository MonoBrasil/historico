#region Copyright and License
/*
Copyright 2003 Jason Alexander, nGallery.org
Design work copyright Thomas Johansen (http://www.aylarsolutions.com/)

GOTDOTNET WORKSPACES COMMERCIAL DERIVATIVES LICENSE
Copyright (C) 2003 Microsoft Corporation

You can use this Software for any commercial or noncommercial purpose, 
including distributing derivative works.

In return, we simply require that you agree:

1. Not to remove any copyright notices from the Software. 
2. That if you distribute the Software in source code form you do so only 
   under this License (i.e. you must include a complete copy of this License 
   with your distribution), and if you distribute the Software solely in 
   object form you only do so under a license that complies with this License. 
3. That the Software comes "as is", with no warranties. None whatsoever. This 
   means no express, implied or statutory warranty, including without 
   limitation, warranties of merchantability or fitness for a particular 
   purpose or any warranty of noninfringement. Also, you must pass this 
   disclaimer on whenever you distribute the Software.
4. That neither Microsoft nor any contributor to the Software will be liable 
   for any of those types of damages known as indirect, special, consequential, 
   or incidental related to the Software or this License, to the maximum extent 
   the law permits, no matter what legal theory it�s based on. Also, you must 
   pass this limitation of liability on whenever you distribute the Software.
5. That if you sue anyone over patents that you think may apply to the 
   Software for a person's use of the Software, your license to the Software 
   ends automatically. 
6. That the patent rights, if any, licensed hereunder only apply to the 
   Software, not to any derivative works you make. 
7. That your rights under this License end automatically if you breach it in 
   any way.
*/
#endregion
using System;
using System.Collections;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using FreeTextBoxControls;

namespace nGallery.admin
{
	/// <summary>
	/// Summary description for albumDetails.
	/// </summary>
	public class albumDetails : System.Web.UI.Page
	{
		protected FreeTextBox ftbCaption;
		protected System.Web.UI.WebControls.Label lblAlbumID;
		protected System.Web.UI.WebControls.TextBox txtAlbumName;
		protected System.Web.UI.WebControls.TextBox txtAlbumDesc;
		protected System.Web.UI.WebControls.Button btnUpdate;
		protected System.Web.UI.WebControls.DataGrid dgPictures;
		protected System.Web.UI.WebControls.Label lblAlbumCreateDate;
		protected System.Web.UI.WebControls.Image imgHighlightedPicture;
		protected System.Web.UI.WebControls.DropDownList ddParentAlbums;
		protected nGallery.Lib.BL galleryBL;
		protected nGallery.Lib.Album currentAlbum;
		protected int albumID = 0;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			galleryBL		= new nGallery.Lib.BL(Server.MapPath(nGallery.Lib.Configuration.Instance().DataDirectory), Server.MapPath(nGallery.Lib.Configuration.Instance().PhotosDirectory));
			HyperLinkColumn colEdit			= new HyperLinkColumn();
			HyperLinkColumn colDelete		= new HyperLinkColumn();
			HyperLinkColumn colHighlight	= new HyperLinkColumn();


			if (Request.QueryString["albumID"] != null)
			{
				try
				{
					albumID = int.Parse(Request.QueryString["albumID"]);
				}
				catch
				{
					Response.Redirect("default.aspx");
				}
			}
			else
			{
				if (ViewState["albumID"] != null)
				{
					albumID = int.Parse(ViewState["albumID"].ToString());
				}
				else
				{
					Response.Redirect("default.aspx");
				}
			}

			// Retrieve the current album.
			currentAlbum = galleryBL.GetAlbum(albumID);

			if (!this.IsPostBack)
			{
				nGallery.Lib.PhotoCache highlightedPicture;

				
				// Init the parent albums control.
				InitParentAlbums();

				// Set the page control properties.
				lblAlbumID.Text			= currentAlbum.ID.ToString();
				lblAlbumCreateDate.Text = currentAlbum.CreateDate.ToString();
				txtAlbumName.Text		= currentAlbum.Name;
				ftbCaption.Text			= currentAlbum.Description;


				// Get the highlighted picture image
				if(currentAlbum.HighlightedPicture != null)
				{
					highlightedPicture = galleryBL.CreatePhotoCache(currentAlbum.ID, currentAlbum.HighlightedPicture.ID);
				}
				else
				{
					highlightedPicture = galleryBL.CreatePhotoCache(currentAlbum.ID, 0);
				}
				string highlightedPictureImage = highlightedPicture.GetAlbumList();


				imgHighlightedPicture.BorderStyle	= BorderStyle.Solid;
				imgHighlightedPicture.BorderColor	= Color.Black;
				imgHighlightedPicture.BorderWidth	= Unit.Pixel(1);
				imgHighlightedPicture.ImageUrl		= highlightedPictureImage;
				imgHighlightedPicture.AlternateText = "Highlighted image for this album";

			}


			// Load up the album's pictures.
			nGallery.Lib.PictureCollection pictures = galleryBL.GetAlbumPictures(albumID);

			// Configure the data grid.
			dgPictures.AlternatingItemStyle.BackColor	= Color.LightGoldenrodYellow;


			// Configure the header style.
			dgPictures.HeaderStyle.BackColor		= Color.LightGray;
			dgPictures.HeaderStyle.HorizontalAlign	= HorizontalAlign.Center;
			dgPictures.HeaderStyle.Font.Name = "Arial";
			dgPictures.HeaderStyle.Font.Size = FontUnit.Point(10);
			dgPictures.HeaderStyle.Font.Bold = true;


			// Configure the item style.
			dgPictures.ItemStyle.HorizontalAlign	= HorizontalAlign.Center;
			dgPictures.ItemStyle.VerticalAlign		= VerticalAlign.Top;
			dgPictures.ItemStyle.Font.Name = "Arial";
			dgPictures.ItemStyle.Font.Size = FontUnit.Point(10);

			dgPictures.DataSource = pictures;

			dgPictures.DataBind();
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void InitParentAlbums()
		{
			nGallery.Lib.AlbumCollection albums = galleryBL.GetAlbums();


			ddParentAlbums.Items.Add(new ListItem("No Parent", "0"));
			for (int i = 0; i < albums.Count; i++)
			{
				if (albums[i].ID != albumID)
				{
					ListItem newItem = new ListItem(albums[i].Name, albums[i].ID.ToString());

					if (currentAlbum.ParentAlbumID == albums[i].ID)
						newItem.Selected = true;

					ddParentAlbums.Items.Add(newItem);
					
				}
			}
		}


		protected int GetCommentCount(object dataItem)
		{
			nGallery.Lib.Picture currentPicture = (nGallery.Lib.Picture) dataItem;

			return currentPicture.Comments.Count;
		}

		private void btnUpdate_Click(object sender, System.EventArgs e)
		{
			nGallery.Lib.BL galleryBL = new nGallery.Lib.BL(Server.MapPath(nGallery.Lib.Configuration.Instance().DataDirectory));
			nGallery.Lib.Album newAlbum = new nGallery.Lib.Album();

			
			// Create your new album with the updated details.
			newAlbum.ID				= int.Parse(lblAlbumID.Text);
			newAlbum.CreateDate		= DateTime.Now;
			newAlbum.Name			= txtAlbumName.Text;
			newAlbum.Description	= ftbCaption.Text;

			if (ddParentAlbums.SelectedValue != "0")
				newAlbum.ParentAlbumID  = int.Parse(ddParentAlbums.SelectedValue);

			ViewState["albumID"] = albumID;

			galleryBL.UpdateAlbum(newAlbum);


		}

	}
}
