#region Copyright and License
/*
Copyright 2003 Jason Alexander, nGallery.org
Design work copyright Thomas Johansen (http://www.aylarsolutions.com/)

GOTDOTNET WORKSPACES COMMERCIAL DERIVATIVES LICENSE
Copyright (C) 2003 Microsoft Corporation

You can use this Software for any commercial or noncommercial purpose, 
including distributing derivative works.

In return, we simply require that you agree:

1. Not to remove any copyright notices from the Software. 
2. That if you distribute the Software in source code form you do so only 
   under this License (i.e. you must include a complete copy of this License 
   with your distribution), and if you distribute the Software solely in 
   object form you only do so under a license that complies with this License. 
3. That the Software comes "as is", with no warranties. None whatsoever. This 
   means no express, implied or statutory warranty, including without 
   limitation, warranties of merchantability or fitness for a particular 
   purpose or any warranty of noninfringement. Also, you must pass this 
   disclaimer on whenever you distribute the Software.
4. That neither Microsoft nor any contributor to the Software will be liable 
   for any of those types of damages known as indirect, special, consequential, 
   or incidental related to the Software or this License, to the maximum extent 
   the law permits, no matter what legal theory it�s based on. Also, you must 
   pass this limitation of liability on whenever you distribute the Software.
5. That if you sue anyone over patents that you think may apply to the 
   Software for a person's use of the Software, your license to the Software 
   ends automatically. 
6. That the patent rights, if any, licensed hereunder only apply to the 
   Software, not to any derivative works you make. 
7. That your rights under this License end automatically if you breach it in 
   any way.
*/
#endregion
using System;
using System.Collections;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.Security.Cryptography;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using FreeTextBoxControls;

namespace nGallery.admin
{
	/// <summary>
	/// Summary description for addPicture.
	/// </summary>
	public class addPicture : System.Web.UI.Page
	{
		protected FreeTextBox ftbCaption;
		protected System.Web.UI.WebControls.Label lblError;
		protected System.Web.UI.HtmlControls.HtmlInputButton btnSubmit;
		protected System.Web.UI.HtmlControls.HtmlInputFile filePictureUpload;
		protected System.Web.UI.WebControls.TextBox txtPictureTitle;
		protected int albumID;


		private void Page_Load(object sender, System.EventArgs e)
		{

			if (Request.QueryString["albumID"] != null)
			{
				try
				{
					albumID = int.Parse(Request.QueryString["albumID"]);
				}
				catch
				{
					Response.Redirect("default.aspx");
				}
			}
			else
			{
				Response.Redirect("default.aspx");
			}
			

		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.btnSubmit.ServerClick += new System.EventHandler(this.btnSubmit_ServerClick);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void btnSubmit_ServerClick(object sender, System.EventArgs e)
		{
			nGallery.Lib.Picture newPicture = new nGallery.Lib.Picture();
			nGallery.Lib.BL galleryBL = new nGallery.Lib.BL(Server.MapPath(nGallery.Lib.Configuration.Instance().DataDirectory), Server.MapPath(nGallery.Lib.Configuration.Instance().PhotosDirectory));


			if ((filePictureUpload.PostedFile != null) && (filePictureUpload.PostedFile.ContentLength != 0))
			{
				if ((filePictureUpload.PostedFile.ContentType != "image/jpeg") &&
					(filePictureUpload.PostedFile.ContentType != "image/pjpeg") &&
					(filePictureUpload.PostedFile.ContentType != "image/gif") &&
					(filePictureUpload.PostedFile.ContentType != "image/png"))
				{
					lblError.Text = "Invalid file type \"" + filePictureUpload.PostedFile.ContentType + "\". File must be a .jpg, .gif or .png.";
					return;
				}

				System.IO.FileInfo fileInfo = new System.IO.FileInfo(filePictureUpload.PostedFile.FileName);

				newPicture.ID			= galleryBL.GetNextPictureID(albumID);
				newPicture.Title		= txtPictureTitle.Text;
				newPicture.Caption		= ftbCaption.Text;
				newPicture.FileName		= fileInfo.Name;
				newPicture.CreateDate	= DateTime.Now;
								
				galleryBL.CreatePicture(albumID, newPicture, filePictureUpload.PostedFile);

				nGallery.Lib.PhotoCache photoCache = new nGallery.Lib.PhotoCache(albumID, newPicture.ID, Server.MapPath(nGallery.Lib.Configuration.Instance().PhotosDirectory));
				photoCache.GetThumbnail();

				Response.Redirect("albumDetails.aspx?albumID=" + albumID);
			}
			else
			{
				lblError.Text = "Please select a file to upload.";
			}
		}
	}
}
