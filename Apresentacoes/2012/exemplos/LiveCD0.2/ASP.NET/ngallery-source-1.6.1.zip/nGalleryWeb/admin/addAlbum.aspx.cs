#region Copyright and License
/*
Copyright 2003 Jason Alexander, nGallery.org
Design work copyright Thomas Johansen (http://www.aylarsolutions.com/)

GOTDOTNET WORKSPACES COMMERCIAL DERIVATIVES LICENSE
Copyright (C) 2003 Microsoft Corporation

You can use this Software for any commercial or noncommercial purpose, 
including distributing derivative works.

In return, we simply require that you agree:

1. Not to remove any copyright notices from the Software. 
2. That if you distribute the Software in source code form you do so only 
   under this License (i.e. you must include a complete copy of this License 
   with your distribution), and if you distribute the Software solely in 
   object form you only do so under a license that complies with this License. 
3. That the Software comes "as is", with no warranties. None whatsoever. This 
   means no express, implied or statutory warranty, including without 
   limitation, warranties of merchantability or fitness for a particular 
   purpose or any warranty of noninfringement. Also, you must pass this 
   disclaimer on whenever you distribute the Software.
4. That neither Microsoft nor any contributor to the Software will be liable 
   for any of those types of damages known as indirect, special, consequential, 
   or incidental related to the Software or this License, to the maximum extent 
   the law permits, no matter what legal theory it�s based on. Also, you must 
   pass this limitation of liability on whenever you distribute the Software.
5. That if you sue anyone over patents that you think may apply to the 
   Software for a person's use of the Software, your license to the Software 
   ends automatically. 
6. That the patent rights, if any, licensed hereunder only apply to the 
   Software, not to any derivative works you make. 
7. That your rights under this License end automatically if you breach it in 
   any way.
*/
#endregion
using System;
using System.Collections;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using FreeTextBoxControls;

namespace nGallery.admin
{
	/// <summary>
	/// Summary description for addAlbum.
	/// </summary>
	public class addAlbum : System.Web.UI.Page
	{
		protected FreeTextBox ftbCaption;
		protected System.Web.UI.WebControls.Label txtConfirm;
		protected System.Web.UI.WebControls.TextBox txtAlbumName;
		protected System.Web.UI.WebControls.Button btnAddAlbum;
		protected System.Web.UI.WebControls.Button btnAddAlbumCont;
		protected System.Web.UI.WebControls.DropDownList ddParentAlbums;
		protected nGallery.Lib.BL galleryBL;
		
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			galleryBL		= new nGallery.Lib.BL(Server.MapPath(nGallery.Lib.Configuration.Instance().DataDirectory), Server.MapPath(nGallery.Lib.Configuration.Instance().PhotosDirectory));


			if (!this.IsPostBack)
			{

				// Init the parent albums control.
				InitParentAlbums();

			}

		}


		private void InitParentAlbums()
		{
			nGallery.Lib.AlbumCollection albums = galleryBL.GetAlbums();


			ddParentAlbums.Items.Add(new ListItem("No Parent", "0"));
			for (int i = 0; i < albums.Count; i++)
			{
				ListItem newItem = new ListItem(albums[i].Name, albums[i].ID.ToString());

				ddParentAlbums.Items.Add(newItem);
					
			}
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.btnAddAlbum.Click += new System.EventHandler(this.btnAddAlbum_Click);
			this.btnAddAlbumCont.Click += new EventHandler(btnAddAlbumCont_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void btnAddAlbum_Click(object sender, System.EventArgs e)
		{
			this.CreateAlbum();

			if(CheckErrors() == false)
				Response.Redirect("default.aspx");
		}

		private void btnAddAlbumCont_Click(object sender, EventArgs e)
		{
			int newAlbumID = this.CreateAlbum();

			if(CheckErrors() == false)
				Response.Redirect("addPicture.aspx?albumID=" + newAlbumID);
		}

		private bool CheckErrors()
		{
			System.Text.StringBuilder text = new System.Text.StringBuilder("<font color='red'>");
			bool areErrors = false;

			text.Append("Album successfully added, however there were warnings:<br><br>");

			if(System.Text.RegularExpressions.Regex.IsMatch(txtAlbumName.Text, "\\.$") == true)
			{
				text.Append("Your album name ends in a period.<br>");
				areErrors = true;
			}

			if(System.Text.RegularExpressions.Regex.IsMatch(txtAlbumName.Text, "%") == true)
			{
				text.Append("Your album name contains a '%' character.<br>");
				areErrors = true;
			}

			if(System.Text.RegularExpressions.Regex.IsMatch(txtAlbumName.Text, "/") == true)
			{
				text.Append("Your album name contains a '/' character.<br>");
				areErrors = true;
			}

			if(System.Text.RegularExpressions.Regex.IsMatch(txtAlbumName.Text, "&") == true)
			{
				text.Append("Your album name contains a '&' character.<br>");
				areErrors = true;
			}

			text.Append("<br>This will break nGallery's URL rewriting.  We advise you use \"By ID\" Friendly URL type for your installation, or remove the invalid characters.</font><br><br>");
			txtConfirm.Text = text.ToString();
			return areErrors;
		}

		private int CreateAlbum()
		{
			nGallery.Lib.BL galleryBL = new nGallery.Lib.BL(Server.MapPath(nGallery.Lib.Configuration.Instance().DataDirectory), Server.MapPath(nGallery.Lib.Configuration.Instance().PhotosDirectory));
			nGallery.Lib.Album newAlbum = new nGallery.Lib.Album();


			newAlbum.ID				= galleryBL.GetNextAlbumID();
			newAlbum.Name			= txtAlbumName.Text;
			newAlbum.Description	= ftbCaption.Text;
			newAlbum.CreateDate		= DateTime.Now;

			if (ddParentAlbums.SelectedValue != "0")
				newAlbum.ParentAlbumID  = int.Parse(ddParentAlbums.SelectedValue);

			galleryBL.CreateAlbum(newAlbum);


			return newAlbum.ID;
		}

	}
}
