using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace nGallery.admin
{
	/// <summary>
	/// Summary description for basicConfig.
	/// </summary>
	public class basicConfig : System.Web.UI.Page
	{
		protected TextBox txtSiteTitle;
		protected TextBox txtSiteSkin;
		protected TextBox txtSitePassword;
		protected TextBox txtAdminFullName;
		protected TextBox txtAdminEmailAddress;
		protected TextBox txtAdminUserName;
		protected TextBox txtAdminPassword;
		protected TextBox txtSMTPServer;
		protected TextBox txtAdminDirectory;
		protected TextBox txtDataDirectory;
		protected TextBox txtTemplateDirectory;
		protected TextBox txtPhotosDirectory;
		protected CheckBox chkErrorPageEnabled;
		protected TextBox txtSlideShowDelay;
		protected Button btnUpdate;
		protected Label lblStatusMessages;
		protected TextBox txtCharSet;
		protected DropDownList ddRewriteType;

		private void Page_Load(object sender, System.EventArgs e)
		{
			if (!this.IsPostBack)
			{
				txtSiteTitle.Text			= nGallery.Lib.Configuration.Instance().SiteTitle;
				txtSiteSkin.Text			= nGallery.Lib.Configuration.Instance().SiteSkin;
				txtSitePassword.Text		= nGallery.Lib.Configuration.Instance().SitePassword;
				txtAdminFullName.Text		= nGallery.Lib.Configuration.Instance().AdminFullName;
				txtAdminEmailAddress.Text	= nGallery.Lib.Configuration.Instance().AdminEmailAddress;
				txtAdminUserName.Text		= nGallery.Lib.Configuration.Instance().AdminUserName;
				txtAdminPassword.Text		= nGallery.Lib.Configuration.Instance().AdminPassword;
				txtSMTPServer.Text			= nGallery.Lib.Configuration.Instance().SmtpServer;
				txtAdminDirectory.Text		= nGallery.Lib.Configuration.Instance().AdminDirectory;
				txtDataDirectory.Text		= nGallery.Lib.Configuration.Instance().DataDirectory;
				txtTemplateDirectory.Text	= nGallery.Lib.Configuration.Instance().TemplateDirectory;
				txtPhotosDirectory.Text		= nGallery.Lib.Configuration.Instance().PhotosDirectory;
				txtSlideShowDelay.Text		= nGallery.Lib.Configuration.Instance().SlideShowDelay.ToString();
				txtCharSet.Text				= nGallery.Lib.Configuration.Instance().CharacterSet;
				
				chkErrorPageEnabled.Checked = nGallery.Lib.Configuration.Instance().CustomErrorPageEnabled;

				ddRewriteType.Items.Add(new ListItem("By Album ID", ((int) nGallery.Lib.RewriteType.ById).ToString()));
				ddRewriteType.Items.Add(new ListItem("By Album Name", ((int) nGallery.Lib.RewriteType.ByName).ToString()));
				ddRewriteType.SelectedValue = ((int) nGallery.Lib.Configuration.Instance().AlbumRewriting).ToString();

			}
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

			btnUpdate.Click += new EventHandler(btnUpdate_Click);
		}
		#endregion

		private void btnUpdate_Click(object sender, EventArgs e)
		{
			nGallery.Lib.Configuration.Instance().SiteTitle			= txtSiteTitle.Text;
			nGallery.Lib.Configuration.Instance().SiteSkin			= txtSiteSkin.Text;
			nGallery.Lib.Configuration.Instance().SitePassword		= txtSitePassword.Text;
			nGallery.Lib.Configuration.Instance().AdminFullName		= txtAdminFullName.Text;
			nGallery.Lib.Configuration.Instance().AdminEmailAddress	= txtAdminEmailAddress.Text;
			nGallery.Lib.Configuration.Instance().AdminUserName		= txtAdminUserName.Text;
			nGallery.Lib.Configuration.Instance().AdminPassword		= txtAdminPassword.Text;
			nGallery.Lib.Configuration.Instance().SmtpServer		= txtSMTPServer.Text;
			nGallery.Lib.Configuration.Instance().AdminDirectory	= txtAdminDirectory.Text;
			nGallery.Lib.Configuration.Instance().DataDirectory		= txtDataDirectory.Text;
			nGallery.Lib.Configuration.Instance().TemplateDirectory = txtTemplateDirectory.Text;
			nGallery.Lib.Configuration.Instance().PhotosDirectory	= txtPhotosDirectory.Text;
			nGallery.Lib.Configuration.Instance().CharacterSet		= txtCharSet.Text;
			nGallery.Lib.Configuration.Instance().AlbumRewriting	= (nGallery.Lib.RewriteType) int.Parse(ddRewriteType.SelectedValue);


			try
			{
				nGallery.Lib.Configuration.Instance().SlideShowDelay = int.Parse(txtSlideShowDelay.Text);
			}
			catch
			{
				lblStatusMessages.ForeColor = Color.Red;
				lblStatusMessages.Text = "<b>Invalid value entered for the \"Slide Show Delay\". Please enter a valid number.</b><br /><br />";
				return;
			}
				

			nGallery.Lib.Configuration.Instance().CustomErrorPageEnabled = chkErrorPageEnabled.Checked;
			
			nGallery.Lib.Configuration.Save();


			lblStatusMessages.ForeColor = Color.Blue;
			lblStatusMessages.Text = "<b>Configuration updated!</b><br /><br />";
		}
	}
}
