using System;
using System.IO;
using System.Text;
using System.Runtime.InteropServices;
using System.Security;
using System.Security.Permissions;
using System.Security.Principal;
using System.Web;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace nGallery.admin
{
	/// <summary>
	/// Summary description for checkPermissions.
	/// </summary>
	public class checkPermissions : System.Web.UI.Page
	{
		protected MetaBuilders.WebControls.MasterPages.Content SubNavContent;
		protected MetaBuilders.WebControls.MasterPages.Content LeftNavContent;
		protected MetaBuilders.WebControls.MasterPages.Content ComplexContent;
		protected MetaBuilders.WebControls.MasterPages.ContentContainer MPContainer;

		protected Label lblErrors;
		protected Label lblUser;
		protected Label lblPhotosResults;
		protected Label lblDataResults;
		protected Label lblUploadResults;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			// display the owner
			lblUser.Text = WindowsIdentity.GetCurrent().Name;

			// Test photos directory
			try
			{
				FileStream fs = File.Create(Server.MapPath(nGallery.Lib.Configuration.Instance().PhotosDirectory) + "test.txt");
				fs.Close();
				File.Delete(Server.MapPath(nGallery.Lib.Configuration.Instance().PhotosDirectory) + "test.txt");
				lblPhotosResults.Text = "<font color='green'>Passed</font>";
			}
			catch(Exception e1)
			{
				lblPhotosResults.Text = "<font color='red'>Failed</font>";
				lblErrors.Text += "Photos Directory<br />Path: " + Server.MapPath(nGallery.Lib.Configuration.Instance().PhotosDirectory) + "<br />Error message: " + e1.Message + "<br /><br />";
			}

			// Test data directory
			try
			{
				FileStream fs = File.Create(Server.MapPath(nGallery.Lib.Configuration.Instance().DataDirectory) + "test.txt");
				fs.Close();
				File.Delete(Server.MapPath(nGallery.Lib.Configuration.Instance().DataDirectory) + "test.txt");
				lblDataResults.Text = "<font color='green'>Passed</font>";
			}
			catch(Exception e2)
			{
				lblDataResults.Text = "<font color='red'>Failed</font>";
				lblErrors.Text += "Data Directory<br />Path: " + Server.MapPath(nGallery.Lib.Configuration.Instance().DataDirectory) + "<br />Error message: " + e2.Message + "<br /><br />";
			}

			// Test upload directory
			try
			{
				FileStream fs = File.Create(Server.MapPath(nGallery.Lib.Configuration.Instance().DataDirectory + "../upload/") + "test.txt");
				fs.Close();
				File.Delete(Server.MapPath(nGallery.Lib.Configuration.Instance().DataDirectory + "../upload/") + "test.txt");
				lblUploadResults.Text = "<font color='green'>Passed</font>";
			}
			catch(Exception e3)
			{
				lblUploadResults.Text = "<font color='red'>Failed</font>";
				lblErrors.Text += "Upload Directory<br />Path: " + Server.MapPath(nGallery.Lib.Configuration.Instance().DataDirectory + "../upload/") + "<br />Error message: " + e3.Message + "<br /><br />";
			}


		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}


	public class SecurityDescriptor
	{
		[DllImportAttribute("advapi32.dll", SetLastError=true)]
		private static extern int GetNamedSecurityInfo (
			string pObjectName,
			int ObjectType,
			int SecurityInfo,
			out IntPtr ppsidOwner,
			out IntPtr ppsidGroup,
			out IntPtr ppDacl,
			out IntPtr ppSacl,
			out IntPtr ppSecurityDescriptor
			);

		[DllImport( "advapi32.dll", CharSet=CharSet.Auto, SetLastError=true)]
		private static extern int LookupAccountSid( string systemName,
			IntPtr psid,
			StringBuilder accountName,
			ref int cbAccount,
			[Out] StringBuilder domainName,
			ref int cbDomainName,
			out int use );

		const int OWNER_SECURITY_INFORMATION = 1;
		const int SE_FILE_OBJECT = 1;

		public static string GetFileObjectOwner(string objectName)
		{
			IntPtr pZero = IntPtr.Zero;
			IntPtr pSid = pZero;
			IntPtr psd = pZero; // Not used here
			int errorReturn = GetNamedSecurityInfo(objectName, SE_FILE_OBJECT,
				OWNER_SECURITY_INFORMATION,
				out pSid, out pZero, out pZero, out pZero, out psd);
			if(errorReturn != 0) 
			{
				Console.WriteLine("GetNamedSecurityInfo: {0} ", errorReturn);
				return null;
			}
			int _bufferSize = 64;
			StringBuilder _buffer = new StringBuilder();
			int _accounLength = _bufferSize;
			int _domainLength = _bufferSize;
			int _sidNameUse= 0;
			StringBuilder _account = new StringBuilder(_bufferSize);
			StringBuilder _domain = new StringBuilder(_bufferSize);
			errorReturn = LookupAccountSid(null, pSid, _account, ref _accounLength, _domain, ref _domainLength, out _sidNameUse);
			if(errorReturn == 0) 
			{
				Console.WriteLine("LookupAccountSid: {0}", Marshal.GetLastWin32Error());
				return null;
			}
			_buffer.Append(_domain);
			_buffer.Append(@"\");
			_buffer.Append(_account);
			return _buffer.ToString();
		}
	}
}
