using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Text;

namespace nGallery.admin
{
	/// <summary>
	/// Summary description for imageConfig.
	/// </summary>
	public class imageConfig : System.Web.UI.Page
	{
		protected TextBox txtPictureMaxHeight;
		protected TextBox txtPictureMaxWidth;
		protected TextBox txtWatermarkText;
		protected TextBox txtAlbumListImageHeight;
		protected TextBox txtAlbumListImageWidth;
		protected TextBox txtAlbumListImageQuality;
		protected TextBox txtPictureListImageHeight;
		protected TextBox txtPictureListImageWidth;
		protected TextBox txtPictureListImageQuality;
		protected TextBox txtPictureDetailsImageHeight;
		protected TextBox txtPictureDetailsImageWidth;
		protected TextBox txtPictureDetailsImageQuality;
		protected TextBox txtSummaryImageHeight;
		protected TextBox txtSummaryImageWidth;
		protected TextBox txtSummaryImageQuality;
		protected TextBox txtSlideShowImageHeight;
		protected TextBox txtSlideShowImageWidth;
		protected TextBox txtSlideShowImageQuality;
		protected CheckBox chkOriginalPictureWatermark;
		protected CheckBox chkPictureListMaintainRatio;
		protected CheckBox chkPictureDetailsMaintainRatio;
		protected CheckBox chkPictureDetailsWatermark;
		protected CheckBox chkSummaryMaintainRatio;
		protected CheckBox chkSummaryWatermark;
		protected CheckBox chkSlideShowWatermark;
		protected CheckBox chkUserDefaultWatermarkImage;
		protected System.Web.UI.HtmlControls.HtmlInputFile fileWatermarkImage;
		protected DropDownList lstWatermarkType;
		protected DropDownList lstWatermarkPosition;
		protected Button btnUpdate;
		protected Label lblStatusMessages;
		protected System.Web.UI.WebControls.Image imgWatermark;
		protected System.Web.UI.WebControls.Image imgAlbumListExample;
		protected System.Web.UI.WebControls.Image imgPictureListExample;
		protected System.Web.UI.WebControls.Image imgPictureDetailsExample;
		protected System.Web.UI.WebControls.Image imgSummaryExample;
		protected MetaBuilders.WebControls.MasterPages.Content SubNavContent;
		protected MetaBuilders.WebControls.MasterPages.Content LeftNavContent;
		protected MetaBuilders.WebControls.MasterPages.Content ComplexContent;
		protected MetaBuilders.WebControls.MasterPages.ContentContainer MPContainer;
		protected System.Web.UI.WebControls.Image imgSlideShowExample;


		private void Page_Load(object sender, System.EventArgs e)
		{
			if (!this.IsPostBack)
			{
				txtPictureMaxHeight.Text			= nGallery.Lib.Configuration.Instance().PictureMaxHeight.ToString();
				txtPictureMaxWidth.Text				= nGallery.Lib.Configuration.Instance().PictureMaxWidth.ToString();
				txtWatermarkText.Text				= nGallery.Lib.Configuration.Instance().WatermarkText;
				txtAlbumListImageHeight.Text		= nGallery.Lib.Configuration.Instance().AlbumListImageHeight.ToString();
				txtAlbumListImageWidth.Text			= nGallery.Lib.Configuration.Instance().AlbumListImageWidth.ToString();
				txtAlbumListImageQuality.Text		= nGallery.Lib.Configuration.Instance().AlbumListImageQuality.ToString();
				txtPictureListImageHeight.Text		= nGallery.Lib.Configuration.Instance().PictureListImageHeight.ToString();
				txtPictureListImageWidth.Text		= nGallery.Lib.Configuration.Instance().PictureListImageWidth.ToString();
				txtPictureListImageQuality.Text		= nGallery.Lib.Configuration.Instance().PictureListImageQuality.ToString();
				txtPictureDetailsImageHeight.Text	= nGallery.Lib.Configuration.Instance().PictureDetailsImageHeight.ToString();
				txtPictureDetailsImageWidth.Text	= nGallery.Lib.Configuration.Instance().PictureDetailsImageWidth.ToString();
				txtPictureDetailsImageQuality.Text	= nGallery.Lib.Configuration.Instance().PictureDetailsImageQuality.ToString();
				txtSummaryImageHeight.Text			= nGallery.Lib.Configuration.Instance().SummaryImageHeight.ToString();
				txtSummaryImageWidth.Text			= nGallery.Lib.Configuration.Instance().SummaryImageWidth.ToString();
				txtSummaryImageQuality.Text			= nGallery.Lib.Configuration.Instance().SummaryImageQuality.ToString();
				txtSlideShowImageHeight.Text		= nGallery.Lib.Configuration.Instance().SlideShowImageHeight.ToString();
				txtSlideShowImageWidth.Text			= nGallery.Lib.Configuration.Instance().SlideShowImageWidth.ToString();
				txtSlideShowImageQuality.Text		= nGallery.Lib.Configuration.Instance().SlideShowImageQuality.ToString();

				chkOriginalPictureWatermark.Checked		= nGallery.Lib.Configuration.Instance().OriginalPictureWatermark;
				chkPictureListMaintainRatio.Checked		= nGallery.Lib.Configuration.Instance().PictureListMaintainRatio;
				chkPictureDetailsMaintainRatio.Checked	= nGallery.Lib.Configuration.Instance().PictureDetailsMaintainRatio;
				chkPictureDetailsWatermark.Checked		= nGallery.Lib.Configuration.Instance().PictureDetailsWatermark;
				chkSummaryMaintainRatio.Checked			= nGallery.Lib.Configuration.Instance().SummaryMaintainRatio;
				chkSummaryWatermark.Checked				= nGallery.Lib.Configuration.Instance().SummaryWatermark;
				chkSlideShowWatermark.Checked			= nGallery.Lib.Configuration.Instance().SlideShowWatermark;

				lstWatermarkType.SelectedIndex			= (int)nGallery.Lib.Configuration.Instance().WatermarkType;
				lstWatermarkPosition.SelectedIndex		= (int)nGallery.Lib.Configuration.Instance().WatermarkPosition;
			}

			this.ConfigurateExampleImage(imgAlbumListExample, 
				nGallery.Lib.Configuration.Instance().AlbumListImageHeight, 
				nGallery.Lib.Configuration.Instance().AlbumListImageWidth);

			this.ConfigurateExampleImage(imgPictureListExample,
				nGallery.Lib.Configuration.Instance().PictureListImageHeight,
				nGallery.Lib.Configuration.Instance().PictureListImageWidth);

			this.ConfigurateExampleImage(imgPictureDetailsExample,
				nGallery.Lib.Configuration.Instance().PictureDetailsImageHeight,
				nGallery.Lib.Configuration.Instance().PictureDetailsImageWidth);

			this.ConfigurateExampleImage(imgSummaryExample,
				nGallery.Lib.Configuration.Instance().SummaryImageHeight,
				nGallery.Lib.Configuration.Instance().SummaryImageWidth);

			this.ConfigurateExampleImage(imgSlideShowExample,
				nGallery.Lib.Configuration.Instance().SlideShowImageHeight,
				nGallery.Lib.Configuration.Instance().SlideShowImageWidth);

			this.ConfigurateWatermarkImage();

		}

		private void ConfigurateExampleImage(System.Web.UI.WebControls.Image imageObject, int height, int width)
		{
			imageObject.ImageUrl	= "../photos/gray_pixel.jpg";
			imageObject.Height		= height;
			imageObject.Width		= width;
			imageObject.BorderStyle = BorderStyle.Solid;
			imageObject.BorderColor = Color.Black;
			imageObject.BorderWidth = Unit.Pixel(1);

		}

		private void ConfigurateWatermarkImage()
		{
			if(System.IO.File.Exists(Page.Server.MapPath("../photos/" + nGallery.Lib.Configuration.Instance().WatermarkImage)))
			{
				imgWatermark.ImageUrl = "../photos/" + nGallery.Lib.Configuration.Instance().WatermarkImage;
			}
			else
			{
				imgWatermark.ImageUrl = "../photos/gray_pixel.jpg";
				imgWatermark.Height	= 100;
				imgWatermark.Width	= 100;
			}
			imgWatermark.BorderStyle = BorderStyle.Solid;
			imgWatermark.BorderColor = Color.Black;
			imgWatermark.BorderWidth = Unit.Pixel(1);
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void btnUpdate_Click(object sender, EventArgs e)
		{
			StringBuilder errors = new StringBuilder();
			bool hasErrors = false;


			errors.Append("<ul>");
			try
			{
				nGallery.Lib.Configuration.Instance().PictureMaxHeight = int.Parse(txtPictureMaxHeight.Text);
			}
			catch
			{
				errors.Append("<li>Invalid value entered for \"Picture Max Height\". Please enter a valid number.</li>");
				hasErrors = true;
			}

			try
			{
				nGallery.Lib.Configuration.Instance().PictureMaxWidth = int.Parse(txtPictureMaxWidth.Text);
			}
			catch
			{
				errors.Append("<li>Invalid value entered for \"Picture Max Width\". Please enter a valid number.</li>");
				hasErrors = true;
			}

			try
			{
				nGallery.Lib.Configuration.Instance().AlbumListImageHeight = int.Parse(txtAlbumListImageHeight.Text);
			}
			catch
			{
				errors.Append("<li>Invalid value entered for \"Album List Image Height\". Please enter a valid number.</li>");
				hasErrors = true;
			}

			try
			{
				nGallery.Lib.Configuration.Instance().AlbumListImageWidth = int.Parse(txtAlbumListImageWidth.Text);
			}
			catch
			{
				errors.Append("<li>Invalid value entered for \"Album List Image Width\". Please enter a valid number.</li>");
				hasErrors = true;
			}

			try
			{
				nGallery.Lib.Configuration.Instance().AlbumListImageQuality = int.Parse(txtAlbumListImageQuality.Text);
			}
			catch
			{
				errors.Append("<li>Invalid value entered for \"Album List Image Quality\". Please enter a valid number between 1 - 100.</li>");
				hasErrors = true;
			}

			try
			{
				nGallery.Lib.Configuration.Instance().PictureListImageHeight = int.Parse(txtPictureListImageHeight.Text);
			}
			catch
			{
				errors.Append("<li>Invalid value entered for \"Picture List Image Height\". Please enter a valid number.</li>");
				hasErrors = true;
			}

			try
			{
				nGallery.Lib.Configuration.Instance().PictureListImageWidth = int.Parse(txtPictureListImageWidth.Text);
			}
			catch
			{
				errors.Append("<li>Invalid value entered for \"Picture List Image Width\". Please enter a valid number.</li>");
				hasErrors = true;
			}

			try
			{
				nGallery.Lib.Configuration.Instance().PictureListImageQuality = int.Parse(txtPictureListImageQuality.Text);
			}
			catch
			{
				errors.Append("<li>Invalid value entered for \"Picture List Image Quality\". Please enter a valid number between 1 - 100.</li>");
				hasErrors = true;
			}

			try
			{
				nGallery.Lib.Configuration.Instance().PictureDetailsImageHeight = int.Parse(txtPictureDetailsImageHeight.Text);
			}
			catch
			{
				errors.Append("<li>Invalid value entered for \"Picture Details Image Height\". Please enter a valid number.</li>");
				hasErrors = true;
			}

			try
			{
				nGallery.Lib.Configuration.Instance().PictureDetailsImageWidth = int.Parse(txtPictureDetailsImageWidth.Text);
			}
			catch
			{
				errors.Append("<li>Invalid value entered for \"Picture Details Image Width\". Please enter a valid number.</li>");
				hasErrors = true;
			}

			try
			{
				nGallery.Lib.Configuration.Instance().PictureDetailsImageQuality = int.Parse(txtPictureDetailsImageQuality.Text);
			}
			catch
			{
				errors.Append("<li>Invalid value entered for \"Picture Details Image Quality\". Please enter a valid number between 1 - 100.</li>");
				hasErrors = true;
			}

			try
			{
				nGallery.Lib.Configuration.Instance().SummaryImageHeight = int.Parse(txtSummaryImageHeight.Text);
			}
			catch
			{
				errors.Append("<li>Invalid value entered for \"Summary Image Height\". Please enter a valid number.</li>");
				hasErrors = true;
			}

			try
			{
				nGallery.Lib.Configuration.Instance().SummaryImageWidth = int.Parse(txtSummaryImageWidth.Text);
			}
			catch
			{
				errors.Append("<li>Invalid value entered for \"Summary Image Width\". Please enter a valid number.</li>");
				hasErrors = true;
			}

			try
			{
				nGallery.Lib.Configuration.Instance().SummaryImageQuality = int.Parse(txtSummaryImageQuality.Text);
			}
			catch
			{
				errors.Append("<li>Invalid value entered for \"Summary Image Quality\". Please enter a valid number between 1 - 100.</li>");
				hasErrors = true;
			}

			try
			{
				nGallery.Lib.Configuration.Instance().SlideShowImageHeight = int.Parse(txtSlideShowImageHeight.Text);
			}
			catch
			{
				errors.Append("<li>Invalid value entered for \"Slide Show Image Height\". Please enter a valid number.</li>");
				hasErrors = true;
			}

			try
			{
				nGallery.Lib.Configuration.Instance().SlideShowImageWidth = int.Parse(txtSlideShowImageWidth.Text);
			}
			catch
			{
				errors.Append("<li>Invalid value entered for \"Slide Show Image Width\". Please enter a valid number.</li>");
				hasErrors = true;
			}

			try
			{
				nGallery.Lib.Configuration.Instance().SlideShowImageQuality = int.Parse(txtSlideShowImageQuality.Text);
			}
			catch
			{
				errors.Append("<li>Invalid value entered for \"Slide Show Image Quality\". Please enter a valid number between 1 - 100.</li>");
				hasErrors = true;
			}
			errors.Append("</ul><br /><br />");

			nGallery.Lib.Configuration.Instance().OriginalPictureWatermark		= chkOriginalPictureWatermark.Checked;
			nGallery.Lib.Configuration.Instance().PictureDetailsWatermark		= chkPictureDetailsWatermark.Checked;
			nGallery.Lib.Configuration.Instance().SummaryWatermark				= chkSummaryWatermark.Checked;
			nGallery.Lib.Configuration.Instance().SlideShowWatermark			= chkSlideShowWatermark.Checked;
			nGallery.Lib.Configuration.Instance().PictureListMaintainRatio		= chkPictureListMaintainRatio.Checked;
			nGallery.Lib.Configuration.Instance().PictureDetailsMaintainRatio	= chkPictureDetailsMaintainRatio.Checked;
			nGallery.Lib.Configuration.Instance().SummaryMaintainRatio			= chkSummaryMaintainRatio.Checked;

			nGallery.Lib.Configuration.Instance().WatermarkType					= (nGallery.Lib.Definitions.WatermarkType)lstWatermarkType.SelectedIndex;
			nGallery.Lib.Configuration.Instance().WatermarkPosition				= (nGallery.Lib.Definitions.WatermarkPosition)lstWatermarkPosition.SelectedIndex;

			try
			{
				nGallery.Lib.Configuration.Instance().WatermarkText				= txtWatermarkText.Text;
			}
			catch
			{
				errors.Append("<li>Invalid text entered in for \"Watermark Text\".</li>");
			}

			if((fileWatermarkImage.PostedFile != null) && (fileWatermarkImage.PostedFile.ContentLength != 0))
			{

				if ((fileWatermarkImage.PostedFile.ContentType != "image/bmp"))
				{
					errors.Append("Invalid file type \"" + fileWatermarkImage.PostedFile.ContentType + "\". File must be a .jpg, .gif or .png.");
					return;
				}

				if((nGallery.Lib.Configuration.Instance().WatermarkImage != null)
					&& (System.IO.File.Exists(Server.MapPath(nGallery.Lib.Configuration.Instance().PhotosDirectory + System.IO.Path.DirectorySeparatorChar + nGallery.Lib.Configuration.Instance().WatermarkImage))))
				{
					System.IO.File.Delete(nGallery.Lib.Configuration.Instance().WatermarkImage);
				}

				System.IO.FileInfo fileInfo = new System.IO.FileInfo(fileWatermarkImage.PostedFile.FileName);
				nGallery.Lib.Configuration.Instance().WatermarkImage = "watermark" + fileInfo.Extension;
				fileWatermarkImage.PostedFile.SaveAs(Server.MapPath(nGallery.Lib.Configuration.Instance().PhotosDirectory + System.IO.Path.DirectorySeparatorChar + "watermark" + fileInfo.Extension));
				this.ConfigurateWatermarkImage();
			}
			else
			{
				if(chkUserDefaultWatermarkImage.Checked == true)
				{
					nGallery.Lib.Configuration.Instance().WatermarkImage = "default_watermark.bmp";
					this.ConfigurateWatermarkImage();
				}
			}

			if (hasErrors)
			{
				lblStatusMessages.ForeColor = Color.Red;
				lblStatusMessages.Text = "The following error(s) were encountered while attempting to update the configuration:<br />" + errors.ToString();
				return;
			}

			nGallery.Lib.Configuration.Save();

			lblStatusMessages.ForeColor = Color.Blue;
			lblStatusMessages.Text = "<b>Configuration updated!</b><br /><br />";

		}
	}
}
