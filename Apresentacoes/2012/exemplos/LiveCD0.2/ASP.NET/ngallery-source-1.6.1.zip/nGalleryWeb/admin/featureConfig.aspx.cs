using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Text;


namespace nGallery.admin
{
	/// <summary>
	/// Summary description for featureConfig.
	/// </summary>
	public class featureConfig : System.Web.UI.Page
	{
		protected TextBox txtAlbumListRecordsPerPage;
		protected TextBox txtAlbumListDescriptionLength;
		protected ListBox ddAlbumListPagingDisplayType;
		protected TextBox txtPictureListRecordsPerPage;
		protected TextBox txtPictureListColumnsPerPage;
		protected ListBox ddPictureListPagingDisplayType;
		protected CheckBox chkEnableComments;
		protected ListBox ddCommentType;
		protected CheckBox chkEnableRatings;
		protected Button btnUpdate;
		protected Label lblStatusMessages;
		protected CheckBox chkEnableExif;
		protected CheckBox chkEnableStats;

		private void Page_Load(object sender, System.EventArgs e)
		{
			string albumDisplayType = "";
			string pictureDisplayType = "";
			string commentType = "";


			if (!this.IsPostBack)
			{
				txtAlbumListRecordsPerPage.Text		= nGallery.Lib.Configuration.Instance().AlbumListRecordsPerPage.ToString();
				txtAlbumListDescriptionLength.Text	= nGallery.Lib.Configuration.Instance().AlbumListDescLength.ToString();
				txtPictureListRecordsPerPage.Text	= nGallery.Lib.Configuration.Instance().PictureListRecordsPerPage.ToString();
				txtPictureListColumnsPerPage.Text	= nGallery.Lib.Configuration.Instance().PictureListColumnsPerPage.ToString();

				chkEnableComments.Checked			= nGallery.Lib.Configuration.Instance().EnableComments;
				chkEnableRatings.Checked			= nGallery.Lib.Configuration.Instance().EnableRatings;
				chkEnableExif.Checked				= nGallery.Lib.Configuration.Instance().EnableExif;
				chkEnableStats.Checked				= nGallery.Lib.Configuration.Instance().EnableStats;
				
				albumDisplayType	= nGallery.Lib.Configuration.Instance().AlbumListPagingDisplayType;
				pictureDisplayType	= nGallery.Lib.Configuration.Instance().PictureListPagingDisplayType;
				commentType			= nGallery.Lib.Configuration.Instance().CommentType;

				// Album List Paging Display Type
				ListItem liADDisplay = new ListItem("Display", "display");
				ListItem liADDisappear = new ListItem("Disappear", "disappear");

				liADDisplay.Selected = (albumDisplayType == "display" ? true : false);
				liADDisappear.Selected = (albumDisplayType == "disappear" ? true : false);

				ddAlbumListPagingDisplayType.Items.Add(liADDisplay);
				ddAlbumListPagingDisplayType.Items.Add(liADDisappear);

				ddAlbumListPagingDisplayType.Rows = 1;

				// Picture List Paging Display Type
				ListItem liPLDisplay = new ListItem("Display", "display");
				ListItem liPLDisappear = new ListItem("Disappear", "disappear");

				liPLDisplay.Selected = (pictureDisplayType == "display" ? true : false);
				liPLDisappear.Selected = (pictureDisplayType == "disappear" ? true : false);

				ddPictureListPagingDisplayType.Items.Add(liPLDisplay);
				ddPictureListPagingDisplayType.Items.Add(liPLDisappear);

				ddPictureListPagingDisplayType.Rows = 1;

				// Comment Types
				ListItem liComment = new ListItem("Comment", "Comment");
				ListItem liCaption = new ListItem("Caption", "Caption");

				liComment.Selected = (commentType == "Comment" ? true : false);
				liCaption.Selected = (commentType == "Caption" ? true : false);

				ddCommentType.Items.Add(liComment);
				ddCommentType.Items.Add(liCaption);

				ddCommentType.Rows = 1;			
			}

		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);
			btnUpdate.Click += new EventHandler(btnUpdate_Click);			
		}
		#endregion

		private void btnUpdate_Click(object sender, EventArgs e)
		{
			StringBuilder errors = new StringBuilder();
			bool hasErrors = false;


			errors.Append("<ul>");
			try
			{
				nGallery.Lib.Configuration.Instance().AlbumListRecordsPerPage = int.Parse(txtAlbumListRecordsPerPage.Text);
			}
			catch
			{
				errors.Append("<li>Invalid value entered for \"Album List Records Per Page\". Please enter a valid number.</li>");
				hasErrors = true;
			}

			try
			{
				nGallery.Lib.Configuration.Instance().AlbumListDescLength  = int.Parse(txtAlbumListDescriptionLength.Text);
			}
			catch
			{
				errors.Append("<li>Invalid value entered for \"Album List Description Length\". Please enter a valid number.</li>");
				hasErrors = true;
			}

			try
			{
				nGallery.Lib.Configuration.Instance().PictureListRecordsPerPage = int.Parse(txtPictureListRecordsPerPage.Text);
			}
			catch
			{
				errors.Append("<li>Invalid value entered for \"Picture List Records Per Page\". Please enter a valid number.</li>");
				hasErrors = true;
			}

			try
			{
				nGallery.Lib.Configuration.Instance().PictureListColumnsPerPage = int.Parse(txtPictureListColumnsPerPage.Text);
			}
			catch 
			{
				errors.Append("<li>Invalid value entered for \"Picture List Columns Per Page\". Please enter a valid number.</li>");
				hasErrors = true;
			}
			errors.Append("</ul><br /><br />");
			
			nGallery.Lib.Configuration.Instance().EnableComments	= chkEnableComments.Checked;
			nGallery.Lib.Configuration.Instance().EnableRatings		= chkEnableRatings.Checked;
			nGallery.Lib.Configuration.Instance().EnableExif		= chkEnableExif.Checked;
			nGallery.Lib.Configuration.Instance().EnableStats		= chkEnableStats.Checked;

			nGallery.Lib.Configuration.Instance().AlbumListPagingDisplayType	= ddAlbumListPagingDisplayType.SelectedValue;
			nGallery.Lib.Configuration.Instance().PictureListPagingDisplayType	= ddPictureListPagingDisplayType.SelectedValue;
			nGallery.Lib.Configuration.Instance().CommentType					= ddCommentType.SelectedValue;


			if (hasErrors)
			{
				lblStatusMessages.ForeColor = Color.Red;
				lblStatusMessages.Text = "The following error(s) were encountered while attempting to update the configuration:<br />" + errors.ToString();
				return;
			}

			nGallery.Lib.Configuration.Save();

			lblStatusMessages.ForeColor = Color.Blue;
			lblStatusMessages.Text = "<b>Configuration updated!</b><br /><br />";

		}
	}
}
