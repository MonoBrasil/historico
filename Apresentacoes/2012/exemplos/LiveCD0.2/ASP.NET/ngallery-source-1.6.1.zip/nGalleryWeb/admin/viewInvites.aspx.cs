using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace nGallery.admin
{
	/// <summary>
	/// Summary description for viewInvites.
	/// </summary>
	public class viewInvites : System.Web.UI.Page
	{
		protected Repeater rRecipients;

		private int _inviteID;
		private nGallery.Lib.BL _galleryBL;
		private ArrayList _viewedRecipients = new ArrayList();
		private ArrayList _unviewedRecipients = new ArrayList();


		private void Page_Load(object sender, System.EventArgs e)
		{
			_galleryBL = new nGallery.Lib.BL(Server.MapPath(nGallery.Lib.Configuration.Instance().DataDirectory));
			

			if (Request.QueryString["InviteID"] != null)
			{
				try
				{
					_inviteID  = int.Parse(Request.QueryString["InviteID"]);
				}
				catch 
				{
					Response.Redirect("invitations.aspx");
				}
			}
			else
			{
				Response.Redirect("invitations.aspx");
			}


			ArrayList recipientInfo = _galleryBL.GetInvitationRecipients(_inviteID);
			ArrayList recipients = new ArrayList();

			for (int i = 0; i < recipientInfo.Count; i++)
			{
				ArrayList recipient = (ArrayList) recipientInfo[i];


				recipients.Add(_galleryBL.GetContact(int.Parse(recipient[0].ToString())));

				if (recipient[2].ToString().Trim() == "true")
				{
					_viewedRecipients.Add(recipient[0]);
				}
				else if (recipient[2].ToString().Trim() == "false")
				{
					_unviewedRecipients.Add(recipient[0]);
				}
			}

			rRecipients.DataSource = recipients;

			rRecipients.DataBind();

		}

		protected string ShowViewStatus(object dataItem)
		{
			nGallery.Lib.Contact recipient = (nGallery.Lib.Contact) dataItem;


			// First check viewed.
			for (int i = 0; i < _viewedRecipients.Count; i++)
			{
				if (int.Parse(_viewedRecipients[i].ToString()) == recipient.ID)
				{
					return "Yes";
				}
			}

			// Next, unviewed.
			for (int i = 0; i < _unviewedRecipients.Count; i++)
			{
				if (int.Parse(_unviewedRecipients[i].ToString()) == recipient.ID)
				{
					return "No";
				}
			}

			return "Unknown";
		}


		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);
		}
		#endregion
	}
}
