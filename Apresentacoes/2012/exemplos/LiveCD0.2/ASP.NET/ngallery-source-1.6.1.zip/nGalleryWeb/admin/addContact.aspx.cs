using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace nGallery.admin
{
	/// <summary>
	/// Summary description for addContact.
	/// </summary>
	public class addContact : System.Web.UI.Page
	{
		protected MetaBuilders.WebControls.MasterPages.Content SubNavContent;
		protected MetaBuilders.WebControls.MasterPages.Content LeftNavContent;
		protected MetaBuilders.WebControls.MasterPages.Content ComplexContent;
		protected MetaBuilders.WebControls.MasterPages.ContentContainer MPContainer;
		protected TextBox txtFirstName;
		protected TextBox txtMiddleName;
		protected TextBox txtLastName;
		protected TextBox txtNickName;
		protected TextBox txtEmailAddress;
		protected TextBox txtHomeNumber;
		protected TextBox txtWorkNumber;
		protected TextBox txtMobileNumber;
		protected TextBox txtAddress1;
		protected TextBox txtAddress2;
		protected TextBox txtCity;
		protected TextBox txtState;
		protected TextBox txtZipCode;
		protected TextBox txtWebsiteUrl;
		protected Button btnSave;
		protected Button btnSaveAdd;
		protected Button btnCancel;
		private nGallery.Lib.BL galleryBL; 

	
		private void Page_Load(object sender, System.EventArgs e)
		{
			galleryBL = new nGallery.Lib.BL(Server.MapPath(nGallery.Lib.Configuration.Instance().DataDirectory));
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

			this.btnSave.Click += new EventHandler(btnSave_Click);
			this.btnSaveAdd.Click += new EventHandler(btnSaveAdd_Click);
			this.btnCancel.Click += new EventHandler(btnCancel_Click);

		}
		#endregion

		private void btnSave_Click(object sender, EventArgs e)
		{
			nGallery.Lib.Contact newContact = new nGallery.Lib.Contact();
			

			newContact.ID			= galleryBL.GetNextContactID();
			newContact.FirstName	= txtFirstName.Text;
			newContact.MiddleName	= txtMiddleName.Text;
			newContact.LastName		= txtLastName.Text;
			newContact.NickName		= txtNickName.Text;
			newContact.EmailAddress = txtEmailAddress.Text;
			newContact.HomePhone	= txtHomeNumber.Text;
			newContact.WorkPhone	= txtWorkNumber.Text;
			newContact.MobilePhone	= txtMobileNumber.Text;
			newContact.Address1		= txtAddress1.Text;
			newContact.Address2		= txtAddress2.Text;
			newContact.City			= txtCity.Text;
			newContact.State		= txtState.Text;
			newContact.Zip			= txtZipCode.Text;
			newContact.WebsiteUrl	= txtWebsiteUrl.Text;


			galleryBL.CreateContact(newContact);

			Response.Redirect("addressBook.aspx");
		}

		private void btnSaveAdd_Click(object sender, EventArgs e)
		{
			nGallery.Lib.Contact newContact = new nGallery.Lib.Contact();
			

			newContact.ID			= galleryBL.GetNextContactID();
			newContact.FirstName	= txtFirstName.Text;
			newContact.MiddleName	= txtMiddleName.Text;
			newContact.LastName		= txtLastName.Text;
			newContact.NickName		= txtNickName.Text;
			newContact.EmailAddress = txtEmailAddress.Text;
			newContact.HomePhone	= txtHomeNumber.Text;
			newContact.WorkPhone	= txtWorkNumber.Text;
			newContact.MobilePhone	= txtMobileNumber.Text;
			newContact.Address1		= txtAddress1.Text;
			newContact.Address2		= txtAddress2.Text;
			newContact.City			= txtCity.Text;
			newContact.State		= txtState.Text;
			newContact.Zip			= txtZipCode.Text;
			newContact.WebsiteUrl	= txtWebsiteUrl.Text;


			galleryBL.CreateContact(newContact);

			Response.Redirect("addContact.aspx");

		}

		private void btnCancel_Click(object sender, EventArgs e)
		{
			Response.Redirect("addressBook.aspx");
		}
	}
}
