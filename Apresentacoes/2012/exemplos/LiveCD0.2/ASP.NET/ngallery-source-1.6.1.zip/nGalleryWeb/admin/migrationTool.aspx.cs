using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.IO;
using System.Security.Cryptography;

namespace nGallery.admin
{
	/// <summary>
	/// Summary description for migrationTool.
	/// </summary>
	public class migrationTool : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.Button Button1;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			Response.Buffer = false;
			Response.BufferOutput = false;
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Button1.Click += new System.EventHandler(this.Button1_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void Button1_Click(object sender, System.EventArgs e)
		{
			string sourceDirectory = Server.MapPath("~/photos/");
			string[] sourceFiles = Directory.GetFiles(sourceDirectory, "*.jpg");
			nGallery.Lib.BL galleryBL = new nGallery.Lib.BL(Server.MapPath(nGallery.Lib.Configuration.Instance().DataDirectory));
			nGallery.Lib.AlbumCollection albums = galleryBL.GetAlbums();


			Response.Write("Beginning migration...<br>");
			Response.Write(sourceFiles.Length + " image file(s) found...<br>");
			for (int i = 0; i < sourceFiles.Length; i++)
			{
				string[] fileParts = sourceFiles[i].Split(System.IO.Path.DirectorySeparatorChar);
				string fileName = fileParts[fileParts.Length - 1];
				string hashedFileName = GenerateUniqueFileName(sourceFiles[i]);
			
				Response.Write("Analyzing " + fileName + " (" + hashedFileName + ")...<br>");
				for (int j = 0; j < albums.Count; j++)
				{
					for (int k = 0; k < albums[j].Pictures.Count; k++)
					{
						if (nGallery.Lib.Util.DeriveFileName(albums[j].Pictures[k].FileName) == hashedFileName)
						{
							int albumID = albums[j].ID;
							int pictureID = albums[j].Pictures[k].ID;
							string targetRootDirectory = Server.MapPath("~/photos");
							string targetDirectory = targetRootDirectory + System.IO.Path.DirectorySeparatorChar + albumID + System.IO.Path.DirectorySeparatorChar;


							Response.Write("&nbsp;&nbsp;&nbsp;&nbsp;Processing " + fileName + " ...<br>");
							try
							{
								Directory.CreateDirectory(targetDirectory);
							}
							catch
							{
								// Do nothing.
							}

							File.Move(sourceFiles[i], targetDirectory + pictureID);

							Response.Write("&nbsp;&nbsp;&nbsp;&nbsp;Cleaning up cache files...<br>");
							CleanOldCacheFiles(hashedFileName);

						}
					}
				}
				Response.Flush();
			}
			Response.Write("Done.");
			Response.Flush();
		}

		private void CleanOldCacheFiles(string hashedFileName)
		{
			string sourceDirectory = Server.MapPath("~/photos/");
			string[] cacheFiles = Directory.GetFiles(sourceDirectory, hashedFileName + ".jpg.*");


			Response.Write("&nbsp;&nbsp;&nbsp;&nbsp;" + cacheFiles.Length + " cache file(s) to clean...<br>");
			for (int i = 0; i < cacheFiles.Length; i++)
			{
				File.Delete(cacheFiles[i]);
			}

		}

		private string GenerateUniqueFileName(string fileName)
		{
			MD5 md5				= new MD5CryptoServiceProvider();
			StreamReader reader	= new StreamReader(fileName);
			System.Guid g		= new System.Guid((System.Byte[])md5.ComputeHash(reader.BaseStream));


			reader.Close();

			return g.ToString();
		}

	}
}
