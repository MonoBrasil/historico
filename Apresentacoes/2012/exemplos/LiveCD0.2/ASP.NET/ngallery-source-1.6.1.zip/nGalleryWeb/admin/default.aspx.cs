#region Copyright and License
/*
Copyright 2003 Jason Alexander, nGallery.org
Design work copyright Thomas Johansen (http://www.aylarsolutions.com/)

GOTDOTNET WORKSPACES COMMERCIAL DERIVATIVES LICENSE
Copyright (C) 2003 Microsoft Corporation

You can use this Software for any commercial or noncommercial purpose, 
including distributing derivative works.

In return, we simply require that you agree:

1. Not to remove any copyright notices from the Software. 
2. That if you distribute the Software in source code form you do so only 
   under this License (i.e. you must include a complete copy of this License 
   with your distribution), and if you distribute the Software solely in 
   object form you only do so under a license that complies with this License. 
3. That the Software comes "as is", with no warranties. None whatsoever. This 
   means no express, implied or statutory warranty, including without 
   limitation, warranties of merchantability or fitness for a particular 
   purpose or any warranty of noninfringement. Also, you must pass this 
   disclaimer on whenever you distribute the Software.
4. That neither Microsoft nor any contributor to the Software will be liable 
   for any of those types of damages known as indirect, special, consequential, 
   or incidental related to the Software or this License, to the maximum extent 
   the law permits, no matter what legal theory it�s based on. Also, you must 
   pass this limitation of liability on whenever you distribute the Software.
5. That if you sue anyone over patents that you think may apply to the 
   Software for a person's use of the Software, your license to the Software 
   ends automatically. 
6. That the patent rights, if any, licensed hereunder only apply to the 
   Software, not to any derivative works you make. 
7. That your rights under this License end automatically if you breach it in 
   any way.
*/
#endregion
using System;
using System.Collections;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace nGallery.admin
{
	/// <summary>
	/// Summary description for _default.
	/// </summary>
	public class _default : nGallery.nGalleryPage
	{
		protected System.Web.UI.WebControls.DataGrid dgAlbums;
		
		private void Page_Load(object sender, System.EventArgs e)
		{
			nGallery.Lib.BL galleryBL = new nGallery.Lib.BL(Server.MapPath(nGallery.Lib.Configuration.Instance().DataDirectory));


			nGallery.Lib.AlbumCollection albums = galleryBL.GetAlbums();
			HyperLinkColumn colEdit		= new HyperLinkColumn();
			HyperLinkColumn colDelete	= new HyperLinkColumn();
			
			
			// Configure the data grid.
			//dgAlbums.Width			= Unit.Percentage(80);
			dgAlbums.DataSource		= albums;
			dgAlbums.AlternatingItemStyle.BackColor = Color.LightGoldenrodYellow;
			
			
			// Configure the header style.
			dgAlbums.HeaderStyle.BackColor			= Color.LightGray;
			dgAlbums.HeaderStyle.HorizontalAlign	= HorizontalAlign.Center;
			dgAlbums.HeaderStyle.Font.Name = "Arial";
			dgAlbums.HeaderStyle.Font.Size = FontUnit.Point(10);
			dgAlbums.HeaderStyle.Font.Bold = true;

			// Configure the item style.
			dgAlbums.ItemStyle.HorizontalAlign	= HorizontalAlign.Center;
			dgAlbums.ItemStyle.VerticalAlign	= VerticalAlign.Top;
			dgAlbums.ItemStyle.Font.Name = "Arial";
			dgAlbums.ItemStyle.Font.Size = FontUnit.Point(10);
	

			// Bind the grid
			dgAlbums.DataBind();


		}

		protected int GetPictureCount(object dataItem)
		{
			nGallery.Lib.Album currentAlbum = (nGallery.Lib.Album) dataItem;


			return currentAlbum.Pictures.Count;
		}


		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

	}
}
