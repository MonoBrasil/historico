using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using FreeTextBoxControls;

namespace nGallery.admin
{
	/// <summary>
	/// Summary description for createInvitation.
	/// </summary>
	public class createInvitation : System.Web.UI.Page
	{
		protected DropDownList ddAlbums;
		protected ListBox lbRecipients;
		protected FreeTextBox txtMessage;
		protected Button btnCreate;
		protected Button btnCancel;
		protected Label lblStatus;

		private nGallery.Lib.BL _galleryBL;


		private void Page_Load(object sender, System.EventArgs e)
		{
			_galleryBL =  new nGallery.Lib.BL(Server.MapPath(nGallery.Lib.Configuration.Instance().DataDirectory), Server.MapPath(nGallery.Lib.Configuration.Instance().PhotosDirectory));

			lbRecipients.SelectionMode = ListSelectionMode.Multiple;
			lblStatus.ForeColor = Color.Red;


			if (!this.IsPostBack)
			{
				LoadAlbums();	
				LoadRecipients();
			}
		}

		private void LoadAlbums()
		{
			nGallery.Lib.AlbumCollection albums = _galleryBL.GetAlbums();


			for (int i = 0; i < albums.Count; i++)
			{
				ddAlbums.Items.Add(new ListItem(albums[i].Name, albums[i].ID.ToString()));
			}

		}

		private void LoadRecipients()
		{
			nGallery.Lib.ContactCollection contacts = _galleryBL.GetContacts();


			for (int i = 0; i < contacts.Count; i++)
			{
				lbRecipients.Items.Add(new ListItem(contacts[i].LastName + ", " + contacts[i].FirstName, contacts[i].ID.ToString()));
			}
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

			this.btnCreate.Click += new EventHandler(btnCreate_Click);
			this.btnCancel.Click += new EventHandler(btnCancel_Click);
		}
		#endregion

		private void btnCreate_Click(object sender, EventArgs e)
		{
			nGallery.Lib.Invitation invite = new nGallery.Lib.Invitation();


			if (ddAlbums.SelectedItem == null)
			{
				lblStatus.Text = "You must select the album to send an invitation to.";
				return;
			}

			if (lbRecipients.SelectedItem == null)
			{
				lblStatus.Text = "You must select at least one recipient to send the invitation to.";
				return;
			}

			invite.ID		= _galleryBL.GetNextInvitationID();
			invite.AlbumID	= int.Parse(ddAlbums.SelectedValue);

			for (int i = 0; i < lbRecipients.Items.Count; i++)
			{
				if (lbRecipients.Items[i].Selected)
				{
					invite.AddRecipient(int.Parse(lbRecipients.Items[i].Value));
				}
			}

			invite.Message		= txtMessage.Text;
			invite.CreateDate	= DateTime.Now;
			
			_galleryBL.CreateInvitation(invite);


			try
			{
				_galleryBL.ProcessInvitation(invite, this);
			}
			catch (Exception exc)
			{
				lblStatus.Text = "There was an error while attempting to send your message: " + exc.Message;

				if (exc.InnerException != null)
				{
					lblStatus.Text = lblStatus.Text + "<br>Some additional info, if necessary: " + exc.InnerException.Message;

					if (exc.InnerException.InnerException != null)
					{
						lblStatus.Text = lblStatus.Text + "<br>Some additional info, if necessary: " + exc.InnerException.InnerException.Message;
					}
				}

				return;
			}

			Response.Redirect("invitations.aspx");

		}

		private void btnCancel_Click(object sender, EventArgs e)
		{
			Response.Redirect("invitations.aspx");
		}

		
	}
}

