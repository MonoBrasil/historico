using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace nGallery.admin
{
	/// <summary>
	/// Summary description for deleteInvitation.
	/// </summary>
	public class deleteInvitation : System.Web.UI.Page
	{

		private int _inviteID;
		private nGallery.Lib.BL _galleryBL;

		private void Page_Load(object sender, System.EventArgs e)
		{
			_galleryBL = new nGallery.Lib.BL(Server.MapPath(nGallery.Lib.Configuration.Instance().DataDirectory));

			
			if (Request.QueryString["InviteID"] != null)
			{
				try
				{
					_inviteID  = int.Parse(Request.QueryString["InviteID"]);
				}
				catch 
				{
					Response.Redirect("invitations.aspx");
				}
			}
			else
			{
				Response.Redirect("invitations.aspx");
			}

			_galleryBL.DeleteInvitation(_inviteID);

			Response.Redirect("invitations.aspx");
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);
		}
		#endregion
	}
}
