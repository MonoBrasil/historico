#region Copyright and License
/*
Copyright 2003 Jason Alexander, nGallery.org
Design work copyright Thomas Johansen (http://www.aylarsolutions.com/)

GOTDOTNET WORKSPACES COMMERCIAL DERIVATIVES LICENSE
Copyright (C) 2003 Microsoft Corporation

You can use this Software for any commercial or noncommercial purpose, 
including distributing derivative works.

In return, we simply require that you agree:

1. Not to remove any copyright notices from the Software. 
2. That if you distribute the Software in source code form you do so only 
   under this License (i.e. you must include a complete copy of this License 
   with your distribution), and if you distribute the Software solely in 
   object form you only do so under a license that complies with this License. 
3. That the Software comes "as is", with no warranties. None whatsoever. This 
   means no express, implied or statutory warranty, including without 
   limitation, warranties of merchantability or fitness for a particular 
   purpose or any warranty of noninfringement. Also, you must pass this 
   disclaimer on whenever you distribute the Software.
4. That neither Microsoft nor any contributor to the Software will be liable 
   for any of those types of damages known as indirect, special, consequential, 
   or incidental related to the Software or this License, to the maximum extent 
   the law permits, no matter what legal theory it�s based on. Also, you must 
   pass this limitation of liability on whenever you distribute the Software.
5. That if you sue anyone over patents that you think may apply to the 
   Software for a person's use of the Software, your license to the Software 
   ends automatically. 
6. That the patent rights, if any, licensed hereunder only apply to the 
   Software, not to any derivative works you make. 
7. That your rights under this License end automatically if you breach it in 
   any way.
*/
#endregion
using System;
using System.Text;
using System.Collections;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using nGallery.Lib;

namespace nGallery
{
	/// <summary>
	/// Summary description for rss.
	/// </summary>
	public class rss : System.Web.UI.Page
	{
		private void Page_Load(object sender, System.EventArgs e)
		{
			nGallery.Lib.Definitions.SortOrder sortOrder = nGallery.Lib.Definitions.SortOrder.DATE_ASCENDING;
			StringBuilder baseURI			= new StringBuilder();
			StringBuilder linkDestination	= new StringBuilder();
			nGallery.Lib.BL galleryBL	    = new nGallery.Lib.BL(Server.MapPath(nGallery.Lib.Configuration.Instance().DataDirectory));


			// Build the link URL.
			baseURI.Append("http://" + this.Request.ServerVariables["SERVER_NAME"]);

			if (this.Request.ServerVariables["SERVER_PORT"] != "80")
			{
				baseURI.Append(":" + this.Request.ServerVariables["SERVER_PORT"]);
			}

			linkDestination.Append(baseURI.ToString() + this.Request.ServerVariables["SCRIPT_NAME"].Replace("rss.aspx", ""));


			// Sorting
			if (Request.QueryString["so"] != null)
			{
				try
				{
					sortOrder = (nGallery.Lib.Definitions.SortOrder) int.Parse(Request.QueryString["so"]);
					
				}
				catch
				{
					// Do nothing
				}

			}

			// RSS 
			Rss.RssFeed feed = new Rss.RssFeed();
			RSS RSSGen = new RSS(galleryBL, this.Page);

			if((Request.QueryString["AlbumID"] != null) && (Request.QueryString["PictureID"] != null))
			{
				int AlbumID = Convert.ToInt32(Request.QueryString["AlbumID"].ToString());
				int PictureID = Convert.ToInt32(Request.QueryString["PictureID"].ToString());
				
				feed = RSSGen.GetPictureComments(AlbumID, PictureID, new System.Uri(linkDestination.ToString()), sortOrder);
			}
			else if (Request.QueryString["AlbumID"] != null)
			{
				int AlbumID = Convert.ToInt32(Request.QueryString["AlbumID"].ToString());
				
				feed = RSSGen.GetAlbumPictures(AlbumID, new System.Uri(linkDestination.ToString()), sortOrder);
			} 
			else 
			{
				feed = RSSGen.GetAlbums(new System.Uri(linkDestination.ToString()), sortOrder);
			}
			
			Response.ContentType = "text/xml";
			feed.Write(Response.OutputStream);
			Response.End();

		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);
		}
		#endregion
	}
}
