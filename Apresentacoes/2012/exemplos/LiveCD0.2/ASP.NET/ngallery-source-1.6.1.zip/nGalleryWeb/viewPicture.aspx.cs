#region Copyright and License
/*
Copyright 2003 Jason Alexander, nGallery.org
Design work copyright Thomas Johansen (http://www.aylarsolutions.com/)

GOTDOTNET WORKSPACES COMMERCIAL DERIVATIVES LICENSE
Copyright (C) 2003 Microsoft Corporation

You can use this Software for any commercial or noncommercial purpose, 
including distributing derivative works.

In return, we simply require that you agree:

1. Not to remove any copyright notices from the Software. 
2. That if you distribute the Software in source code form you do so only 
   under this License (i.e. you must include a complete copy of this License 
   with your distribution), and if you distribute the Software solely in 
   object form you only do so under a license that complies with this License. 
3. That the Software comes "as is", with no warranties. None whatsoever. This 
   means no express, implied or statutory warranty, including without 
   limitation, warranties of merchantability or fitness for a particular 
   purpose or any warranty of noninfringement. Also, you must pass this 
   disclaimer on whenever you distribute the Software.
4. That neither Microsoft nor any contributor to the Software will be liable 
   for any of those types of damages known as indirect, special, consequential, 
   or incidental related to the Software or this License, to the maximum extent 
   the law permits, no matter what legal theory it�s based on. Also, you must 
   pass this limitation of liability on whenever you distribute the Software.
5. That if you sue anyone over patents that you think may apply to the 
   Software for a person's use of the Software, your license to the Software 
   ends automatically. 
6. That the patent rights, if any, licensed hereunder only apply to the 
   Software, not to any derivative works you make. 
7. That your rights under this License end automatically if you breach it in 
   any way.
*/
#endregion
using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Configuration;

namespace nGallery
{
	/// <summary>
	/// Summary description for viewPhoto.
	/// </summary>
	public class viewPicture : nGallery.nGalleryPage
	{
		protected System.Web.UI.WebControls.PlaceHolder phTopNavigation;
		protected System.Web.UI.WebControls.PlaceHolder phMainContent;
		protected System.Web.UI.WebControls.PlaceHolder phComments;
		protected System.Web.UI.WebControls.PlaceHolder phCommentsForm;
		protected System.Web.UI.WebControls.PlaceHolder phStats;
		protected System.Web.UI.WebControls.PlaceHolder phRating;
		protected System.Web.UI.WebControls.PlaceHolder phBottomNavigation;
		protected System.Web.UI.WebControls.PlaceHolder phEXIF;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			string albumName									= "Unknown";
			int albumID											= 0;
			int pictureID										= 0;
			int prevPictureID									= 0;
			int nextPictureID									= 0;
			nGallery.Lib.ControlPictureDetails pictureDetails	= new nGallery.Lib.ControlPictureDetails();
			nGallery.Lib.ControlCommentListing commentListing	= new nGallery.Lib.ControlCommentListing();
			nGallery.Lib.ControlCommentForm commentForm			= new nGallery.Lib.ControlCommentForm();
			nGallery.Lib.ControlPictureRating pictureRating		= new nGallery.Lib.ControlPictureRating();
			nGallery.Lib.ControlNavigation topNav				= new nGallery.Lib.ControlNavigation(nGallery.Lib.Definitions.NavigationType.NAV_PICTURE_DETAILS);
			nGallery.Lib.ControlNavigation bottomNav			= new nGallery.Lib.ControlNavigation(nGallery.Lib.Definitions.NavigationType.NAV_PICTURE_DETAILS);
			nGallery.Lib.BL galleryBL							= new nGallery.Lib.BL(Server.MapPath(nGallery.Lib.Configuration.Instance().DataDirectory));
			nGallery.Lib.ControlEXIF exif;
			nGallery.Lib.Picture picture;
			nGallery.Lib.CommentCollection pictureComments;


			nGallery.Lib.Util.CheckSitePassword(this);

			if (Request.QueryString["albumID"] != null)
			{
				try
				{
					albumID = int.Parse(Request.QueryString["albumID"]);
				}
				catch
				{
					Response.Redirect("default.aspx");
				}
			}
			else
			{
				Response.Redirect("default.aspx");
			}

			if (Request.QueryString["pictureID"] != null)
			{
				try
				{
					pictureID = int.Parse(Request.QueryString["pictureID"]);
				}
				catch
				{
					Response.Redirect("default.aspx");
				}
			}
			else
			{
				Response.Redirect("default.aspx");
			}

			if (Request.QueryString["albumName"] != null)
			{
				albumName = Request.QueryString["albumName"];
			}


			prevPictureID = galleryBL.GetPreviousPictureID(albumID, pictureID);
			nextPictureID = galleryBL.GetNextActualPictureID(albumID, pictureID);

			// Load up the picture and give it to the picture details control.
			picture = galleryBL.GetPicture(albumID, pictureID);

			pictureDetails.AlbumID	= albumID;
			pictureDetails.AlbumName = albumName;
			pictureDetails.Picture	= picture;
			pictureDetails.PrevPictureID = prevPictureID;
			pictureDetails.NextPictureID = nextPictureID;
			
			// Update the picture's view count
			galleryBL.UpdateViewCount(albumID, pictureID);

			// Set the navigation properties.
			topNav.AlbumID			= albumID;
			topNav.AlbumName		= albumName;
			topNav.PictureTitle		= picture.Title;

			bottomNav.AlbumID		= albumID;
			bottomNav.AlbumName		= albumName;
			bottomNav.PictureTitle	= picture.Title;
			

			phTopNavigation.Controls.Add(topNav);
			phMainContent.Controls.Add(pictureDetails);

			// Only put the stats control out if it's enabled.
			if (nGallery.Lib.Configuration.Instance().EnableStats)
			{
				nGallery.Lib.ControlPictureStats pictureStats = new nGallery.Lib.ControlPictureStats();

				pictureStats.CurrentPicture = picture;

				phStats.Controls.Add(pictureStats);
			}

			// Only work with the rating stuff if it has been enabled.
			if (nGallery.Lib.Configuration.Instance().EnableRatings)
			{
				// Get the picture rating
				pictureRating.Rating	= galleryBL.GetPictureRating(albumID, pictureID);
				pictureRating.AlbumID	= albumID;
				pictureRating.PictureID	= pictureID;

				// Add the rating control to the placeholder.
				phRating.Controls.Add(pictureRating);
			}

			//Get EXIF information and write it out.
			if (nGallery.Lib.Configuration.Instance().EnableExif)
			{
				exif = new nGallery.Lib.ControlEXIF(Server.MapPath(nGallery.Lib.Configuration.Instance().PhotosDirectory)  + albumID.ToString() + System.IO.Path.DirectorySeparatorChar + picture.ID.ToString());
				phEXIF.Controls.Add(exif);
			}

			// Only work with the comments if they've been enabled.
			if (nGallery.Lib.Configuration.Instance().EnableComments)
			{
				// Configure the comment form.
				commentForm.AlbumID		= albumID;
				commentForm.PictureID	= pictureID;

				// Get the picture's comments.
				pictureComments = galleryBL.GetPictureComments(albumID, pictureID);

				commentListing.Comments = pictureComments;

				// Add the comment controls to their respective place holders.
				phComments.Controls.Add(commentListing);
				phComments.Controls.Add(commentForm);
			}

			phBottomNavigation.Controls.Add(bottomNav);

		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
