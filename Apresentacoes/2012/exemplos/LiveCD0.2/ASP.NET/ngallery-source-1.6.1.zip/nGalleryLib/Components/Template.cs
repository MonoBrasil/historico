#region Copyright and License
/*
Copyright 2003 Jason Alexander, nGallery.org
Design work copyright Thomas Johansen (http://www.aylarsolutions.com/)

GOTDOTNET WORKSPACES COMMERCIAL DERIVATIVES LICENSE
Copyright (C) 2003 Microsoft Corporation

You can use this Software for any commercial or noncommercial purpose, 
including distributing derivative works.

In return, we simply require that you agree:

1. Not to remove any copyright notices from the Software. 
2. That if you distribute the Software in source code form you do so only 
   under this License (i.e. you must include a complete copy of this License 
   with your distribution), and if you distribute the Software solely in 
   object form you only do so under a license that complies with this License. 
3. That the Software comes "as is", with no warranties. None whatsoever. This 
   means no express, implied or statutory warranty, including without 
   limitation, warranties of merchantability or fitness for a particular 
   purpose or any warranty of noninfringement. Also, you must pass this 
   disclaimer on whenever you distribute the Software.
4. That neither Microsoft nor any contributor to the Software will be liable 
   for any of those types of damages known as indirect, special, consequential, 
   or incidental related to the Software or this License, to the maximum extent 
   the law permits, no matter what legal theory it�s based on. Also, you must 
   pass this limitation of liability on whenever you distribute the Software.
5. That if you sue anyone over patents that you think may apply to the 
   Software for a person's use of the Software, your license to the Software 
   ends automatically. 
6. That the patent rights, if any, licensed hereunder only apply to the 
   Software, not to any derivative works you make. 
7. That your rights under this License end automatically if you breach it in 
   any way.
*/
#endregion
using System;
using System.Configuration;
using System.Text;
using System.IO;
using System.Web;
using System.Collections;
using System.Collections.Specialized;


namespace nGallery.Lib
{


	/// <summary>
	/// This class handles all HTML templates and the replacing of template variables.
	/// </summary>
	public class Template
	{


		#region Private Members


		private StringBuilder templateFile;


		#endregion


		#region Constructor(s)


		/// <summary>
		/// Constructor that initializes an empty template file.
		/// </summary>
		public Template()
		{
			templateFile = new StringBuilder("");
		}

		/// <summary>
		/// Basic constructor to open the specified template.
		/// </summary>
		/// <param name="templateName">The name of the template to open (from nGalleryLib.Definitions.Templates)</param>
		/// <param name="hostPage">The page to display it on.  Used for caching purposes.</param>
		public Template(string templateName, System.Web.UI.Page hostPage)
		{
			templateFile = new StringBuilder(Template.GetTemplate(templateName, hostPage));
		}


		#endregion


		#region Public Methods


		/// <summary>
		/// Processes the given template variable and any functions that go along with it.
		/// </summary>
		/// <param name="templateVar">Name of template variable (from nGalleryLib.Definitions.TemplateVariables)</param>
		/// <param name="value">Value of the template variable.</param>
		public void ProcessesVariable(string templateVar, string value)
		{
			// First get rid of instances with no modifiers... makes it a little faster
			templateFile.Replace(templateVar, value);

			// Get the string and locate the first instance with a modifier
			string partialVar = templateVar.Substring(0, templateVar.Length-2) + "|";
			string textOutput = templateFile.ToString();
			int start = textOutput.IndexOf(partialVar);

			// Loop through and find all instances with a modifier
			while(start != -1)
			{
				// Get the list of modifiers to process
				string varFuncs = textOutput.Substring(start + partialVar.Length, textOutput.IndexOf("$]", start) - start - partialVar.Length);
				string valueMod = value;

				// Loop through the modifiers
				foreach (string func in varFuncs.Split(new Char [] {'|'}))
				{
					switch(func.ToUpper()) 
					{
						case "UPPER":
							valueMod = valueMod.ToUpper();
							break;
						case "LOWER":
							valueMod = valueMod.ToLower();
							break;
						case "ESCAPE":
							valueMod = valueMod.Replace("'", "\\'");
							break;
						case "DOUBLEESCAPE":
							valueMod = valueMod.Replace("\"", "\\\"");
							break;
						case "ENCODE":
							valueMod = HttpUtility.UrlEncode(valueMod);
							break;
					}
				}

				// Replace in template and refetch the string and next location
				templateFile.Replace(partialVar + varFuncs + "$]", valueMod);
				textOutput = templateFile.ToString();
				start = textOutput.IndexOf(partialVar);
			}
		}

		/// <summary>
		/// Processes the given template variable and any functions that go along with it.
		/// </summary>
		/// <param name="templateVar">Name of template variable (from nGalleryLib.Definitions.TemplateVariables)</param>
		/// <param name="value">Value of the template variable.</param>
		public void ProcessesVariable(string templateVar, int value)
		{
			// First get rid of instances with no modifiers... makes it a little faster
			templateFile.Replace(templateVar, value.ToString());

			// Get the string and locate the first instance with a modifier
			string partialVar = templateVar.Substring(0, templateVar.Length-2) + "|";
			string textOutput = templateFile.ToString();
			int start = textOutput.IndexOf(partialVar);

			// Loop through and find all instances with a modifier
			while(start != -1)
			{
				// Get the list of modifiers to process
				string varFuncs = textOutput.Substring(start + partialVar.Length, textOutput.IndexOf("$]", start) - start - partialVar.Length);
				int valueMod = value;

				// Loop through the modifiers
				foreach (string func in varFuncs.Split(new Char [] {'|'}))
				{
					switch(func.Substring(0, ((func.IndexOf(":") == -1) ? func.Length : func.IndexOf(":")) ).ToUpper())
					{
						case "DIV":
							valueMod = valueMod / int.Parse(func.Substring(func.IndexOf(":")+1));
							break;
						case "MUL":
							valueMod = valueMod * int.Parse(func.Substring(func.IndexOf(":")+1));
							break;
						case "ADD":
							valueMod = valueMod + int.Parse(func.Substring(func.IndexOf(":")+1));
							break;
						case "SUB":
							valueMod = valueMod - int.Parse(func.Substring(func.IndexOf(":")+1));
							break;
					}
				}

				// Replace in template and refetch the string and next location
				templateFile.Replace(partialVar + varFuncs + "$]", valueMod.ToString());
				textOutput = templateFile.ToString();
				start = textOutput.IndexOf(partialVar);
			}
		}

		/// <summary>
		/// Appends a string to the end of the template.
		/// </summary>
		/// <param name="value">The string to append.</param>
		public void Append(string value)
		{
			templateFile.Append(value);
		}

		/// <summary>
		/// Returns a string value of the template page.
		/// </summary>
		/// <returns>string</returns>
		public string GetString()
		{
			return templateFile.ToString();
		}

		/// <summary>
		/// This method attempts to locate the given template, first in cache, and if it's not loaded into
		/// cache, it attempts to retrieve it from the file system in the template directory (configured in
		/// the web.config). If successful, the file is read in (containing HTML, usually) and then cached 
		/// for later use.
		/// </summary>
		/// <param name="templateName">The name of the template file. Also used for the cache key</param>
		/// <param name="hostPage">An instance of the page requesting the template</param>
		/// <returns>string</returns>
		public static string GetTemplate(string templateName, System.Web.UI.Page hostPage)
		{
			System.Text.StringBuilder textOutput = new System.Text.StringBuilder();
			string returnValue			= "";
			string cacheName			= "";
			string skinName				= "";
			string templateDirectory	= "";


			cacheName			= "ngallery." + templateName;
			skinName			= nGallery.Lib.Configuration.Instance().SiteSkin;
			templateDirectory	= hostPage.Server.MapPath(nGallery.Lib.Configuration.Instance().TemplateDirectory + "/" + skinName);


			try
			{
				// TODO: Add custom exception for Template not found
				// Attempt to get the template out of cache.
				textOutput = (System.Text.StringBuilder) hostPage.Cache.Get(cacheName);

				// If it's not there, rebuild it.
				if (textOutput == null)
				{
					string filePath = templateDirectory + System.IO.Path.DirectorySeparatorChar + templateName;
					
					System.IO.StreamReader objReader = new System.IO.StreamReader(filePath);
					textOutput = new System.Text.StringBuilder();
				
					// Build the HTML string.
					textOutput.Append(objReader.ReadToEnd());
					objReader.Close();

					hostPage.Cache.Insert(cacheName, textOutput, new System.Web.Caching.CacheDependency(filePath));
				}	

				returnValue = textOutput.ToString();
			}
			catch (Exception exc)
			{
				try
				{
					hostPage.Response.Write("Error loading a template file: " + templateName + " from " + templateDirectory + ".<br>" +
						"Please check the permissions on the directory and try again.<br><br>" + 
						"Exception was: " + exc.Message);
					hostPage.Response.End();
				}
				catch
				{
				}
			}

			return returnValue;
		}


		#endregion


	}

}