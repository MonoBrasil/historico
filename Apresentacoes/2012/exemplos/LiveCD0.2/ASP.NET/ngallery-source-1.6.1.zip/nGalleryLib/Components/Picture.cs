#region Copyright and License
/*
Copyright 2003 Jason Alexander, nGallery.org
Design work copyright Thomas Johansen (http://www.aylarsolutions.com/)

GOTDOTNET WORKSPACES COMMERCIAL DERIVATIVES LICENSE
Copyright (C) 2003 Microsoft Corporation

You can use this Software for any commercial or noncommercial purpose, 
including distributing derivative works.

In return, we simply require that you agree:

1. Not to remove any copyright notices from the Software. 
2. That if you distribute the Software in source code form you do so only 
   under this License (i.e. you must include a complete copy of this License 
   with your distribution), and if you distribute the Software solely in 
   object form you only do so under a license that complies with this License. 
3. That the Software comes "as is", with no warranties. None whatsoever. This 
   means no express, implied or statutory warranty, including without 
   limitation, warranties of merchantability or fitness for a particular 
   purpose or any warranty of noninfringement. Also, you must pass this 
   disclaimer on whenever you distribute the Software.
4. That neither Microsoft nor any contributor to the Software will be liable 
   for any of those types of damages known as indirect, special, consequential, 
   or incidental related to the Software or this License, to the maximum extent 
   the law permits, no matter what legal theory it�s based on. Also, you must 
   pass this limitation of liability on whenever you distribute the Software.
5. That if you sue anyone over patents that you think may apply to the 
   Software for a person's use of the Software, your license to the Software 
   ends automatically. 
6. That the patent rights, if any, licensed hereunder only apply to the 
   Software, not to any derivative works you make. 
7. That your rights under this License end automatically if you breach it in 
   any way.
*/
#endregion
using System;
using System.Drawing;

namespace nGallery.Lib
{
	/// <summary>
	/// The Picture class holds all information that pertains to a given photo in an album.
	/// Pictures are held in a PictureCollection object, which is ultimately held by a Album.
	/// </summary>
	[Serializable]
	public class Picture : BaseGalleryObject
	{
		#region Private Members
		private string		_title;
		private string		_caption;
		private string		_fileName;
		private bool		_highlightPicture;
		private CommentCollection _comments;
		private int			_viewCount;
		private Rating		_rating;
		private int         _height = 0;
		private int         _width = 0;
		#endregion
		
		#region Constructors
		/// <summary>
		/// The base constructor of the Picture object.
		/// </summary>
		public Picture()
		{
			this.ID				= 0;
			this.Title			= "";
			_caption			= "";
			_fileName			= "";
			this.CreateDate		= DateTime.Now;
			_highlightPicture	= false;
			_comments			= new CommentCollection();
			_viewCount			= 0;
			_rating				= new Rating();
		}
		#endregion

		#region Public Properties
		/// <summary>
		/// The title of the picture.
		/// </summary>
		public string Title
		{
			get
			{
				return _title;
			}
			set
			{
				_title = value;
				this.Name = value;
			}
		}

		/// <summary>
		/// The caption to display for the given picture.
		/// </summary>
		public string Caption
		{
			get
			{
				return _caption;
			}
			set
			{
				_caption = value;
			}
		}

		/// <summary>
		/// The file name of the image that this Picture object represents.
		/// </summary>
		public string FileName
		{
			get
			{
				return _fileName;
			}
			set
			{
				_fileName = value;
			}
		}

		/// <summary>
		/// Indicator if this picture should be used as the highlight picture for it's containing album.
		/// </summary>
		public bool HighlightPicture
		{
			get
			{
				return _highlightPicture;
			}
			set
			{
				_highlightPicture = value;
			}
		}

		/// <summary>
		/// The collection of comments that have been made for a specific picture.
		/// </summary>
		public CommentCollection Comments
		{
			get
			{
				return _comments;
			}
			set
			{
				_comments = value;
			}
		}

		/// <summary>
		/// The number of times the picture has been viewed.
		/// </summary>
		public int ViewCount
		{
			get
			{
				return _viewCount;
			}
			set
			{
				_viewCount = value;
			}
		}

		/// <summary>
		/// The rating information for the picture.
		/// </summary>
		public Rating Rating
		{
			get
			{
				return _rating;
			}
			set
			{
				_rating = value;
			}
		}

		/// <summary>
		/// The height of the original image.
		/// </summary>
		public int Height
		{
			get
			{
				return _height;
			}
			set
			{
				_height = value;
			}
		}

		/// <summary>
		/// The width of the original image.
		/// </summary>
		public int Width
		{
			get
			{
				return _width;
			}
			set
			{
				_width = value;
			}
		}
		#endregion


	}
}
