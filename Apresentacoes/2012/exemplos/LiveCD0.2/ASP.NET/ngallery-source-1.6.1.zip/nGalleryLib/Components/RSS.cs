#region Copyright and License
/*
Copyright 2003 Jason Alexander, nGallery.org
Design work copyright Thomas Johansen (http://www.aylarsolutions.com/)

GOTDOTNET WORKSPACES COMMERCIAL DERIVATIVES LICENSE
Copyright (C) 2003 Microsoft Corporation

You can use this Software for any commercial or noncommercial purpose, 
including distributing derivative works.

In return, we simply require that you agree:

1. Not to remove any copyright notices from the Software. 
2. That if you distribute the Software in source code form you do so only 
   under this License (i.e. you must include a complete copy of this License 
   with your distribution), and if you distribute the Software solely in 
   object form you only do so under a license that complies with this License. 
3. That the Software comes "as is", with no warranties. None whatsoever. This 
   means no express, implied or statutory warranty, including without 
   limitation, warranties of merchantability or fitness for a particular 
   purpose or any warranty of noninfringement. Also, you must pass this 
   disclaimer on whenever you distribute the Software.
4. That neither Microsoft nor any contributor to the Software will be liable 
   for any of those types of damages known as indirect, special, consequential, 
   or incidental related to the Software or this License, to the maximum extent 
   the law permits, no matter what legal theory it�s based on. Also, you must 
   pass this limitation of liability on whenever you distribute the Software.
5. That if you sue anyone over patents that you think may apply to the 
   Software for a person's use of the Software, your license to the Software 
   ends automatically. 
6. That the patent rights, if any, licensed hereunder only apply to the 
   Software, not to any derivative works you make. 
7. That your rights under this License end automatically if you breach it in 
   any way.
*/
#endregion
using System;
using System.Text;
using System.Web;

namespace nGallery.Lib
{
	/// <summary>
	/// Summary description for RSS.
	/// </summary>
	public class RSS
	{
		

		#region Private Members


		private Rss.RssFeed rfAlbums;
		private Rss.RssFeed rfAlbumPictures;
		private Rss.RssFeed rfPictureComments;
		private System.Web.UI.Page page;
		private nGallery.Lib.BL galleryBL;


		#endregion


		#region Constructor(s)


		public RSS(nGallery.Lib.BL blGallery, System.Web.UI.Page Page)
		{
			galleryBL = blGallery;
			page = Page;
		}


		#endregion


		#region Public Methods


		public Rss.RssFeed GetAlbums(System.Uri uriBaseUri, nGallery.Lib.Definitions.SortOrder soOrder)
		{

			// Create channel
			Rss.RssChannel channel = new Rss.RssChannel();

			// RSS header
			channel.Title = nGallery.Lib.Configuration.Instance().SiteTitle;
			channel.Description = "nGallery photo album";
			channel.Link = uriBaseUri;

			// RSS Items
			nGallery.Lib.AlbumCollection albums = galleryBL.GetAlbums();

			albums.Sort(new GenericSorter(soOrder));

			foreach (nGallery.Lib.Album myAlbum in albums)
			{
				Rss.RssItem item = new Rss.RssItem();
	 
				item.Title = (myAlbum.Name != "") ? myAlbum.Name : "No Title";
				item.Description = (myAlbum.Description != "") ? myAlbum.Description : "No Description";
				item.PubDate = myAlbum.CreateDate;
				//item.Comments = BaseUri.ToString() + "rss.aspx?AlbumID=" + myAlbum.ID.ToString();

				if (Configuration.Instance().AlbumRewriting == RewriteType.ById)
					item.Link = new System.Uri(uriBaseUri.ToString() + "albums/" + myAlbum.ID.ToString() + ".aspx");
				else if (Configuration.Instance().AlbumRewriting == RewriteType.ByName)
					item.Link = new System.Uri(uriBaseUri.ToString() + "albums/" + page.Server.UrlEncode(myAlbum.Name) + ".aspx");

				channel.Items.Add(item);

			}
			if (channel.Items.Count <=0)
			{
				Rss.RssItem item = new Rss.RssItem();
	 
				item.Title = "No Albums";
				item.Description = "No Albums";

				channel.Items.Add(item);
			}


			rfAlbums = new Rss.RssFeed();
			rfAlbums.Channels.Add(channel);

			return rfAlbums;

		}

		public Rss.RssFeed GetAlbumPictures(int myAlbumID, System.Uri uriBaseUri, nGallery.Lib.Definitions.SortOrder soOrder)
		{

			// Create channel
			Rss.RssChannel channel = new Rss.RssChannel();

			// Album
			nGallery.Lib.Album album = galleryBL.GetAlbum(myAlbumID);

			// RSS header
			channel.Title = nGallery.Lib.Configuration.Instance().SiteTitle;
			channel.Description = album.Name;

			if (Configuration.Instance().AlbumRewriting == RewriteType.ById)
				channel.Link = new System.Uri(uriBaseUri.ToString() + "albums/" + album.ID.ToString() + ".aspx");
			else if (Configuration.Instance().AlbumRewriting == RewriteType.ByName)
				channel.Link = new System.Uri(uriBaseUri.ToString() + "albums/" + page.Server.UrlEncode(album.Name) + ".aspx");

			// RSS Items
			nGallery.Lib.PictureCollection pictures = galleryBL.GetAlbumPictures(album.ID);
			pictures.Sort(new GenericSorter(soOrder));

			foreach (nGallery.Lib.Picture myPicture in pictures)
			{
				Rss.RssItem item = new Rss.RssItem();
	 
				item.Title = (myPicture.Name != "") ? myPicture.Name : "No Title";
				item.Description = (myPicture.Caption != "") ? myPicture.Caption : "No Description";
				item.PubDate = myPicture.CreateDate;

				if (Configuration.Instance().AlbumRewriting == RewriteType.ById)
					item.Link = new System.Uri(uriBaseUri.ToString() + "albums/" + album.ID.ToString() + "/" + myPicture.ID.ToString() + ".aspx");
				else if (Configuration.Instance().AlbumRewriting == RewriteType.ByName)
					item.Link = new System.Uri(uriBaseUri.ToString() + "albums/" + page.Server.UrlEncode(album.Name) + "/" + myPicture.ID.ToString() + ".aspx");
	 
				channel.Items.Add(item);

			}
			if (channel.Items.Count <=0)
			{
				Rss.RssItem item = new Rss.RssItem();
	 
				item.Title = "No Pictures";
				item.Description = "No Pictures";

				channel.Items.Add(item);
			}

			rfAlbumPictures = new Rss.RssFeed();
			rfAlbumPictures.Channels.Add(channel);

			return rfAlbumPictures;

		}

		public Rss.RssFeed GetPictureComments(int myAlbumID, int myPictureID, System.Uri uriBaseUri, nGallery.Lib.Definitions.SortOrder soOrder)
		{

			// Create channel
			Rss.RssChannel channel = new Rss.RssChannel();

			// Album
			nGallery.Lib.Album album = galleryBL.GetAlbum(myAlbumID);

			// Picture
			nGallery.Lib.Picture picture = galleryBL.GetPicture(album.ID, myPictureID);

			if (picture == null)
			{
				channel.Title = nGallery.Lib.Configuration.Instance().SiteTitle;
				channel.Description = "Invalid Picture ID!";
				channel.Link = new System.Uri(uriBaseUri.ToString());

				Rss.RssFeed blankRss = new Rss.RssFeed();

				Rss.RssItem item = new Rss.RssItem();
	 
				item.Title = "No such picture for the given ID (" + myPictureID + ").";
				item.Description = "No such picture for the given ID (" + myPictureID + ").";

				channel.Items.Add(item);

				blankRss.Channels.Add(channel);

				return blankRss;
			}

			// RSS header
			channel.Title = nGallery.Lib.Configuration.Instance().SiteTitle;
			channel.Description = picture.Title;

			if (Configuration.Instance().AlbumRewriting == RewriteType.ById)
				channel.Link = new System.Uri(uriBaseUri.ToString() + "albums/" + album.ID.ToString() + "/" + picture.ID.ToString() + ".aspx");
			else if (Configuration.Instance().AlbumRewriting == RewriteType.ByName)
				channel.Link = new System.Uri(uriBaseUri.ToString() + "albums/" + page.Server.UrlEncode(album.Name) + "/" + picture.ID.ToString() + ".aspx");

			// RSS Items
			nGallery.Lib.CommentCollection comments = galleryBL.GetPictureComments(album.ID, picture.ID);
			comments.Sort(new GenericSorter(soOrder));

			foreach (nGallery.Lib.Comment myComment in comments)
			{
				Rss.RssItem item = new Rss.RssItem();
	 
				item.Title = (myComment.FromName != "") ? myComment.FromName : "No Name";
				item.Description = (myComment.CommentText != "") ? myComment.CommentText : "No Description";
				item.PubDate = myComment.CreateDate;

				if (Configuration.Instance().AlbumRewriting == RewriteType.ById)
					item.Link = new System.Uri(uriBaseUri.ToString() + "albums/" + album.ID.ToString() + "/" + picture.ID.ToString() + ".aspx#" + myComment.ID.ToString());
				else if (Configuration.Instance().AlbumRewriting == RewriteType.ByName)
					item.Link = new System.Uri(uriBaseUri.ToString() + "albums/" + page.Server.UrlEncode(album.Name) + "/" + picture.ID.ToString() + ".aspx#" + myComment.ID.ToString());
	 
				channel.Items.Add(item);

			}
			if (channel.Items.Count <=0)
			{
				Rss.RssItem item = new Rss.RssItem();
	 
				item.Title = "No Comments";
				item.Description = "No Comments";

				channel.Items.Add(item);
			}

			rfPictureComments = new Rss.RssFeed();
			rfPictureComments.Channels.Add(channel);

			return rfPictureComments;

		}


		#endregion


	}
}
