#region Copyright and License
/*
Copyright 2003 Jason Alexander, nGallery.org
Design work copyright Thomas Johansen (http://www.aylarsolutions.com/)

GOTDOTNET WORKSPACES COMMERCIAL DERIVATIVES LICENSE
Copyright (C) 2003 Microsoft Corporation

You can use this Software for any commercial or noncommercial purpose, 
including distributing derivative works.

In return, we simply require that you agree:

1. Not to remove any copyright notices from the Software. 
2. That if you distribute the Software in source code form you do so only 
   under this License (i.e. you must include a complete copy of this License 
   with your distribution), and if you distribute the Software solely in 
   object form you only do so under a license that complies with this License. 
3. That the Software comes "as is", with no warranties. None whatsoever. This 
   means no express, implied or statutory warranty, including without 
   limitation, warranties of merchantability or fitness for a particular 
   purpose or any warranty of noninfringement. Also, you must pass this 
   disclaimer on whenever you distribute the Software.
4. That neither Microsoft nor any contributor to the Software will be liable 
   for any of those types of damages known as indirect, special, consequential, 
   or incidental related to the Software or this License, to the maximum extent 
   the law permits, no matter what legal theory it�s based on. Also, you must 
   pass this limitation of liability on whenever you distribute the Software.
5. That if you sue anyone over patents that you think may apply to the 
   Software for a person's use of the Software, your license to the Software 
   ends automatically. 
6. That the patent rights, if any, licensed hereunder only apply to the 
   Software, not to any derivative works you make. 
7. That your rights under this License end automatically if you breach it in 
   any way.
*/
#endregion
using System;

namespace nGallery.Lib
{
	/// <summary>
	/// This class is what makes up a comment that's left on a picture.
	/// </summary>
	public class Comment : BaseGalleryObject
	{


		#region Private Members


		private string		_fromName;
		private string		_fromEmailAddr;
		private string		_fromWebURL;
		private string		_commentText;


		#endregion


		#region Constructors


		/// <summary>
		/// The main constructor for the Comment object.
		/// </summary>
		public Comment()
		{
			this.ID			= 0;
			this.FromName	= "";
			_fromEmailAddr	= "";
			_fromWebURL		= "";
			_commentText	= "";
			this.CreateDate	= DateTime.Now;
		}


		#endregion


		#region Public Properties

		/// <summary>
		/// This is equivalent to CreateDate. Kept for backwards compatibility.
		/// </summary>
		public DateTime DateSubmitted
		{
			// TODO: Refactor to remove this all together.
			get
			{
				return this.CreateDate;
			}
			set
			{
				this.CreateDate = value;
			}
		}


		/// <summary>
		/// The name of the person who left the comment.
		/// </summary>
		public string FromName
		{
			get
			{
				return _fromName;
			}
			set
			{
				_fromName = value;
				this.Name = value;
			}
		}


		/// <summary>
		/// The email address of the person who left the comment.
		/// </summary>
		public string FromEmailAddr
		{
			get
			{
				return _fromEmailAddr;
			}
			set
			{
				_fromEmailAddr = value;
			}
		}


		/// <summary>
		/// The Website URL of the person who left the comment.
		/// </summary>
		public string FromWebURL
		{
			get
			{
				return _fromWebURL;
			}
			set
			{
				_fromWebURL = value;
			}
		}


		/// <summary>
		/// The body text of the comment that was left.
		/// </summary>
		public string CommentText
		{
			get
			{
				return _commentText;
			}
			set
			{
				_commentText = value;
			}
		}


		#endregion


	}
}
