#region Copyright and License
/*
Copyright 2003 Jason Alexander, nGallery.org
Design work copyright Thomas Johansen (http://www.aylarsolutions.com/)

GOTDOTNET WORKSPACES COMMERCIAL DERIVATIVES LICENSE
Copyright (C) 2003 Microsoft Corporation

You can use this Software for any commercial or noncommercial purpose, 
including distributing derivative works.

In return, we simply require that you agree:

1. Not to remove any copyright notices from the Software. 
2. That if you distribute the Software in source code form you do so only 
   under this License (i.e. you must include a complete copy of this License 
   with your distribution), and if you distribute the Software solely in 
   object form you only do so under a license that complies with this License. 
3. That the Software comes "as is", with no warranties. None whatsoever. This 
   means no express, implied or statutory warranty, including without 
   limitation, warranties of merchantability or fitness for a particular 
   purpose or any warranty of noninfringement. Also, you must pass this 
   disclaimer on whenever you distribute the Software.
4. That neither Microsoft nor any contributor to the Software will be liable 
   for any of those types of damages known as indirect, special, consequential, 
   or incidental related to the Software or this License, to the maximum extent 
   the law permits, no matter what legal theory it�s based on. Also, you must 
   pass this limitation of liability on whenever you distribute the Software.
5. That if you sue anyone over patents that you think may apply to the 
   Software for a person's use of the Software, your license to the Software 
   ends automatically. 
6. That the patent rights, if any, licensed hereunder only apply to the 
   Software, not to any derivative works you make. 
7. That your rights under this License end automatically if you breach it in 
   any way.
*/
#endregion
using System;

namespace nGallery.Lib
{
	/// <summary>
	/// Summary description for Contact.
	/// </summary>
	public class Contact
	{

	
		#region Private Members


		private int _id;
		private string _firstName;
		private string _middleName;
		private string _lastName;
		private string _nickName;
		private string _emailAddress;
		private string _homePhone;
		private string _workPhone;
		private string _mobilePhone;
		private string _address1;
		private string _address2;
		private string _city;
		private string _state;
		private string _zip;
		private string _websiteUrl;


		#endregion


		#region Constructor(s)


		public Contact()
		{
		}


		#endregion


		#region Public Properties


		public int ID { get { return _id; } set { _id = value; } }
		public string FirstName { get { return _firstName; } set { _firstName = value; } }
		public string MiddleName { get { return _middleName; } set { _middleName = value; } }
		public string LastName { get { return _lastName; } set { _lastName = value; } }
		public string NickName { get { return _nickName; } set { _nickName = value; } }
		public string EmailAddress { get { return _emailAddress; } set { _emailAddress = value; } }
		public string HomePhone { get { return _homePhone; } set { _homePhone = value; } }
		public string WorkPhone { get { return _workPhone; } set { _workPhone = value; } }
		public string MobilePhone { get { return _mobilePhone; } set { _mobilePhone = value; } }
		public string Address1 { get { return _address1; } set { _address1 = value; } }
		public string Address2 { get { return _address2; } set { _address2 = value; } }
		public string City { get { return _city; } set { _city = value; } }
		public string State { get { return _state; } set { _state = value; } }
		public string Zip { get { return _zip; } set { _zip = value; } }
		public string WebsiteUrl { get { return _websiteUrl; } set { _websiteUrl = value; } }


		#endregion


	}
}
