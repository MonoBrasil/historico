using System;

namespace nGalleryLib.Components
{
	/// <summary>
	/// Summary description for AddressBook.
	/// </summary>
	public class AddressBook
	{
		public AddressBook()
		{
			//
			// TODO: Add constructor logic here
			//
		}
	}
}
