#region Copyright and License
/*
Copyright 2003 Jason Alexander, nGallery.org
Design work copyright Thomas Johansen (http://www.aylarsolutions.com/)

GOTDOTNET WORKSPACES COMMERCIAL DERIVATIVES LICENSE
Copyright (C) 2003 Microsoft Corporation

You can use this Software for any commercial or noncommercial purpose, 
including distributing derivative works.

In return, we simply require that you agree:

1. Not to remove any copyright notices from the Software. 
2. That if you distribute the Software in source code form you do so only 
   under this License (i.e. you must include a complete copy of this License 
   with your distribution), and if you distribute the Software solely in 
   object form you only do so under a license that complies with this License. 
3. That the Software comes "as is", with no warranties. None whatsoever. This 
   means no express, implied or statutory warranty, including without 
   limitation, warranties of merchantability or fitness for a particular 
   purpose or any warranty of noninfringement. Also, you must pass this 
   disclaimer on whenever you distribute the Software.
4. That neither Microsoft nor any contributor to the Software will be liable 
   for any of those types of damages known as indirect, special, consequential, 
   or incidental related to the Software or this License, to the maximum extent 
   the law permits, no matter what legal theory it�s based on. Also, you must 
   pass this limitation of liability on whenever you distribute the Software.
5. That if you sue anyone over patents that you think may apply to the 
   Software for a person's use of the Software, your license to the Software 
   ends automatically. 
6. That the patent rights, if any, licensed hereunder only apply to the 
   Software, not to any derivative works you make. 
7. That your rights under this License end automatically if you breach it in 
   any way.
*/
#endregion
using System;

namespace nGallery.Lib
{


	/// <summary>
	/// The Picture class holds all information that pertains to a given photo in an album.
	/// Pictures are held in a PictureCollection object, which is ultimately held by a Album.
	/// </summary>
	[Serializable]
	public class Rating
	{


		#region Private Members


		private int _rating1;
		private int _rating2;
		private int _rating3;
		private int _rating4;
		private int _rating5;

		#endregion


		#region Constructors


		/// <summary>
		/// The base constructor of the Picture object.
		/// </summary>
		public Rating()
		{
			_rating1	= 0;
			_rating2	= 0;
			_rating3	= 0;
			_rating4	= 0;
			_rating5	= 0;
		}


		#endregion


		#region Public Properties


		/// <summary>
		/// The number of votes for the rating of "1".
		/// </summary>
		public int Rating1
		{
			get
			{
				return _rating1;
			}
			set
			{
				_rating1 = value;
			}
		}

		/// <summary>
		/// The number of votes for the rating of "2".
		/// </summary>
		public int Rating2
		{
			get
			{
				return _rating2;
			}
			set
			{
				_rating2 = value;
			}
		}

		/// <summary>
		/// The number of votes for the rating of "3".
		/// </summary>
		public int Rating3
		{
			get
			{
				return _rating3;
			}
			set
			{
				_rating3 = value;
			}
		}

		/// <summary>
		/// The number of votes for the rating of "4".
		/// </summary>
		public int Rating4
		{
			get
			{
				return _rating4;
			}
			set
			{
				_rating4 = value;
			}
		}

		/// <summary>
		/// The number of votes for the rating of "5".
		/// </summary>
		public int Rating5
		{
			get
			{
				return _rating5;
			}
			set
			{
				_rating5 = value;
			}
		}

		/// <summary>
		/// Read-only. The total number of votes that have been submitted.
		/// </summary>
		public int TotalVotes
		{
			get
			{
				return _rating1 + _rating2 + _rating3 + _rating4 + _rating5;
			}
		}

		/// <summary>
		/// This method returns the average rating, given the previous rating values.
		/// </summary>
		/// <returns>decimal</returns>
		public decimal GetRating()
		{
			int sumValues = _rating1 + (_rating2 * 2) + (_rating3 * 3) + (_rating4 * 4) + (_rating5 * 5);
			int totalVotes = _rating1 + _rating2 + _rating3 + _rating4 + _rating5;


			if (totalVotes == 0) totalVotes = 1;
			
			return decimal.Round( (decimal) sumValues / (decimal) totalVotes, 2);
		}


		#endregion


	}
}
