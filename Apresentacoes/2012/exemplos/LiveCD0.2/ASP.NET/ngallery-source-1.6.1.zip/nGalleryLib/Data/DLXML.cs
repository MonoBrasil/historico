#region Copyright and License
/*
Copyright 2003 Jason Alexander, nGallery.org
Design work copyright Thomas Johansen (http://www.aylarsolutions.com/)

GOTDOTNET WORKSPACES COMMERCIAL DERIVATIVES LICENSE
Copyright (C) 2003 Microsoft Corporation

You can use this Software for any commercial or noncommercial purpose, 
including distributing derivative works.

In return, we simply require that you agree:

1. Not to remove any copyright notices from the Software. 
2. That if you distribute the Software in source code form you do so only 
   under this License (i.e. you must include a complete copy of this License 
   with your distribution), and if you distribute the Software solely in 
   object form you only do so under a license that complies with this License. 
3. That the Software comes "as is", with no warranties. None whatsoever. This 
   means no express, implied or statutory warranty, including without 
   limitation, warranties of merchantability or fitness for a particular 
   purpose or any warranty of noninfringement. Also, you must pass this 
   disclaimer on whenever you distribute the Software.
4. That neither Microsoft nor any contributor to the Software will be liable 
   for any of those types of damages known as indirect, special, consequential, 
   or incidental related to the Software or this License, to the maximum extent 
   the law permits, no matter what legal theory it�s based on. Also, you must 
   pass this limitation of liability on whenever you distribute the Software.
5. That if you sue anyone over patents that you think may apply to the 
   Software for a person's use of the Software, your license to the Software 
   ends automatically. 
6. That the patent rights, if any, licensed hereunder only apply to the 
   Software, not to any derivative works you make. 
7. That your rights under this License end automatically if you breach it in 
   any way.
*/
#endregion
using System;
using System.Collections;
using System.IO;
using System.Xml.Serialization;


namespace nGallery.Lib.DL
{

	
	/// <summary>
	/// This class is the XML-based DL class. This class handles all data layer
	/// calls for an XML-based data store, and provides the specific implementations
	/// for the generic interfaces defined in the subclass.
	/// </summary>
	public class XML : DLBase
	{


		#region Private Members


		private static InvitationCollection _invitations = null;
		private static AlbumCollection _albumCollection = null;
		private static ContactCollection _contacts = null;
		private static object _albumLockHandle = new object();
		private static object _addressBookLockHandle = new object();
		private static object _invitationLockHandle = new object();


		#endregion
		
		
		#region Public Method Implementations


		/// <summary>
		/// This method loads up the XML datastore, and returns all the albums in it.
		/// </summary>
		/// <returns>AlbumCollection</returns>
		public override AlbumCollection GetAlbums()
		{
			if (_albumCollection == null)
			{
				lock (_albumLockHandle)
				{
					if (!File.Exists(this.DataDirectory))
					{
						_albumCollection = new AlbumCollection();
					}
					else
					{
						StreamReader reader = null;
						try
						{
							XmlSerializer ser = new XmlSerializer(typeof(AlbumCollection));
							reader = new StreamReader(this.DataDirectory);
				
							// Deserialize the object into a AlbumCollection and return it.
							_albumCollection = (AlbumCollection) ser.Deserialize(reader);
						}
						finally
						{
							if (reader != null) reader.Close();
						}
					}
				}
			}
			
			return _albumCollection;
		}


		/// <summary>
		/// Returns all the contacts in the system.
		/// </summary>
		/// <returns>ContactCollection</returns>
		public override ContactCollection GetContacts()
		{
			if (_contacts == null)
			{
				lock (_addressBookLockHandle)
				{
					string addrBookDirectory = this.DataDirectory.Replace("ngallery.xml", "addressbook.xml");

					if (!File.Exists(addrBookDirectory))
					{
						_contacts = new ContactCollection();
					}
					else
					{
						StreamReader reader = null;
						try
						{
							XmlSerializer ser = new XmlSerializer(typeof(ContactCollection));
							reader = new StreamReader(addrBookDirectory);

							// Deserialize the object into a AddressBook and return it.
							_contacts = (ContactCollection) ser.Deserialize(reader);
						}
						finally
						{
							if (reader != null) reader.Close();
						}
					}
				}
			}

			return _contacts;
		}


		/// <summary>
		/// Returns all invitations within the system.
		/// </summary>
		/// <returns>InvitationCollection</returns>
		public override InvitationCollection GetInvitations()
		{
			if (_invitations == null)
			{
				lock (_invitationLockHandle)
				{
					string inviteDirectory = this.DataDirectory.Replace("ngallery.xml", "invitations.xml");

					if (!File.Exists(inviteDirectory))
					{
						_invitations = new InvitationCollection();
					}
					else
					{
						StreamReader reader = null;
						try
						{
							XmlSerializer ser = new XmlSerializer(typeof(InvitationCollection));
							reader = new StreamReader(inviteDirectory);

							// Deserialize the object into a InvitationCollection and return it.
							_invitations = (InvitationCollection) ser.Deserialize(reader);
						}
						finally
						{
							if (reader != null) reader.Close();
						}
					}
				}
			}

			return _invitations;
		}
		

		/// <summary>
		/// Persists the album content and address book to disk.
		/// </summary>
		private void Save()
		{
			XmlSerializer ser = new XmlSerializer(typeof(AlbumCollection));
			FileStream fileOut = null;
			
			// Serialize the main ngallery AlbumCollection.
			lock (_albumLockHandle)
			{
				try
				{
					fileOut = new FileStream(this.DataDirectory, FileMode.Create, FileAccess.Write, FileShare.None);
					
					// Serialize the object in XML to the given file stream.
					ser.Serialize(fileOut, this.GetAlbums());
				}
				finally
				{
					// Close the file stream.
					if (fileOut != null) fileOut.Close();
				}
			}


		}


		/// <summary>
		/// Saves all the address book values to addressbook.xml in your data directory.
		/// </summary>
		private void SaveAddressBook()
		{
			XmlSerializer ser = new XmlSerializer(typeof(ContactCollection));
			FileStream fileOut = null;
			

			// Serialize the address book.
			lock (_addressBookLockHandle)
			{
				try
				{
					fileOut = new FileStream(this.DataDirectory.Replace("ngallery.xml", "addressbook.xml"), FileMode.Create, FileAccess.Write, FileShare.None);

					ser.Serialize(fileOut, this.GetContacts());
				}
				finally
				{
					if (fileOut != null) fileOut.Close();
				}
			}

		}


		/// <summary>
		/// Saves all your invitation information to invitations.xml in your data directory.
		/// </summary>
		public void SaveInvitations()
		{
			XmlSerializer ser = new XmlSerializer(typeof(InvitationCollection));
			FileStream fileOut = null;
			

			// Serialize the address book.
			lock (_invitationLockHandle)
			{
				try
				{
					fileOut = new FileStream(this.DataDirectory.Replace("ngallery.xml", "invitations.xml"), FileMode.Create, FileAccess.Write, FileShare.None);

					ser.Serialize(fileOut, this.GetInvitations());
				}
				finally
				{
					if (fileOut != null) fileOut.Close();
				}
			}
		}


		/// <summary>
		/// This method loads up the XML datastore, and returns the Album object for the
		/// given album ID.
		/// </summary>
		/// <param name="albumID">The ID of the album you wish to retrieve</param>
		/// <returns>Album</returns>
		public override Album GetAlbum(int albumID)
		{
			AlbumCollection albums = this.GetAlbums();
			
			for (int i = 0; i < albums.Count; i++)
			{
				// TODO: Add custom exception for no album found.
				if (albums[i].ID == albumID) return albums[i];
			}
			
			return null;
		}
		

		/// <summary>
		/// This method loads up the XML datastore, and adds the given Album object to
		/// the main AlbumCollection data store.
		/// </summary>
		/// <param name="album">The Album object you wish to add/create</param>
		public override void CreateAlbum(Album album)
		{
			AlbumCollection albums = this.GetAlbums();
			
			// Add the album.
			albums.Add(album);
			
			// Save it!
			this.Save();
		}


		/// <summary>
		/// This method loads up the XML datastore, and attempts to update the Album
		/// in the AlbumCollection based on Album.ID.
		/// </summary>
		/// <param name="album">The Album instance you wish to update</param>
		public override void UpdateAlbum(Album album)
		{
			AlbumCollection albums = this.GetAlbums();
			
			for (int i = 0; i < albums.Count; i++)
			{
				// TODO: Add custom exception for no album found.
				if (albums[i].ID == album.ID)
				{
					albums[i].Name			= album.Name;
					albums[i].Description	= album.Description;
					albums[i].CreateDate	= album.CreateDate;
					albums[i].ParentAlbumID = album.ParentAlbumID;

					break;
				}
			}
			
			this.Save();
		}


		/// <summary>
		/// This method loads up the XML datastore, and attempts to delete it from
		/// the main AlbumCollection data store.
		/// </summary>
		/// <param name="albumID">The ID of the Album to delete</param>
		public override void DeleteAlbum(int albumID)
		{
			AlbumCollection albums = this.GetAlbums();
			
			for (int i = 0; i < albums.Count; i++)
			{
				// TODO: Add custom exception for no album found.
				if (albums[i].ID == albumID)
				{
					albums.Remove((Album) albums[i]);

					break;
				}
			}
			
            this.Save();
		}
		
		/// <summary>
		/// This method loads up the XML datastore, and retrieves the PictureCollection
		/// for the given album ID.
		/// </summary>
		/// <param name="albumID">The ID of the album that you wish to retrieve the pictures for</param>
		/// <returns>PictureCollection</returns>
		public override PictureCollection GetAlbumPictures(int albumID)
		{
			AlbumCollection albums = this.GetAlbums();
			
			for (int i = 0; i < albums.Count; i++)
			{
				// TODO: Add custom exception for no pictures found.
				if (albums[i].ID == albumID) return (PictureCollection) albums[i].Pictures;
			}
			
			return null;
		}
		
		/// <summary>
		/// This method loads up the XML datastore, and attempts to retrieve the Picture
		/// object for the given album ID and picture ID.
		/// </summary>
		/// <param name="albumID">The ID of the album you wish to look in</param>
		/// <param name="pictureID">The ID of the picture you wish to retrieve</param>
		/// <returns>Picture</returns>
		public override Picture GetPicture(int albumID, int pictureID)
		{
			AlbumCollection albums = this.GetAlbums();
			
			for (int i = 0; i < albums.Count; i++)
			{
				// TODO: Add custom exception for no album found.
				if (albums[i].ID == albumID)
				{
					for (int j = 0; j < albums[i].Pictures.Count; j++)
					{
						// TODO: Add custom exception for no picture found.
						if (albums[i].Pictures[j].ID == pictureID) return (Picture) albums[i].Pictures[j];
					}
				}
			}
			
			return null;
		}
		
		/// <summary>
		/// This method loads up the XML datastore, and attempts to add your Picture object to the
		/// given album's PictureCollection.
		/// </summary>
		/// <param name="albumID">The ID of the album to add the picture to</param>
		/// <param name="picture">The Picture object to add to the album's PictureCollection</param>
		public override void CreatePicture(int albumID, Picture picture)
		{
			AlbumCollection albums = this.GetAlbums();
			
			for (int i = 0; i < albums.Count; i++)
			{
				// TODO: Add custom exception for no album found.
				if (albums[i].ID == albumID)
				{
					albums[i].Pictures.Add(picture);

					this.Save();

					break;
				}
			}
		}


		/// <summary>
		/// This method loads up the XML datastore, and attempts to update the Picture object based
		/// on the given album ID and picture.ID.
		/// </summary>
		/// <param name="albumID">The ID of the album to look in for the update</param>
		/// <param name="picture">The Picture object to update in the album</param>
		public override void UpdatePicture(int albumID, Picture picture)
		{
			AlbumCollection albums = this.GetAlbums();
			
			for (int i = 0; i < albums.Count; i++)
			{
				// TODO: Add custom exception for no album found.
				if (albums[i].ID == albumID)
				{
					for (int j = 0; j < albums[i].Pictures.Count; j++)
					{
						// TODO: Add custom exception for no picture found.
						if (albums[i].Pictures[j].ID == picture.ID)
						{
							albums[i].Pictures[j].FileName		= picture.FileName;
							albums[i].Pictures[j].Title			= picture.Title;
							albums[i].Pictures[j].Caption		= picture.Caption;
							albums[i].Pictures[j].CreateDate	= picture.CreateDate;
							albums[i].Pictures[j].Height    	= picture.Height;
							albums[i].Pictures[j].Width			= picture.Width;

							this.Save();

							break;
						}
					}
				}
			}
		}


		/// <summary>
		/// This method loads up the XML datastore, and attempt to delete the picture in the given
		/// album ID.
		/// </summary>
		/// <param name="albumID">The ID of the album to look in</param>
		/// <param name="pictureID">The ID of the picture to attempt to delete</param>
		public override void DeletePicture(int albumID, int pictureID)
		{
			AlbumCollection albums = this.GetAlbums();
			bool bFoundPicture = false;

			for (int i = 0; i < albums.Count; i++)
			{
				// TODO: Add custom exception for no album found
				// TODO: Add custom exception for no picture found
				if (bFoundPicture) break;
				if (albums[i].ID == albumID)
				{
					for (int j = 0; j < albums[i].Pictures.Count; j++)
					{
						if (albums[i].Pictures[j].ID == pictureID)
						{
							albums[i].Pictures.Remove((Picture) albums[i].Pictures[j]);
							
							this.Save();

							bFoundPicture = true;

							break;
						}
					}
				}
			}
		}


		/// <summary>
		/// This method loads up the XML datastore, and attempts to retrieve the next unique album ID.
		/// </summary>
		/// <returns>int</returns>
		public override int GetNextAlbumID()
		{
			AlbumCollection albums = this.GetAlbums();
			int maxAlbumID = 0;


			for (int i = 0; i < albums.Count; i++)
			{
				if (albums[i].ID > maxAlbumID) maxAlbumID = albums[i].ID;
			}

			return (maxAlbumID + 1);
		}



		/// <summary>
		/// This method loads up the XML datastore, and attempts to retrieve the next unique picture ID
		/// in the given album, based on album ID. 
		/// </summary>
		/// <param name="albumID">The ID of the album that you need the next unique picture ID for</param>
		/// <returns>int</returns>
		public override int GetNextPictureID(int albumID)
		{
			AlbumCollection albums = this.GetAlbums();
			int maxPictureID = 0;


			for (int i = 0; i < albums.Count; i++)
			{
				// TODO: Add custom exception for no album found
				if (albums[i].ID == albumID)
				{
					for (int j = 0; j < albums[i].Pictures.Count; j++)
					{
						if (albums[i].Pictures[j].ID > maxPictureID) maxPictureID = albums[i].Pictures[j].ID;
					}

					break;
				}
			}

			return (maxPictureID + 1);
		}



		/// <summary>
		/// This method sets the given picture as the highlighted Picture for the given
		/// album ID.
		/// </summary>
		/// <param name="albumID">The ID of the album you wish to set a highlighted picture for</param>
		/// <param name="pictureID">The ID of the picture you wish to set as the highlighted picture</param>
		public override void SetHighlightedPicture(int albumID, int pictureID)
		{
			AlbumCollection albums = this.GetAlbums();
			
			for (int i = 0; i < albums.Count; i++)
			{
				// TODO: Add custom exception for no album found.
				if (albums[i].ID == albumID)
				{
					for (int j = 0; j < albums[i].Pictures.Count; j++)
					{
						// TODO: Add custom exception for no picture found.
						if (albums[i].Pictures[j].ID == pictureID)
						{
							albums[i].Pictures[j].HighlightPicture = true;
						}
						else
						{
							albums[i].Pictures[j].HighlightPicture = false;
						}
					}
				}
			}
			
			this.Save();
		}


		/// <summary>
		/// This method returns the next unique comment ID for the given album ID and picture ID.
		/// </summary>
		/// <param name="albumID">The ID of the respective album.</param>
		/// <param name="pictureID">The ID of the respective picture.</param>
		/// <returns>int</returns>
		public override int GetNextCommentID(int albumID, int pictureID)
		{
			AlbumCollection albums = this.GetAlbums();
			int maxCommentID = 0;

			for (int i = 0; i < albums.Count; i++)
			{
				if (albums[i].ID == albumID)
				{
					for (int j = 0; j < albums[i].Pictures.Count; j++)
					{
						if (albums[i].Pictures[j].ID == pictureID)
						{
							for (int k = 0; k < albums[i].Pictures[j].Comments.Count; k++)
							{
								if (albums[i].Pictures[j].Comments[k].ID > maxCommentID) maxCommentID = albums[i].Pictures[j].Comments[k].ID;
							}

							break;
						}
					}

					break;
				}
			}

			return (maxCommentID + 1);
		}


		/// <summary>
		/// This method returns the CommentCollection containing all Comment objects for
		/// a given album ID and picture ID.
		/// </summary>
		/// <param name="albumID">The ID of the respective album.</param>
		/// <param name="pictureID">The ID of the respective picture.</param>
		/// <returns>CommentCollection</returns>
		public override CommentCollection GetPictureComments(int albumID, int pictureID)
		{
			AlbumCollection albums = this.GetAlbums();
			
			for (int i = 0; i < albums.Count; i++)
			{
				if (albums[i].ID == albumID)
				{
					for (int j = 0; j < albums[i].Pictures.Count; j++)
					{
						if (albums[i].Pictures[j].ID == pictureID) return (CommentCollection) albums[i].Pictures[j].Comments;
					}

					break;
				}
			}

			return null;
		}


		/// <summary>
		/// This method returns the specific Comment object for the given Album, Picture and Comment ID.
		/// </summary>
		/// <param name="albumID">The ID of the respective album.</param>
		/// <param name="pictureID">The ID of the respective picture.</param>
		/// <param name="commentID">The ID of the respective comment.</param>
		/// <returns>Comment</returns>
		public override Comment GetComment(int albumID, int pictureID, int commentID)
		{
			AlbumCollection albums = this.GetAlbums();
			
			for (int i = 0; i < albums.Count; i++)
			{
				if (albums[i].ID == albumID)
				{
					for (int j = 0; j < albums[i].Pictures.Count; j++)
					{
						if (albums[i].Pictures[j].ID == pictureID)
						{
							for (int k = 0; k < albums[i].Pictures[j].Comments.Count; k++)
							{
								if (albums[i].Pictures[j].Comments[k].ID == commentID) return (Comment) albums[i].Pictures[j].Comments[k];
							}

							break;
						}
					}

					break;
				}
			}

			return null;
		}


		/// <summary>
		/// This method attempts to create a comment for a given album ID, picture ID and the respective
		/// Comment object.
		/// </summary>
		/// <param name="albumID">The ID of the album in which to create the Comment</param>
		/// <param name="pictureID">The ID of the picture in which to create a Comment</param>
		/// <param name="comment">The Comment object to create</param>
		public override void CreateComment(int albumID, int pictureID, Comment comment)
		{
			AlbumCollection albums = this.GetAlbums();
			
			for (int i = 0; i < albums.Count; i++)
			{
				if (albums[i].ID == albumID)
				{
					for (int j = 0; j < albums[i].Pictures.Count; j++)
					{
						if (albums[i].Pictures[j].ID == pictureID)
						{
							albums[i].Pictures[j].Comments.Add(comment);

							this.Save();
						}
					}
					
					break;
				}
			}
		}


		/// <summary>
		/// This method attempts to update a Comment for a given album ID, picture ID and Comment.
		/// </summary>
		/// <param name="albumID">The ID of the album in which to update the Comment</param>
		/// <param name="pictureID">The ID of the picture in which to update the Comment</param>
		/// <param name="comment"></param>
		public override void UpdateComment(int albumID, int pictureID, Comment comment)
		{
			AlbumCollection albums = this.GetAlbums();
			
			for (int i = 0; i < albums.Count; i++)
			{
				if (albums[i].ID == albumID)
				{
					for (int j = 0; j < albums[i].Pictures.Count; j++)
					{
						if (albums[i].Pictures[j].ID == pictureID)
						{
							for (int k = 0; k < albums[i].Pictures[j].Comments.Count; k++)
							{
								if (albums[i].Pictures[j].Comments[k].ID == comment.ID)
								{
									albums[i].Pictures[j].Comments[k].FromName		= comment.FromName;
									albums[i].Pictures[j].Comments[k].FromEmailAddr	= comment.FromEmailAddr;
									albums[i].Pictures[j].Comments[k].FromWebURL	= comment.FromWebURL;
									albums[i].Pictures[j].Comments[k].CreateDate	= comment.CreateDate;
									albums[i].Pictures[j].Comments[k].CommentText	= comment.CommentText;
									
									this.Save();
									
									break;
								}
							}
						}
					}

					break;
				}
			}			
		}


		/// <summary>
		/// This method deletes a comment for the given album ID, picture ID and comment ID.
		/// </summary>
		/// <param name="albumID">The ID of the respective album.</param>
		/// <param name="pictureID">The ID of the respective picture.</param>
		/// <param name="commentID">The ID of the respective comment.</param>
		public override void DeleteComment(int albumID, int pictureID, int commentID)
		{
			AlbumCollection albums = this.GetAlbums();
			
			for (int i = 0; i < albums.Count; i++)
			{
				if (albums[i].ID == albumID)
				{
					for (int j = 0; j < albums[i].Pictures.Count; j++)
					{
						if (albums[i].Pictures[j].ID == pictureID)
						{
							for (int k = 0; k < albums[i].Pictures[j].Comments.Count; k++)
							{
								if (albums[i].Pictures[j].Comments[k].ID == commentID)
								{
									albums[i].Pictures[j].Comments.Remove((Comment) albums[i].Pictures[j].Comments[k]);

									this.Save();

									break;
								}
							}

							break;
						}
					}

					break;
				}
			}			
		}

		/// <summary>
		/// Increments the view count for the specified picture.
		/// </summary>
		/// <param name="albumID">ID of the album containing the picture.</param>
		/// <param name="pictureID">ID of the picture.</param>
		public override void UpdateViewCount(int albumID, int pictureID)
		{
			AlbumCollection albums = this.GetAlbums();


			for (int i = 0; i < albums.Count; i++)
			{
				// TODO: Add custom exception for no album found.
				if (albums[i].ID == albumID)
				{
					for (int j = 0; j < albums[i].Pictures.Count; j++)
					{
						// TODO: Add custom exception for no picture found.
						if (albums[i].Pictures[j].ID == pictureID)
						{
							albums[i].Pictures[j].ViewCount = albums[i].Pictures[j].ViewCount + 1;
							this.Save();
							break;
						}
					}
				}
			}
		}


		/// <summary>
		/// This method returns the previous picture's ID for the given album ID and picture ID.
		/// </summary>
		/// <param name="albumID">The ID of the album for the current picture.</param>
		/// <param name="pictureID">The ID of the current picture.</param>
		/// <returns>int</returns>
		public override int GetPreviousPictureID(int albumID, int pictureID)
		{
			int prevPictureID = 0;
			AlbumCollection albums = this.GetAlbums();

			for (int i = 0; i < albums.Count; i++)
			{
				if (albums[i].ID == albumID)
				{
					for (int j = 0; j < albums[i].Pictures.Count; j++)
					{
						if (albums[i].Pictures[j].ID == pictureID)
							return prevPictureID;

						prevPictureID = albums[i].Pictures[j].ID;
					}
				}
			}
			return prevPictureID;
		}


		/// <summary>
		/// This method returns the next picture's ID for the given album ID and picture ID.
		/// </summary>
		/// <param name="albumID">The ID of the album for the current picture.</param>
		/// <param name="pictureID">The ID of the current picture.</param>
		/// <returns>int</returns>
		public override int GetNextActualPictureID(int albumID, int pictureID)
		{
			int nextPictureID = 0;
			AlbumCollection albums = this.GetAlbums();


			for (int i = 0; i < albums.Count; i++)
			{
				if (albums[i].ID == albumID)
				{
					for (int j = 0; j < albums[i].Pictures.Count; j++)
					{
						if (albums[i].Pictures[j].ID == pictureID)
						{
							if ((j + 1) < albums[i].Pictures.Count)
							{
								return albums[i].Pictures[j + 1].ID;
							}
						}
					}
				}
			}
			return nextPictureID;
		}


		/// <summary>
		/// This method returns the previous album's ID for the given album ID.
		/// </summary>
		/// <param name="albumID">The ID of the current album.</param>
		/// <returns>int</returns>
		public override int GetPreviousAlbumID(int albumID)
		{
			bool parentAlbum = true;
			int previousAlbumID = 0;
			AlbumCollection albums = this.GetAlbums();
			Album currentAlbum = this.GetAlbum(albumID);


			if (currentAlbum.ParentAlbumID == 0) parentAlbum = true;
			else parentAlbum = false;

			for (int i = 0; i < albums.Count; i++)
			{
				if ((parentAlbum && albums[i].ParentAlbumID == 0) ||
					(!parentAlbum && albums[i].ParentAlbumID != 0))
				{
					if (albums[i].ID != albumID)
					{
						if (!parentAlbum)
						{
							if (albums[i].ParentAlbumID == currentAlbum.ParentAlbumID)
								previousAlbumID = albums[i].ID;
						}
						else
						{
							previousAlbumID = albums[i].ID;
						}
					}
				}
				if (albums[i].ID == albumID)
				{
					return previousAlbumID;
				}
			}
			return previousAlbumID;
		}


		/// <summary>
		/// This method returns the next album's ID for the given album ID.
		/// </summary>
		/// <param name="albumID">The ID of the current album.</param>
		/// <returns>int</returns>
		public override int GetNextActualAlbumID(int albumID)
		{
			bool parentAlbum = true;
			bool nextIDFound = false;
			int nextAlbumID = 0;
			AlbumCollection albums = this.GetAlbums();
			Album currentAlbum = this.GetAlbum(albumID);


			if (currentAlbum.ParentAlbumID == 0) parentAlbum = true;
			else parentAlbum = false;

			for (int i = 0; i < albums.Count; i++)
			{
				if (albums[i].ID == albumID)
				{
					while (!nextIDFound)
					{
						if ((i + 1) < albums.Count)
						{
							for (int j = (i + 1); j < albums.Count; j++)
							{
								if (parentAlbum && albums[j].ParentAlbumID == 0)
								{
									return albums[j].ID;
								}
								else if (!parentAlbum && albums[j].ParentAlbumID != 0)
								{
									if (albums[j].ParentAlbumID == currentAlbum.ParentAlbumID)
									{
										return albums[j].ID;
									}
								}
							}
							break;
						}
						else
						{
							break;
						}
					}
				}
			}
			return nextAlbumID;			
		}

		/// <summary>
		/// Retrieves all of the information of the sub-ablbums of a particular album.
		/// </summary>
		/// <param name="albumID">The albumID for the album you want the sub-albums of</param>
		/// <returns>AlbumCollection</returns>
		public override AlbumCollection GetSubAlbums(int albumID)
		{
			AlbumCollection subAlbums = new AlbumCollection();
			AlbumCollection albums = this.GetAlbums();


			for (int i = 0; i < albums.Count; i++)
			{
				if (albums[i].ParentAlbumID == albumID)
				{
					subAlbums.Add(albums[i]);
				}
			}
			return subAlbums;
		}

		/// <summary>
		/// Retrieves all of the top level albums.
		/// </summary>
		/// <returns>AlbumCollection</returns>
		public override AlbumCollection GetParentAlbums()
		{
			AlbumCollection parentAlbums = new AlbumCollection();
			AlbumCollection albums = this.GetAlbums();


			for (int i = 0; i < albums.Count; i++)
			{
				if (albums[i].ParentAlbumID == 0)
					parentAlbums.Add(albums[i]);
			}
			return parentAlbums;
		}

		/// <summary>
		/// Gets the rating for a given picture.
		/// </summary>
		/// <param name="albumID">The album's ID</param>
		/// <param name="pictureID">The picture's ID</param>
		/// <returns>Rating</returns>
		public override Rating GetPictureRating(int albumID, int pictureID)
		{
			AlbumCollection albums = this.GetAlbums();

			for(int i = 0; i < albums.Count; i++)
			{
				if(albums[i].ID == albumID)
				{
					for(int j = 0; j < albums[i].Pictures.Count; j++)
					{
						if(albums[i].Pictures[j].ID == pictureID)
						{
							return albums[i].Pictures[j].Rating;
						}
					}
					break;
				}
			}
			return null;
		}

		/// <summary>
		/// Updates the rating for a picture.
		/// </summary>
		/// <param name="albumID">The ID of the album of the respective current picture.</param>
		/// <param name="pictureID">The ID of the picture.</param>
		/// <param name="PictureRating">The picture rating information.</param>
		public override void UpdatePictureRating(int albumID, int pictureID, Rating PictureRating)
		{
			AlbumCollection albums = this.GetAlbums();

			for(int i = 0; i < albums.Count; i++)
			{
				if(albums[i].ID == albumID)
				{
					for(int j = 0; j < albums[i].Pictures.Count; j++)
					{
						if(albums[i].Pictures[j].ID == pictureID)
						{
							albums[i].Pictures[j].Rating = PictureRating;
							this.Save();
							break;
						}
					}
					break;
				}
			}
		}


		/// <summary>
		/// Returns the album ID for a given album name.
		/// </summary>
		/// <param name="albumName">The name of the album that you wish to look-up the ID for.</param>
		/// <returns>int</returns>
		public override int GetAlbumIDByName(string albumName)
		{
			AlbumCollection albums = this.GetAlbums();

			for(int i = 0; i < albums.Count; i++)
			{
				if (albums[i].Name == albumName)
					return albums[i].ID;
			}
			
			return 0;
		}


		/// <summary>
		/// Creates a contact record for the given Contact object passed.
		/// </summary>
		/// <param name="contact">The Contact object to create.</param>
		public override void CreateContact(Contact contact)
		{
			ContactCollection contacts = this.GetContacts();

			contacts.Add(contact);

			this.SaveAddressBook();
		}


		/// <summary>
		/// Returns the next contiguous contact ID available.
		/// </summary>
		/// <returns>int</returns>
		public override int GetNextContactID()
		{
			ContactCollection contacts = this.GetContacts();
			int maxContactID = 0;


			for (int i = 0; i < contacts.Count; i++)
			{
				if (contacts[i].ID > maxContactID) maxContactID = contacts[i].ID;
			}

			return (maxContactID + 1);
		}


		/// <summary>
		/// Returns the Contact object for the given contact ID.
		/// </summary>
		/// <param name="contactID">The ID of the contact that you wish to retrieve.</param>
		/// <returns>Contact</returns>
		public override Contact GetContact(int contactID)
		{
			ContactCollection contacts = this.GetContacts();


			for (int i = 0; i < contacts.Count; i++)
			{
				if (contacts[i].ID == contactID) return contacts[i];
			}
			return null;
		}


		/// <summary>
		/// Updates the contact information for the given Contact object, keying off the contact ID.
		/// </summary>
		/// <param name="contact">The Contact object, with the new values, that you wish to update.</param>
		public override void UpdateContact(Contact contact)
		{
			ContactCollection contacts = this.GetContacts();


			for (int i = 0; i < contacts.Count; i++)
			{
				if (contacts[i].ID == contact.ID)
				{
					contacts[i].FirstName		= contact.FirstName;
					contacts[i].MiddleName		= contact.MiddleName;
					contacts[i].LastName		= contact.LastName;
					contacts[i].NickName		= contact.NickName;
					contacts[i].EmailAddress	= contact.EmailAddress;
					contacts[i].HomePhone		= contact.HomePhone;
					contacts[i].WorkPhone		= contact.WorkPhone;
					contacts[i].MobilePhone		= contact.MobilePhone;
					contacts[i].Address1		= contact.Address1;
					contacts[i].Address2		= contact.Address2;
					contacts[i].City			= contact.City;
					contacts[i].State			= contact.State;
					contacts[i].Zip				= contact.Zip;
					contacts[i].WebsiteUrl		= contact.WebsiteUrl;

					break;
				}
			}

			this.SaveAddressBook();
		}


		/// <summary>
		/// Deletes a contact record for the given contact ID.
		/// </summary>
		/// <param name="contactID">The ID of the contact that you wish to delete.</param>
		public override void DeleteContact(int contactID)
		{
			ContactCollection contacts = this.GetContacts();


			for (int i = 0; i < contacts.Count; i++)
			{
				if (contacts[i].ID == contactID)
				{
					contacts.Remove(contacts[i]);
					break;
				}
			}
		}


		/// <summary>
		/// Returns the next available, contiguous invitation ID.
		/// </summary>
		/// <returns>int</returns>
		public override int GetNextInvitationID()
		{
			InvitationCollection invitations = this.GetInvitations();
			int maxInviteID = 0;


			for (int i = 0; i < invitations.Count; i++)
			{
				if (invitations[i].ID > maxInviteID) maxInviteID = invitations[i].ID;
			}

			return (maxInviteID + 1);			
		}


		/// <summary>
		/// Creates an invitation for the given Invitation object.
		/// </summary>
		/// <param name="invite">The Invitation object that you wish to create.</param>
		public override void CreateInvitation(Invitation invite)
		{
			InvitationCollection invitations = this.GetInvitations();

			invitations.Add(invite);

			this.SaveInvitations();

		}


		/// <summary>
		/// Deletes an invitation for the given invitation ID.
		/// </summary>
		/// <param name="inviteID">The ID of the invitation that you wish to delete.</param>
		public override void DeleteInvitation(int inviteID)
		{
			InvitationCollection invitations = this.GetInvitations();


			for (int i = 0; i < invitations.Count; i++)
			{
				if (invitations[i].ID == inviteID)
				{
					invitations.Remove(invitations[i]);
					break;
				}
			}

			this.SaveInvitations();
		}


		/// <summary>
		/// Sets the invitation read values for a given invitation's GUID.
		/// </summary>
		/// <param name="inviteGuid">The GUID of the invitation that you wish to mark as read.</param>
		public override void MarkInvitationRead(string inviteGuid)
		{
			InvitationCollection invitations = this.GetInvitations();
			bool bFound = false;


			for (int i = 0; i < invitations.Count; i++)
			{
				for (int j = 0; j < invitations[i].Recipients.Count; j++)
				{
					ArrayList recipientValues = (ArrayList) invitations[i].Recipients[j];

					if (recipientValues[1].ToString() == inviteGuid)
					{
						recipientValues[2] = "true";

						invitations[i].Recipients[j] = recipientValues;

						bFound = true;
						break;
					}

				}
				if (bFound) break;
			}

			this.SaveInvitations();
		}


		/// <summary>
		/// Returns the Invitation object for the given GUID.
		/// </summary>
		/// <param name="invitationGuid">The GUID that you wish to use to look-up the invitation.</param>
		/// <returns>Invitation</returns>
		public override Invitation GetInvitationByGuid(string invitationGuid)
		{
			InvitationCollection invitations = this.GetInvitations();


			for (int i = 0; i < invitations.Count; i++)
			{
				for (int j = 0; j < invitations[i].Recipients.Count; j++)
				{
					ArrayList recipientValues = (ArrayList) invitations[i].Recipients[j];

					if (recipientValues[1].ToString() == invitationGuid)
					{
						return invitations[i];
					}

				}
			}

			return null;
		}


		/// <summary>
		/// Returns the Contact object for the given GUID.
		/// </summary>
		/// <param name="invitationGuid">The GUID of the Contact that you wish to look-up.</param>
		/// <returns>Contact</returns>
		public override Contact GetContactByGuid(string invitationGuid)
		{
			InvitationCollection invitations = this.GetInvitations();


			for (int i = 0; i < invitations.Count; i++)
			{
				for (int j = 0; j < invitations[i].Recipients.Count; j++)
				{
					ArrayList recipientValues = (ArrayList) invitations[i].Recipients[j];

					if (recipientValues[1].ToString() == invitationGuid)
					{
						return this.GetContact(int.Parse(recipientValues[0].ToString()));
					}

				}
			}

			return null;
		}


		/// <summary>
		/// Returns all recipients of a given invitation ID.
		/// </summary>
		/// <param name="inviteID">The ID of the invitation that you want the recipients for.</param>
		/// <returns>ArrayList</returns>
		public override ArrayList GetInvitationRecipients(int inviteID)
		{
			InvitationCollection invitations = this.GetInvitations();


			for (int i = 0; i < invitations.Count; i++)
			{
				if (invitations[i].ID == inviteID)
				{
					return invitations[i].Recipients;
				}
			}

			return null;
		}


		/// <summary>
		/// Returns the total number of pictures within an album, including all sub-albums.
		/// </summary>
		/// <param name="albumID">The ID of the album that you wish to get the picture count for.</param>
		/// <returns>int</returns>
		public override int GetTotalPictureCount(int albumID)
		{
			int totalCount = 0;
			Album currentAlbum = this.GetAlbum(albumID);
			AlbumCollection subAlbums = this.GetSubAlbums(albumID);


			totalCount += currentAlbum.Pictures.Count;

			for (int i = 0; i < subAlbums.Count; i++)
			{
				totalCount += this.GetTotalPictureCount(subAlbums[i].ID);
			}

			return totalCount;
		}



		#endregion


	}
}
