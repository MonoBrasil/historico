#region Copyright and License
/*
Copyright 2003 Jason Alexander, nGallery.org
Design work copyright Thomas Johansen (http://www.aylarsolutions.com/)

GOTDOTNET WORKSPACES COMMERCIAL DERIVATIVES LICENSE
Copyright (C) 2003 Microsoft Corporation

You can use this Software for any commercial or noncommercial purpose, 
including distributing derivative works.

In return, we simply require that you agree:

1. Not to remove any copyright notices from the Software. 
2. That if you distribute the Software in source code form you do so only 
   under this License (i.e. you must include a complete copy of this License 
   with your distribution), and if you distribute the Software solely in 
   object form you only do so under a license that complies with this License. 
3. That the Software comes "as is", with no warranties. None whatsoever. This 
   means no express, implied or statutory warranty, including without 
   limitation, warranties of merchantability or fitness for a particular 
   purpose or any warranty of noninfringement. Also, you must pass this 
   disclaimer on whenever you distribute the Software.
4. That neither Microsoft nor any contributor to the Software will be liable 
   for any of those types of damages known as indirect, special, consequential, 
   or incidental related to the Software or this License, to the maximum extent 
   the law permits, no matter what legal theory it�s based on. Also, you must 
   pass this limitation of liability on whenever you distribute the Software.
5. That if you sue anyone over patents that you think may apply to the 
   Software for a person's use of the Software, your license to the Software 
   ends automatically. 
6. That the patent rights, if any, licensed hereunder only apply to the 
   Software, not to any derivative works you make. 
7. That your rights under this License end automatically if you breach it in 
   any way.
*/
#endregion
using System;
using System.Collections;


namespace nGallery.Lib.DL
{


	/// <summary>
	/// This is the abstract base class that is used to general the different data
	/// layers. This class basically sets up any common properties, methods, etc... and defines
	/// any abstract methods that must be implemented on any subclasses that wish to use
	/// this base class.
	/// </summary>
	public abstract class DLBase
	{


		#region Private Members


		private string _dataDirectory;


		#endregion


		#region Public Properties


		/// <summary>
		/// This property gets or sets the data directory in which you use. This is only applicable for the XML
		/// data store.
		/// </summary>
		public string DataDirectory
		{
			get { return _dataDirectory; }
			set { _dataDirectory = value; }
		}


		#endregion


		#region Abstract Method Definitions


		/// <summary>
		/// Any inheriting classes must implement this abstract method so that it queries
		/// whatever necessary data store and returns all albums.
		/// </summary>
		/// <returns>AlbumCollection</returns>
		public abstract AlbumCollection GetAlbums();


		/// <summary>
		/// Any inheriting classes must implement this abstract method so that it queries
		/// whatever necessary data store and returns the album for the given album ID.
		/// </summary>
		/// <param name="albumID">The ID of the album to retrieve.</param>
		/// <returns>Album</returns>
		public abstract Album GetAlbum(int albumID);


		/// <summary>
		/// Any inheriting classes must implement this abstract method so that it creates
		/// a "record" in the data store based on the given Album object.
		/// </summary>
		/// <param name="album">The Album object to create in the data store.</param>
		public abstract void CreateAlbum(Album album);


		/// <summary>
		/// Any inheriting classes must implement this abstract method so that it updates
		/// the data store with the given Album's information.
		/// </summary>
		/// <param name="album">The Album object to update.</param>
		public abstract void UpdateAlbum(Album album);


		/// <summary>
		/// Any inheriting classes must implement this abstract method so that it deletes
		/// the given album, based on the album ID, from the data store.
		/// </summary>
		/// <param name="albumID"></param>
		public abstract void DeleteAlbum(int albumID);


		/// <summary>
		/// Any inheriting classes must implement this abstract method so that it returns
		/// all pictures for the given album ID.
		/// </summary>
		/// <param name="albumID">The ID of the album for which to retrieve it's respective pictures.</param>
		/// <returns></returns>
		public abstract PictureCollection GetAlbumPictures(int albumID);


		/// <summary>
		/// Any inheriting classes must implement this abstract method so that it returns
		/// the Picture object for the given album ID and picture ID.
		/// </summary>
		/// <param name="albumID">The ID of the album to look in.</param>
		/// <param name="pictureID">The ID of the picture to retrieve.</param>
		/// <returns></returns>
		public abstract Picture GetPicture(int albumID, int pictureID);


		/// <summary>
		/// Any inheriting classes must implement this abstract method so that it creates a "record" for
		/// the given Picture object within the given album, based on album ID.
		/// </summary>
		/// <param name="albumID">The ID of the album in which to create a Picture.</param>
		/// <param name="picture">The Picture to add to the album.</param>
		public abstract void CreatePicture(int albumID, Picture picture);


		/// <summary>
		/// Any inheriting classes must implement this abstract method so that it updates the given
		/// picture, based on the album ID and a Picture object.
		/// </summary>
		/// <param name="albumID">The ID of the album in which the Picture resides.</param>
		/// <param name="picture">The Picture object to update.</param>
		public abstract void UpdatePicture(int albumID, Picture picture);


		/// <summary>
		/// Any inheriting classes must implement this abstract method so that it deletes the picture
		/// in the data store for the given album ID and picture ID.
		/// </summary>
		/// <param name="albumID">The ID of the album in which the picture resides.</param>
		/// <param name="pictureID">The ID of the picture in which to delete.</param>
		public abstract void DeletePicture(int albumID, int pictureID);


		/// <summary>
		/// Any inheriting classes must implement this abstract method so that it gets the next
		/// unique album ID for it's respective data store.
		/// </summary>
		/// <returns>int</returns>
		public abstract int GetNextAlbumID();


		/// <summary>
		/// Any inheriting classes must implement this abstract method so that it gets the next
		/// unique picture ID within the album, for the given album ID.
		/// </summary>
		/// <param name="albumID">The ID of the album in which you need a unique picture ID.</param>
		/// <returns>int</returns>
		public abstract int GetNextPictureID(int albumID);


		/// <summary>
		/// Any inheriting classes must implement this abstract method so that it sets the given picture
		/// (based on picture ID), within the given album ID to the album's highlighted picture.
		/// </summary>
		/// <param name="albumID">The ID of the album of which you're setting a highlighted picture.</param>
		/// <param name="pictureID">The ID of the picture that you wish to use as your higlighted picture.</param>
		public abstract void SetHighlightedPicture(int albumID, int pictureID);


		/// <summary>
		/// Any inheriting classes must implement this abstract method so that it returns the next comment ID
		/// for the given album ID and picture ID.
		/// </summary>
		/// <param name="albumID">The ID of the respective album.</param>
		/// <param name="pictureID">The ID of the respective picture.</param>
		/// <returns>int</returns>
		public abstract int GetNextCommentID(int albumID, int pictureID);


		/// <summary>
		/// Any inheriting classes must implement this abstract method so that it returns the CommentCollection
		/// containing all Comment objects for the given album ID and picture ID.
		/// </summary>
		/// <param name="albumID">The ID of the respective album.</param>
		/// <param name="pictureID">The ID of the respective picture.</param>
		/// <returns>CommentCollection</returns>
		public abstract CommentCollection GetPictureComments(int albumID, int pictureID);


		/// <summary>
		/// Any inheriting classes must implement this abstract method so that it returns the given Comment object
		/// for the album ID, picture ID and comment ID given.
		/// </summary>
		/// <param name="albumID">The ID of the respective album.</param>
		/// <param name="pictureID">The ID of the respective picture.</param>
		/// <param name="commentID">The ID of the respective comment.</param>
		/// <returns>Comment</returns>
		public abstract Comment GetComment(int albumID, int pictureID, int commentID);


		/// <summary>
		/// Any inheriting classes must implement this abstract method so that it creates a comment in the datastore
		/// in the given album ID and picture ID, with the details in the Comment object.
		/// </summary>
		/// <param name="albumID">The ID of the respective album.</param>
		/// <param name="pictureID">The ID of the respective picture.</param>
		/// <param name="comment">The Comment object to be created.</param>
		public abstract void CreateComment(int albumID, int pictureID, Comment comment);


		/// <summary>
		/// Any inheriting classes must implement this abstract method so that it deletes a comment in the datastore
		/// for the given album ID, picture ID and comment ID.
		/// </summary>
		/// <param name="albumID">The ID of the respective album.</param>
		/// <param name="pictureID">The ID of the respective picture.</param>
		/// <param name="commentID">The ID of the respective comment.</param>
		public abstract void DeleteComment(int albumID, int pictureID, int commentID);


		/// <summary>
		/// Any inheriting classes must implement this abstract method so that it updates the datastore for
		/// the given album ID and picture ID with the information in the given Comment object.
		/// </summary>
		/// <param name="albumID">The ID of the respective album.</param>
		/// <param name="pictureID">The ID of the respective picture.</param>
		/// <param name="comment">The Comment object with the information to be updated.</param>
		public abstract void UpdateComment(int albumID, int pictureID, Comment comment);

		/// <summary>
		/// Increments the view count for the specified picture.
		/// </summary>
		/// <param name="albumID">ID of the album containing the picture.</param>
		/// <param name="pictureID">ID of the picture.</param>
		public abstract void UpdateViewCount(int albumID, int pictureID);


		/// <summary>
		/// Any inheriting class must implement this abstract method so that it pulls the previous Picture's
		/// ID.
		/// </summary>
		/// <param name="albumID">The ID of the album of the respective current picture.</param>
		/// <param name="pictureID">The ID of the current picture.</param>
		/// <returns>int</returns>
		public abstract int GetPreviousPictureID(int albumID, int pictureID);

		
		/// <summary>
		/// Any inheriting class must implement this abstract method so that it pulls the next Picture's
		/// ID.
		/// </summary>
		/// <param name="albumID">The ID of the album of the respective current picture.</param>
		/// <param name="pictureID">The ID of the current picture.</param>
		/// <returns>int</returns>
		public abstract int GetNextActualPictureID(int albumID, int pictureID);


		/// <summary>
		/// Any inheriting class must implement this abstract method so that it pulls the previous
		/// Album's ID.
		/// </summary>
		/// <param name="albumID">The ID of the current album.</param>
		/// <returns>int</returns>
		public abstract int GetPreviousAlbumID(int albumID);


		/// <summary>
		/// Any inheriting class must implement this abstract method so that it pulls the next
		/// Album's ID.
		/// </summary>
		/// <param name="albumID">The ID of the current album.</param>
		/// <returns>int</returns>
		public abstract int GetNextActualAlbumID(int albumID);

		/// <summary>
		/// Retrieves all of the information of the sub-ablbums of a particular album.
		/// </summary>
		/// <param name="albumID">The albumID for the album you want the sub-albums of</param>
		/// <returns>AlbumCollection</returns>
		public abstract AlbumCollection GetSubAlbums(int albumID);

		/// <summary>
		/// Retrieves all of the top level albums.
		/// </summary>
		/// <returns>AlbumCollection</returns>
		public abstract AlbumCollection GetParentAlbums();

		/// <summary>
		/// Gets the rating for a given picture.
		/// </summary>
		/// <param name="albumID">The album's ID</param>
		/// <param name="pictureID">The picture's ID</param>
		/// <returns>Rating</returns>
		public abstract Rating GetPictureRating(int albumID, int pictureID);


		/// <summary>
		/// Updates the rating for a picture.
		/// </summary>
		/// <param name="albumID">The ID of the album of the respective current picture.</param>
		/// <param name="pictureID">The ID of the picture.</param>
		/// <param name="PictureRating">The picture rating information.</param>
		public abstract void UpdatePictureRating(int albumID, int pictureID, Rating PictureRating);


		/// <summary>
		/// Returns the album ID for the given album name.
		/// </summary>
		/// <param name="albumName">The name of the album you're looking for.</param>
		/// <returns>int</returns>
		public abstract int GetAlbumIDByName(string albumName);


		// Address Book Calls

		/// <summary>
		/// Returns the next contiguous contact ID available.
		/// </summary>
		/// <returns>int</returns>
		public abstract int GetNextContactID();


		/// <summary>
		/// Returns all the contacts in the system.
		/// </summary>
		/// <returns>ContactCollection</returns>
		public abstract ContactCollection GetContacts();


		/// <summary>
		/// Creates a contact record for the given Contact object passed.
		/// </summary>
		/// <param name="contact">The Contact object to create.</param>
		public abstract void CreateContact(Contact contact);

		
		/// <summary>
		/// Returns the Contact object for the given contact ID.
		/// </summary>
		/// <param name="contactID">The ID of the contact that you wish to retrieve.</param>
		/// <returns>Contact</returns>
		public abstract Contact GetContact(int contactID);


		/// <summary>
		/// Updates the contact information for the given Contact object, keying off the contact ID.
		/// </summary>
		/// <param name="contact">The Contact object, with the new values, that you wish to update.</param>
		public abstract void UpdateContact(Contact contact);


		/// <summary>
		/// Deletes a contact record for the given contact ID.
		/// </summary>
		/// <param name="contactID">The ID of the contact that you wish to delete.</param>
		public abstract void DeleteContact(int contactID);

		// Invitation Calls

		/// <summary>
		/// Returns all invitations within the system.
		/// </summary>
		/// <returns>InvitationCollection</returns>
		public abstract InvitationCollection GetInvitations();


		/// <summary>
		/// Returns the next available, contiguous invitation ID.
		/// </summary>
		/// <returns>int</returns>
		public abstract int GetNextInvitationID();

		
		/// <summary>
		/// Creates an invitation for the given Invitation object.
		/// </summary>
		/// <param name="invite">The Invitation object that you wish to create.</param>
		public abstract void CreateInvitation(Invitation invite);


		/// <summary>
		/// Deletes an invitation for the given invitation ID.
		/// </summary>
		/// <param name="inviteID">The ID of the invitation that you wish to delete.</param>
		public abstract void DeleteInvitation(int inviteID);

		
		/// <summary>
		/// Sets the invitation read values for a given invitation's GUID.
		/// </summary>
		/// <param name="inviteGuid">The GUID of the invitation that you wish to mark as read.</param>
		public abstract void MarkInvitationRead(string inviteGuid);


		/// <summary>
		/// Returns the Invitation object for the given GUID.
		/// </summary>
		/// <param name="invitationGuid">The GUID that you wish to use to look-up the invitation.</param>
		/// <returns>Invitation</returns>
		public abstract Invitation GetInvitationByGuid(string invitationGuid);


		/// <summary>
		/// Returns the Contact object for the given GUID.
		/// </summary>
		/// <param name="invitationGuid">The GUID of the Contact that you wish to look-up.</param>
		/// <returns>Contact</returns>
		public abstract Contact GetContactByGuid(string invitationGuid);


		/// <summary>
		/// Returns all recipients of a given invitation ID.
		/// </summary>
		/// <param name="inviteID">The ID of the invitation that you want the recipients for.</param>
		/// <returns>ArrayList</returns>
		public abstract ArrayList GetInvitationRecipients(int inviteID);


		/// <summary>
		/// Returns the total number of pictures, including sub-albums, in the given album.
		/// </summary>
		/// <param name="albumID">The ID of the album in which you want the total count.</param>
		/// <returns>int</returns>
		public abstract int GetTotalPictureCount(int albumID);

		#endregion


	}
}
