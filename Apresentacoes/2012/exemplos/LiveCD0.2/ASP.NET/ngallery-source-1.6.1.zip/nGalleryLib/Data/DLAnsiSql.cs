#region Copyright and License
/*
Copyright 2003 Jason Alexander, nGallery.org
Design work copyright Thomas Johansen (http://www.aylarsolutions.com/)

GOTDOTNET WORKSPACES COMMERCIAL DERIVATIVES LICENSE
Copyright (C) 2003 Microsoft Corporation

You can use this Software for any commercial or noncommercial purpose, 
including distributing derivative works.

In return, we simply require that you agree:

1. Not to remove any copyright notices from the Software. 
2. That if you distribute the Software in source code form you do so only 
   under this License (i.e. you must include a complete copy of this License 
   with your distribution), and if you distribute the Software solely in 
   object form you only do so under a license that complies with this License. 
3. That the Software comes "as is", with no warranties. None whatsoever. This 
   means no express, implied or statutory warranty, including without 
   limitation, warranties of merchantability or fitness for a particular 
   purpose or any warranty of noninfringement. Also, you must pass this 
   disclaimer on whenever you distribute the Software.
4. That neither Microsoft nor any contributor to the Software will be liable 
   for any of those types of damages known as indirect, special, consequential, 
   or incidental related to the Software or this License, to the maximum extent 
   the law permits, no matter what legal theory it�s based on. Also, you must 
   pass this limitation of liability on whenever you distribute the Software.
5. That if you sue anyone over patents that you think may apply to the 
   Software for a person's use of the Software, your license to the Software 
   ends automatically. 
6. That the patent rights, if any, licensed hereunder only apply to the 
   Software, not to any derivative works you make. 
7. That your rights under this License end automatically if you breach it in 
   any way.
*/
#endregion
using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

using Thycotic.Data;

namespace nGallery.Lib.DL
{
	/// <summary>
	/// <c>AnsiSql</c> represents an ANSI SQL compliant generic database implementation
	/// for the DL.  This class handles all of the data layer calls involving data storage 
	/// in any ANSI SQL compliant database.  It provides the default implementation for the
	/// DL unless overridden in a specific database platforms implementation e.g. DLSQL.
	/// </summary>
	public class AnsiSql : DLBase
	{
		#region Private Fields
		private string _connectionName = "nGallery";
		#endregion

		#region Public Properties
		/// <summary>
		/// Gets and sets the ConnectionName defined in the configuration
		/// for use in connecting to the correct database.
		/// </summary>
		public virtual string ConnectionName 
		{
			get 
			{
				return _connectionName;
			}
			set 
			{
				_connectionName = value;
			}
		}
		#endregion

		#region Public Method Implementations

		/// <summary>
		/// This method connects to the database and adds the given Album object to
		/// the database.
		/// </summary>
		/// <param name="album">The Album object you wish to add/create</param>
		public override void CreateAlbum(Album album)
		{
			using (DataAccessor data = new DataAccessor()) 
			{
				DateTime createDate = DateTime.Now;
				album.CreateDate = createDate;
				data.ConnectionName = _connectionName;
				data.CommandType = CommandType.Text;
				data.CommandText = "INSERT INTO album (albumname,albumdesc,albumcreatedate) VALUES(?,?,?)";
				data.AddParameter("albumname",DbType.AnsiString,album.Name);
				data.AddParameter("albumdesc",DbType.AnsiString,album.Description);
				data.AddParameter("albumcreatedate",DbType.DateTime,album.CreateDate);
				data.ExecuteNonQuery();
				// retrieve the new id
				data.ClearParameters();
				data.CommandText = "SELECT albumid FROM album WHERE albumname=? AND albumdesc=? AND albumcreatedate=? ORDER BY albumid DESC";
				data.AddParameter("albumname",DbType.AnsiString,album.Name);
				data.AddParameter("albumdesc",DbType.AnsiString,album.Description);
				data.AddParameter("albumcreatedate",DbType.DateTime,album.CreateDate);
				IDataReader reader = data.ExecuteReader();
				if (reader.Read()) 
				{
					album.ID = reader.GetInt32(0);
				} 
				else 
				{
					throw new Exception("Failed to retrieve AlbumId for new Album.");
				}
			}
		}

		/// <summary>
		/// This method connects to the database, and attempts to add your Picture object to the
		/// given album's PictureCollection.
		/// </summary>
		/// <param name="albumID">The ID of the album to add the picture to</param>
		/// <param name="picture">The Picture object to add to the album's PictureCollection</param>
		public override void CreatePicture(int albumID, Picture picture)
		{
			using (DataAccessor data = new DataAccessor()) 
			{
				DateTime createDate = DateTime.Now;
				picture.CreateDate = createDate;
				data.ConnectionName = _connectionName;
				data.CommandType = CommandType.Text;
				data.CommandText = "INSERT INTO Picture (PictureTitle,PictureCaption,PictureCreateDate,PictureFileName,PictureHighlight,PictureAlbumID) VALUES(?,?,?,?,?,?)";
				data.AddParameter("PictureTitle",DbType.AnsiString,picture.Title);
				data.AddParameter("PictureCaption",DbType.AnsiString,picture.Caption);
				data.AddParameter("PictureCreateDate",DbType.DateTime,picture.CreateDate);
				data.AddParameter("PictureFileName",DbType.AnsiString,picture.FileName);
				data.AddParameter("PictureHighlight",DbType.Boolean,picture.HighlightPicture);
				data.AddParameter("PictureAlbumID",DbType.Int32,albumID);
				data.ExecuteNonQuery();
				// retrieve the new id
				data.ClearParameters();
				data.CommandText = "SELECT PictureId FROM Picture WHERE PictureTitle=? AND PictureCaption=? AND PictureCreateDate=? AND PictureFileName=? AND PictureHighlight=? AND PictureAlbumID=? ORDER BY PictureId DESC";
				data.AddParameter("PictureTitle",DbType.AnsiString,picture.Title);
				data.AddParameter("PictureCaption",DbType.AnsiString,picture.Caption);
				data.AddParameter("PictureCreateDate",DbType.DateTime,picture.CreateDate);
				data.AddParameter("PictureFileName",DbType.AnsiString,picture.FileName);
				data.AddParameter("PictureHighlight",DbType.Boolean,picture.HighlightPicture);
				data.AddParameter("PictureAlbumID",DbType.Int32,albumID);
				IDataReader reader = data.ExecuteReader();
				if (reader.Read()) 
				{
					picture.ID = reader.GetInt32(0);
				} 
				else 
				{
					throw new Exception("Failed to retrieve PictureId for new Album.");
				}
			}
		}
		
		/// <summary>
		/// This method connects to the database, and attempts to delete it from
		/// the main AlbumCollection data store.
		/// </summary>
		/// <param name="albumID">The ID of the album to delete</param>
		public override void DeleteAlbum(int albumID)
		{
			using (DataAccessor data = new DataAccessor()) 
			{
				data.ConnectionName = _connectionName;
				data.CommandType = CommandType.Text;
				data.CommandText = "DELETE FROM Album WHERE AlbumID=?";
				data.AddParameter("AlbumID",DbType.Int32,albumID);
				data.ExecuteNonQuery();
			}
		}

		/// <summary>
		/// This method connects to the database, and attempt to delete the picture in the given
		/// album ID.
		/// </summary>
		/// <param name="albumID">The ID of the album to look in</param>
		/// <param name="pictureID">The ID of the picture to attempt to delete</param>
		public override void DeletePicture(int albumID, int pictureID)
		{
			using (DataAccessor data = new DataAccessor()) 
			{
				data.ConnectionName = _connectionName;
				data.CommandType = CommandType.Text;
				data.CommandText = "DELETE FROM Picture WHERE PictureAlbumID=? AND PictureID=?";
				data.AddParameter("PictureAlbumID",DbType.Int32,albumID);
				data.AddParameter("PictureID",DbType.Int32,pictureID);
				data.ExecuteNonQuery();
			}
		}

		/// <summary>
		/// This method connects to the database, and returns the Album object for the
		/// given album ID.
		/// </summary>
		/// <param name="albumID">The ID of the album you wish to retrieve</param>
		/// <returns>Album</returns>
		public override Album GetAlbum(int albumID)
		{
			Album album = null;
			using (DataAccessor data = new DataAccessor()) 
			{
				data.ConnectionName = _connectionName;
				data.CommandType = CommandType.Text;
				data.CommandText = "SELECT * FROM Album WHERE albumid=?";
				data.AddParameter("albumid",DbType.Int32,albumID);
				DataTable table = data.ExecuteDataTable();
				if (table.Rows.Count > 0) 
				{
					album = GetAlbum(table.Rows[0]);
				} 
				else 
				{
					throw new Exception("Failed to load Album.");
				}
			}
			return album;
		}

		/// <summary>
		/// Gets the identifier for the album with a particular album name.
		/// </summary>
		/// <param name="albumName">The name of the album you wish to retrieve.</param>
		/// <returns>Album</returns>
		public override int GetAlbumIDByName(string albumName)
		{
			Album album = null;
			using (DataAccessor data = new DataAccessor()) 
			{
				data.ConnectionName = _connectionName;
				data.CommandType = CommandType.Text;
				data.CommandText = "SELECT * FROM Album WHERE albumname=?";
				data.AddParameter("albumname",DbType.AnsiString,albumName);
				DataTable table = data.ExecuteDataTable();
				if (table.Rows.Count > 0) 
				{
					album = GetAlbum(table.Rows[0]);
				} 
				else 
				{
					throw new Exception("Failed to load Album.");
				}
			}
			return album.ID;
		}

		/// <summary>
		/// This method connects to the database, and retrieves the PictureCollection
		/// for the given album ID.
		/// </summary>
		/// <param name="albumID">The ID of the album that you wish to retrieve the pictures for</param>
		/// <returns>PictureCollection</returns>
		public override PictureCollection GetAlbumPictures(int albumID)
		{
			PictureCollection pictures = new PictureCollection();
			using (DataAccessor data = new DataAccessor()) 
			{
				data.ConnectionName = _connectionName;
				data.CommandType = CommandType.Text;
				data.CommandText = "SELECT * FROM picture WHERE picturealbumid=?";
				data.AddParameter("picturealbumid",DbType.Int32,albumID);
				DataTable table = data.ExecuteDataTable();
				int rows = table.Rows.Count;
				for (int n = 0; n < rows; n++) 
				{
					Picture picture = this.GetPicture(albumID,table.Rows[n]);
					pictures.Add(picture);
				}
			}
			return pictures;
		}

		private Album GetAlbum(DataRow row) 
		{
			Album myAlbum		= new Album();
			myAlbum.ID			= (int) row["albumid"];
			myAlbum.Name		= row["albumname"].ToString();
			myAlbum.Description	= row["albumdesc"].ToString();
			myAlbum.CreateDate	= (DateTime) row["albumcreatedate"];
			myAlbum.Pictures	= this.GetAlbumPictures(myAlbum.ID);
			return myAlbum;
		}

		private Picture GetPicture(int albumID,DataRow row) 
		{
			Picture myPicture		= new Picture();
			myPicture.ID			= (int) row["pictureid"];
			myPicture.Title			= row["picturetitle"].ToString();
			myPicture.Caption		= row["picturecaption"].ToString();
			// TODO: is this the best way to handle nulls?
			if (row["PictureCreateDate"] == System.DBNull.Value) 
			{
				myPicture.CreateDate = DateTime.Now;
			} 
			else 
			{
				myPicture.CreateDate	= (DateTime) row["PictureCreateDate"];
			}
			// TODO: is this null handling ok?
			if (row["picturehighlight"] == null || row["picturehighlight"] == System.DBNull.Value) 
			{
				myPicture.HighlightPicture = false;
			} 
			else 
			{
				if (row["picturehighlight"] is SByte) 
				{
					myPicture.HighlightPicture = Convert.ToInt32(row["picturehighlight"]).Equals(1);
				} 
				else 
				{
					myPicture.HighlightPicture = (bool) row["picturehighlight"];
				}
			}
			myPicture.FileName		= row["PictureFileName"].ToString();
			myPicture.Comments = this.GetPictureComments(albumID,myPicture.ID);
			return myPicture;
		}

		private Comment GetComment(DataRow row) 
		{
			Comment myComment		= new Comment();
			myComment.ID			= (int) row["commentid"];
			myComment.FromName		= row["commentfromname"].ToString();
			myComment.FromEmailAddr = row["commentfromemailaddr"].ToString();
			myComment.FromWebURL	= row["commentfromweburl"].ToString();
			myComment.CommentText	= row["commenttext"].ToString();
			// TODO: is this the best way to handle nulls?
			if (row["CommentDateSubmitted"] == System.DBNull.Value) 
			{
				myComment.CreateDate = DateTime.Now;
			} 
			else 
			{
				myComment.CreateDate	= (DateTime) row["CommentDateSubmitted"];
			}
			return myComment;
		}

		/// <summary>
		/// This method connects to the database, and returns all the albums in it.
		/// </summary>
		/// <returns>AlbumCollection</returns>
		public override AlbumCollection GetAlbums()
		{
			AlbumCollection albums = new AlbumCollection();
			using (DataAccessor data = new DataAccessor()) 
			{
				data.ConnectionName = _connectionName;
				data.CommandType = CommandType.Text;
				data.CommandText = "SELECT * FROM album ORDER BY AlbumCreateDate DESC";
				DataTable table = data.ExecuteDataTable();
				int rows = table.Rows.Count;
				for (int n = 0; n < rows; n++) 
				{
					Album album = this.GetAlbum(table.Rows[n]);
					albums.Add(album);
				}
			}
			return albums;
		}

		/// <summary>
		/// Gets the ID of the next unique album.
		/// </summary>
		/// <returns>int</returns>
		public override int GetNextAlbumID()
		{
			using (DataAccessor data = new DataAccessor()) 
			{
				data.ConnectionName = _connectionName;
				data.CommandType = CommandType.Text;
				data.CommandText = "SELECT max(albumid)+1 FROM Album";
				IDataReader reader = data.ExecuteReader();
				if (reader.Read()) 
				{
					object o = reader.GetValue(0);
					if (o == null || o == System.DBNull.Value) 
					{
						return 1;
					} 
					else 
					{
						// NOTE: MySQL returns the max + 1 as an Int64 
						// hence the Convert is necessary (and safer)
						return Convert.ToInt32(o);
					}
				} 
				else 
				{
					throw new Exception("Failed to retrieve next AlbumID.");
				}
			}
		}

		/// <summary>
		/// Gets the ID of the next unique picture.
		/// </summary>
		/// <param name="albumID">Album ID for the album the picture is in (not used in SQL Server implementation)</param>
		/// <returns>int</returns>
		public override int GetNextPictureID(int albumID)
		{
			using (DataAccessor data = new DataAccessor()) 
			{
				data.ConnectionName = _connectionName;
				data.CommandType = CommandType.Text;
				data.CommandText = "SELECT max(pictureid)+1 FROM Picture";
				IDataReader reader = data.ExecuteReader();
				if (reader.Read()) 
				{
					object o = reader.GetValue(0);
					if (o == null || o == System.DBNull.Value) 
					{
						return 1;
					} 
					else 
					{
						// NOTE: MySQL returns the max + 1 as an Int64 
						// hence the Convert is necessary (and safer)
						return Convert.ToInt32(o);
					}
				} 
				else 
				{
					throw new Exception("Failed to retrieve next PictureID.");
				}
			}
		}

		/// <summary>
		/// This method connects to the database, and attempts to retrieve the Picture
		/// object for the given album ID and picture ID.
		/// </summary>
		/// <param name="albumID">The ID of the album you wish to look in</param>
		/// <param name="pictureID">The ID of the picture you wish to retrieve</param>
		/// <returns>Picture</returns>
		public override Picture GetPicture(int albumID, int pictureID)
		{
			using (DataAccessor data = new DataAccessor()) 
			{
				data.ConnectionName = _connectionName;
				data.CommandType = CommandType.Text;
				data.CommandText = "SELECT * FROM picture WHERE picturealbumid=? AND pictureid=?";
				data.AddParameter("picturealbumid",DbType.Int32,albumID);
				data.AddParameter("pictureid",DbType.Int32,pictureID);
				DataTable table = data.ExecuteDataTable();
				int rows = table.Rows.Count;
				if (table.Rows.Count == 1)
				{
					Picture picture = this.GetPicture(albumID,table.Rows[0]);
					return picture;
				} 
				else 
				{
					if (table.Rows.Count > 1) 
					{
						throw new Exception("Could not identify unique Picture.");
					} 
					else 
					{
						throw new Exception("Failed to load Picture.");
					}
				}
			}
		}

		/// <summary>
		/// This method connects to the database, and attempts to update the Album
		/// in the AlbumCollection based on Album.ID.
		/// </summary>
		/// <param name="album">The Album instance you wish to update</param>
		public override void UpdateAlbum(Album album)
		{
			using (DataAccessor data = new DataAccessor()) 
			{
				data.ConnectionName = _connectionName;
				data.CommandType = CommandType.Text;
				data.CommandText = "UPDATE Album SET AlbumName=?,AlbumDesc=?,AlbumCreateDate=? WHERE AlbumId=?";
				data.AddParameter("AlbumName",DbType.AnsiString,album.Name);
				data.AddParameter("AlbumDesc",DbType.AnsiString,album.Description);
				data.AddParameter("AlbumCreateDate",DbType.DateTime,album.CreateDate);
				data.AddParameter("AlbumId",DbType.Int32,album.ID);
				data.ExecuteNonQuery();
			}
		}

		/// <summary>
		/// This method sets the given picture as the highlighted Picture for the given
		/// album ID.
		/// </summary>
		/// <param name="albumID">The ID of the album you wish to set a highlighted picture for</param>
		/// <param name="pictureID">The ID of the picture you wish to set as the highlighted picture</param>
		public override void SetHighlightedPicture(int albumID, int pictureID)
		{
			using (DataAccessor data = new DataAccessor()) 
			{
				data.ConnectionName = _connectionName;
				data.CommandType = CommandType.Text;
				data.CommandText = "UPDATE Picture SET PictureHighlight=0 WHERE PictureAlbumID=? AND PictureHighlight = 1";
				data.AddParameter("PictureAlbumID",DbType.Int32,albumID);
				data.ExecuteNonQuery();
				data.ClearParameters();
				data.CommandText = "UPDATE Picture SET PictureHighlight=1 WHERE PictureID=? AND PictureAlbumID=?";
				data.AddParameter("PictureID",DbType.Int32,pictureID);
				data.AddParameter("PictureAlbumID",DbType.Int32,albumID);
				data.ExecuteNonQuery();
			}																					
		}

		/// <summary>
		/// This method connects to the database, and attempts to update the Picture object based
		/// on the given album ID and picture.ID.
		/// </summary>
		/// <param name="albumID">The ID of the album to look in for the update</param>
		/// <param name="picture">The Picture object to update in the album</param>
		public override void UpdatePicture(int albumID, Picture picture)
		{
			using (DataAccessor data = new DataAccessor()) 
			{
				data.ConnectionName = _connectionName;
				data.CommandType = CommandType.Text;
				data.CommandText = "UPDATE Picture SET PictureTitle=?,PictureCaption=?,PictureFileName=?,PictureHighlight=? WHERE PictureId=? AND PictureAlbumId=?";
				data.AddParameter("PictureTitle",DbType.AnsiString,picture.Title);
				data.AddParameter("PictureCaption",DbType.AnsiString,picture.Caption);
				data.AddParameter("PictureFileName",DbType.AnsiString,picture.FileName);
				data.AddParameter("PictureHighlight",DbType.Boolean,picture.HighlightPicture);
				data.AddParameter("PictureId",DbType.Int32,picture.ID);
				data.AddParameter("PictureAlbumId",DbType.Int32,albumID);
				data.ExecuteNonQuery();
			}
		}

		/// <summary>
		/// Gets the next unique ID for a comment.
		/// </summary>
		/// <param name="albumID">The album ID for the comment (ignored in SQL Server implementation)</param>
		/// <param name="pictureID">The picture ID for the comment (ignored in SQL Server implementation)</param>
		/// <returns>int</returns>
		public override int GetNextCommentID(int albumID, int pictureID)
		{
			using (DataAccessor data = new DataAccessor()) 
			{
				data.ConnectionName = _connectionName;
				data.CommandType = CommandType.Text;
				data.CommandText = "SELECT max(commentid)+1 FROM Comment";
				IDataReader reader = data.ExecuteReader();
				if (reader.Read()) 
				{
					object o = reader.GetValue(0);
					if (o == null || o == System.DBNull.Value) 
					{
						return 1;
					} 
					else 
					{
						// NOTE: MySQL returns the max + 1 as an Int64 
						// hence the Convert is necessary (and safer)
						return Convert.ToInt32(o);
					}
				} 
				else 
				{
					throw new Exception("Failed to retrieve next CommentID.");
				}
			}
		}

		/// <summary>
		/// This method returns the CommentCollection containing all Comment objects for
		/// a given album ID and picture ID.
		/// </summary>
		/// <param name="albumID">The ID of the respective album.</param>
		/// <param name="pictureID">The ID of the respective picture.</param>
		/// <returns>CommentCollection</returns>
		public override CommentCollection GetPictureComments(int albumID, int pictureID)
		{
			using (DataAccessor data = new DataAccessor()) 
			{
				data.ConnectionName = _connectionName;
				data.CommandType = CommandType.Text;
				data.CommandText = "SELECT * FROM comment WHERE commentalbumid=? AND commentpictureid=?";
				data.AddParameter("commentalbumid",DbType.Int32,albumID);
				data.AddParameter("commentpictureid",DbType.Int32,pictureID);
				DataTable table = data.ExecuteDataTable();
				int rows = table.Rows.Count;
				CommentCollection comments = new CommentCollection();
				for (int n = 0; n < rows; n++)
				{
					Comment comment = this.GetComment(table.Rows[n]);
					comments.Add(comment);
				} 
				return comments;
			}
		}

		/// <summary>
		/// This method returns the specific Comment object for the given Album, Picture and Comment ID.
		/// </summary>
		/// <param name="albumID">The ID of the respective album.</param>
		/// <param name="pictureID">The ID of the respective picture.</param>
		/// <param name="commentID">The ID of the respective comment.</param>
		/// <returns>Comment</returns>
		public override Comment GetComment(int albumID, int pictureID, int commentID)
		{
			using (DataAccessor data = new DataAccessor()) 
			{
				data.ConnectionName = _connectionName;
				data.CommandType = CommandType.Text;
				data.CommandText = "SELECT * FROM Comment WHERE CommentAlbumID=? AND CommentPictureID=? AND CommentID=?";
				data.AddParameter("CommentAlbumID",DbType.Int32,albumID);
				data.AddParameter("CommentPictureID",DbType.Int32,pictureID);
				data.AddParameter("CommentID",DbType.Int32,commentID);
				DataTable table = data.ExecuteDataTable();
				int rows = table.Rows.Count;
				if (table.Rows.Count == 1)
				{
					Comment comment = this.GetComment(table.Rows[0]);
					return comment;
				} 
				else 
				{
					if (table.Rows.Count > 1) 
					{
						throw new Exception("Could not identify unique Comment.");
					} 
					else 
					{
						throw new Exception("Failed to load Comment.");
					}
				}
			}
		}

		/// <summary>
		/// This method attempts to create a comment for a given album ID, picture ID and the respective
		/// Comment object.
		/// </summary>
		/// <param name="albumID">The ID of the album in which to create the Comment</param>
		/// <param name="pictureID">The ID of the picture in which to create a Comment</param>
		/// <param name="comment">The Comment object to create</param>
		public override void CreateComment(int albumID, int pictureID, Comment comment)
		{
			using (DataAccessor data = new DataAccessor()) 
			{
				data.ConnectionName = _connectionName;
				data.CommandType = CommandType.Text;
				data.CommandText = "INSERT INTO Comment (CommentAlbumID,CommentPictureID,CommentFromName,CommentFromEmailAddr, CommentFromWebURL, CommentText, CommentDateSubmitted) VALUES(?,?,?,?,?,?,?)";
				data.AddParameter("commentalbumid",DbType.Int32,albumID);
				data.AddParameter("commentpictureid",DbType.Int32,pictureID);
				data.AddParameter("fromname",DbType.AnsiString,comment.FromName);
				data.AddParameter("fromemailaddr",DbType.AnsiString,comment.FromEmailAddr);
				data.AddParameter("fromweburl",DbType.AnsiString,comment.FromWebURL);
				data.AddParameter("text",DbType.AnsiString,comment.CommentText);
				data.AddParameter("datesubmitted",DbType.DateTime,DateTime.Now);
				data.ExecuteNonQuery();
			}
		}

		/// <summary>
		/// This method deletes a comment for the given album ID, picture ID and comment ID.
		/// </summary>
		/// <param name="albumID">The ID of the respective album.</param>
		/// <param name="pictureID">The ID of the respective picture.</param>
		/// <param name="commentID">The ID of the respective comment.</param>
		public override void DeleteComment(int albumID, int pictureID, int commentID)
		{
			using (DataAccessor data = new DataAccessor()) 
			{
				data.ConnectionName = _connectionName;
				data.CommandType = CommandType.Text;
				data.CommandText = "DELETE FROM Comment WHERE CommentAlbumID=? AND CommentPictureID=? AND CommentID=?";
				data.AddParameter("CommentAlbumID",DbType.Int32,albumID);
				data.AddParameter("CommentPictureID",DbType.Int32,pictureID);
				data.AddParameter("CommentID",DbType.Int32,commentID);
				data.ExecuteNonQuery();
			}
		}

		/// <summary>
		/// This method attempts to update a Comment for a given album ID, picture ID and Comment.
		/// </summary>
		/// <param name="albumID">The ID of the album in which to update the Comment</param>
		/// <param name="pictureID">The ID of the picture in which to update the Comment</param>
		/// <param name="comment"></param>
		public override void UpdateComment(int albumID, int pictureID, Comment comment)
		{
			using (DataAccessor data = new DataAccessor()) 
			{
				data.ConnectionName = _connectionName;
				data.CommandType = CommandType.Text;
				data.CommandText = "UPDATE Comment SET CommentFromName=?,CommentFromEmailAddr=?,CommentFromWebURL=?,CommentText=? WHERE CommentAlbumID=? AND CommentPictureID=? AND CommentID=?";
				data.AddParameter("CommentFromName",DbType.AnsiString,comment.FromName);
				data.AddParameter("CommentFromEmailAddr",DbType.AnsiString,comment.FromEmailAddr);
				data.AddParameter("CommentFromWebURL",DbType.AnsiString,comment.FromWebURL);
				data.AddParameter("CommentText",DbType.AnsiString,comment.CommentText);
				data.AddParameter("CommentAlbumID",DbType.Int32,albumID);
				data.AddParameter("CommentPictureID",DbType.Int32,pictureID);
				data.AddParameter("CommentID",DbType.Int32,comment.ID);
				data.ExecuteNonQuery();
			}
		}
		#endregion

		#region Methods still to implement


		/// <summary>
		/// This method returns the next album's ID for the given album ID.
		/// </summary>
		/// <param name="i">The ID of the current album.</param>
		/// <returns>int</returns>
		public override int GetNextActualAlbumID(int i) 
		{
			throw new NotImplementedException();
		}


		/// <summary>
		/// This method returns the next picture's ID for the given album ID and picture ID.
		/// </summary>
		/// <param name="n">The ID of the album for the current picture.</param>
		/// <param name="j">The ID of the current picture.</param>
		/// <returns>int</returns>
		public override int GetNextActualPictureID(int n,int j) 
		{
			throw new NotImplementedException();
		}


		/// <summary>
		/// Retrieves all of the top level albums.
		/// </summary>
		/// <returns>AlbumCollection</returns>
		public override AlbumCollection GetParentAlbums()
		{
			throw new NotImplementedException();
		}


		/// <summary>
		/// Gets the rating for a given picture.
		/// </summary>
		/// <param name="albumID">The album's ID</param>
		/// <param name="pictureID">The picture's ID</param>
		/// <returns>Rating</returns>
		public override Rating GetPictureRating(int albumID, int pictureID)
		{
			throw new NotImplementedException();
		}


		/// <summary>
		/// This method returns the previous album's ID for the given album ID.
		/// </summary>
		/// <param name="albumID">The ID of the current album.</param>
		/// <returns>int</returns>
		public override int GetPreviousAlbumID(int albumID)
		{
			throw new NotImplementedException();
		}


		/// <summary>
		/// This method returns the previous picture's ID for the given album ID and picture ID.
		/// </summary>
		/// <param name="albumID">The ID of the album for the current picture.</param>
		/// <param name="pictureID">The ID of the current picture.</param>
		/// <returns>int</returns>
		public override int GetPreviousPictureID(int albumID, int pictureID)
		{
			throw new NotImplementedException();
		}


		/// <summary>
		/// Retrieves all of the information of the sub-ablbums of a particular album.
		/// </summary>
		/// <param name="albumID">The albumID for the album you want the sub-albums of</param>
		/// <returns>AlbumCollection</returns>
		public override AlbumCollection GetSubAlbums(int albumID)
		{
			throw new NotImplementedException();
		}


		/// <summary>
		/// Updates the rating for a picture.
		/// </summary>
		/// <param name="albumID">The ID of the album of the respective current picture.</param>
		/// <param name="pictureID">The ID of the picture.</param>
		/// <param name="PictureRating">The picture rating information.</param>
		public override void UpdatePictureRating(int albumID, int pictureID, Rating PictureRating)
		{
			throw new NotImplementedException();
		}


		/// <summary>
		/// Increments the view count for the specified picture.
		/// </summary>
		/// <param name="albumID">ID of the album containing the picture.</param>
		/// <param name="pictureID">ID of the picture.</param>
		public override void UpdateViewCount(int albumID, int pictureID)
		{
			throw new NotImplementedException();
		}


		/// <summary>
		/// Creates a contact record for the given Contact object passed.
		/// </summary>
		/// <param name="contact">The Contact object to create.</param>
		public override void CreateContact(Contact contact)
		{
			throw new NotImplementedException();
		}


		/// <summary>
		/// Creates an invitation for the given Invitation object.
		/// </summary>
		/// <param name="invite">The Invitation object that you wish to create.</param>
		public override void CreateInvitation(Invitation invite)
		{
			throw new NotImplementedException();
		}


		/// <summary>
		/// Deletes a contact record for the given contact ID.
		/// </summary>
		/// <param name="contactID">The ID of the contact that you wish to delete.</param>
		public override void DeleteContact(int contactID)
		{
			throw new NotImplementedException();
		}


		/// <summary>
		/// Deletes an invitation for the given invitation ID.
		/// </summary>
		/// <param name="inviteID">The ID of the invitation that you wish to delete.</param>
		public override void DeleteInvitation(int inviteID)
		{
			throw new NotImplementedException();
		}


		/// <summary>
		/// Returns the Contact object for the given contact ID.
		/// </summary>
		/// <param name="contactID">The ID of the contact that you wish to retrieve.</param>
		/// <returns>Contact</returns>
		public override Contact GetContact(int contactID)
		{
			throw new NotImplementedException();
		}


		/// <summary>
		/// Returns the Contact object for the given GUID.
		/// </summary>
		/// <param name="invitationGuid">The GUID of the Contact that you wish to look-up.</param>
		/// <returns>Contact</returns>
		public override Contact GetContactByGuid(string invitationGuid)
		{
			throw new NotImplementedException();
		}


		/// <summary>
		/// Returns all the contacts in the system.
		/// </summary>
		/// <returns>ContactCollection</returns>
		public override ContactCollection GetContacts()
		{
			throw new NotImplementedException();
		}


		/// <summary>
		/// Returns the Invitation object for the given GUID.
		/// </summary>
		/// <param name="invitationGuid">The GUID that you wish to use to look-up the invitation.</param>
		/// <returns>Invitation</returns>
		public override Invitation GetInvitationByGuid(string invitationGuid)
		{
			throw new NotImplementedException();
		}


		/// <summary>
		/// Returns all recipients of a given invitation ID.
		/// </summary>
		/// <param name="inviteID">The ID of the invitation that you want the recipients for.</param>
		/// <returns>ArrayList</returns>
		public override System.Collections.ArrayList GetInvitationRecipients(int inviteID)
		{
			throw new NotImplementedException();
		}


		/// <summary>
		/// Returns all invitations within the system.
		/// </summary>
		/// <returns>InvitationCollection</returns>
		public override InvitationCollection GetInvitations()
		{
			throw new NotImplementedException();
		}


		/// <summary>
		/// Returns the next contiguous contact ID available.
		/// </summary>
		/// <returns>int</returns>
		public override int GetNextContactID()
		{
			throw new NotImplementedException();
		}


		/// <summary>
		/// Returns the next available, contiguous invitation ID.
		/// </summary>
		/// <returns>int</returns>
		public override int GetNextInvitationID()
		{
			throw new NotImplementedException();
		}


		/// <summary>
		/// Returns the total number of pictures, including sub-albums, in the given album.
		/// </summary>
		/// <param name="albumID">The ID of the album in which you want the total count.</param>
		/// <returns>int</returns>
		public override int GetTotalPictureCount(int albumID)
		{
			throw new NotImplementedException();
		}


		/// <summary>
		/// Sets the invitation read values for a given invitation's GUID.
		/// </summary>
		/// <param name="inviteGuid">The GUID of the invitation that you wish to mark as read.</param>
		public override void MarkInvitationRead(string inviteGuid)
		{
			throw new NotImplementedException();
		}


		/// <summary>
		/// Updates the contact information for the given Contact object, keying off the contact ID.
		/// </summary>
		/// <param name="contact">The Contact object, with the new values, that you wish to update.</param>
		public override void UpdateContact(Contact contact)
		{
			throw new NotImplementedException();
		}


		#endregion

	}
}
