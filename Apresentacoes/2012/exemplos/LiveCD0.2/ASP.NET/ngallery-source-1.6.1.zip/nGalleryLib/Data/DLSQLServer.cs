#region Copyright and License
/*
Copyright 2003 Jason Alexander, nGallery.org
Design work copyright Thomas Johansen (http://www.aylarsolutions.com/)

GOTDOTNET WORKSPACES COMMERCIAL DERIVATIVES LICENSE
Copyright (C) 2003 Microsoft Corporation

You can use this Software for any commercial or noncommercial purpose, 
including distributing derivative works.

In return, we simply require that you agree:

1. Not to remove any copyright notices from the Software. 
2. That if you distribute the Software in source code form you do so only 
   under this License (i.e. you must include a complete copy of this License 
   with your distribution), and if you distribute the Software solely in 
   object form you only do so under a license that complies with this License. 
3. That the Software comes "as is", with no warranties. None whatsoever. This 
   means no express, implied or statutory warranty, including without 
   limitation, warranties of merchantability or fitness for a particular 
   purpose or any warranty of noninfringement. Also, you must pass this 
   disclaimer on whenever you distribute the Software.
4. That neither Microsoft nor any contributor to the Software will be liable 
   for any of those types of damages known as indirect, special, consequential, 
   or incidental related to the Software or this License, to the maximum extent 
   the law permits, no matter what legal theory it�s based on. Also, you must 
   pass this limitation of liability on whenever you distribute the Software.
5. That if you sue anyone over patents that you think may apply to the 
   Software for a person's use of the Software, your license to the Software 
   ends automatically. 
6. That the patent rights, if any, licensed hereunder only apply to the 
   Software, not to any derivative works you make. 
7. That your rights under this License end automatically if you breach it in 
   any way.
*/
#endregion
using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;


namespace nGallery.Lib.DL
{
	/// <summary>
	/// This class is the SQL Server based DL class.  This class handles all of
	/// the data layer calls involving data storage in a SQL Server database.  It provides
	/// the specific implementation of the for the generic interfaces defined in the sublcass.
	/// </summary>
	public class SQL : DLBase
	{


		#region Private Methods

		private void CreateInvitationContact(int inviteID, int contactID, string GUID)
		{
			SqlConnection conn	= new SqlConnection(nGallery.Lib.Configuration.Instance().ConnectionString);
			SqlCommand comm		= new SqlCommand();

			// setup the connection
			comm.Connection		= conn;
			comm.CommandText	= "ngCreateInvitationContact";
			comm.CommandType	= CommandType.StoredProcedure;

			// pass the parameters
			comm.Parameters.Add("@InvitationID", inviteID);
			comm.Parameters.Add("@ContactID", contactID);
			comm.Parameters.Add("@GUID", GUID);

			// execute the statement
			conn.Open();
			comm.ExecuteNonQuery();

			// clean up
			if (conn.State == ConnectionState.Open)
			{
				conn.Close();
			}
			conn.Dispose();
			comm.Dispose();
		}

		#endregion


		#region Public Method Implementations


		/// <summary>
		/// This method connects to the database and adds the given Album object to
		/// the database.
		/// </summary>
		/// <param name="album">The Album object you wish to add/create</param>
		public override void CreateAlbum(Album album)
		{
			SqlConnection conn	= new SqlConnection(nGallery.Lib.Configuration.Instance().ConnectionString);
			SqlCommand comm		= new SqlCommand();

			// setup the connection
			comm.Connection		= conn;
			comm.CommandText	= "ngCreateAlbum";
			comm.CommandType	= CommandType.StoredProcedure;

			// pass the parameters
			comm.Parameters.Add("@AlbumName", album.Name);
			comm.Parameters.Add("@AlbumDesc", album.Description);
			comm.Parameters.Add("@ParentAlbumID", album.ParentAlbumID);

			// execute the statement
			conn.Open();
			comm.ExecuteNonQuery();

			// clean up
			if (conn.State == ConnectionState.Open)
			{
				conn.Close();
			}
			conn.Dispose();
			comm.Dispose();
		}

		/// <summary>
		/// This method connects to the database, and attempts to add your Picture object to the
		/// given album's PictureCollection.
		/// </summary>
		/// <param name="albumID">The ID of the album to add the picture to</param>
		/// <param name="picture">The Picture object to add to the album's PictureCollection</param>
		public override void CreatePicture(int albumID, Picture picture)
		{
			SqlConnection conn	= new SqlConnection(nGallery.Lib.Configuration.Instance().ConnectionString);
			SqlCommand comm		= new SqlCommand();

			// setup the connection
			comm.Connection		= conn;
			comm.CommandText	= "ngCreatePicture";
			comm.CommandType	= CommandType.StoredProcedure;

			// pass the parameters
			comm.Parameters.Add("@Title", picture.Title);
			comm.Parameters.Add("@Caption", picture.Caption);
			comm.Parameters.Add("@FileName", picture.FileName);
			comm.Parameters.Add("@Highlight", picture.HighlightPicture);
			comm.Parameters.Add("@AlbumID", albumID);
			comm.Parameters.Add("@Height", picture.Height);
			comm.Parameters.Add("@Width", picture.Width);

			// execute the statement
			conn.Open();
			comm.ExecuteNonQuery();

			// clean up
			if (conn.State == ConnectionState.Open)
			{
				conn.Close();
			}
			conn.Dispose();
			comm.Dispose();
		}
		
		/// <summary>
		/// This method connects to the database, and attempts to delete it from
		/// the main AlbumCollection data store.
		/// </summary>
		/// <param name="albumID">The ID of the album to delete</param>
		public override void DeleteAlbum(int albumID)
		{
			SqlConnection conn	= new SqlConnection(nGallery.Lib.Configuration.Instance().ConnectionString);
			SqlCommand comm		= new SqlCommand();

			// setup the connection
			comm.Connection		= conn;
			comm.CommandText	= "ngDeleteAlbum";
			comm.CommandType	= CommandType.StoredProcedure;

			// pass the parameters
			comm.Parameters.Add("@AlbumID", albumID);

			// execute the statement
			conn.Open();
			comm.ExecuteNonQuery();

			// clean up
			if (conn.State == ConnectionState.Open)
			{
				conn.Close();
			}
			conn.Dispose();
			comm.Dispose();
		}

		/// <summary>
		/// This method connects to the database, and attempt to delete the picture in the given
		/// album ID.
		/// </summary>
		/// <param name="albumID">The ID of the album to look in</param>
		/// <param name="pictureID">The ID of the picture to attempt to delete</param>
		public override void DeletePicture(int albumID, int pictureID)
		{
			SqlConnection conn	= new SqlConnection(nGallery.Lib.Configuration.Instance().ConnectionString);
			SqlCommand comm		= new SqlCommand();

			// setup the connection
			comm.Connection		= conn;
			comm.CommandText	= "ngDeletePicture";
			comm.CommandType	= CommandType.StoredProcedure;

			// pass the parameters
			comm.Parameters.Add("@AlbumID", albumID);
			comm.Parameters.Add("@PictureID", pictureID);

			// execute the statement
			conn.Open();
			comm.ExecuteNonQuery();

			// clean up
			if (conn.State == ConnectionState.Open)
			{
				conn.Close();
			}
			conn.Dispose();
			comm.Dispose();
		}

		/// <summary>
		/// This method connects to the database, and returns the Album object for the
		/// given album ID.
		/// </summary>
		/// <param name="albumID">The ID of the album you wish to retrieve</param>
		/// <returns>Album</returns>
		public override Album GetAlbum(int albumID)
		{
			SqlConnection conn	= new SqlConnection(nGallery.Lib.Configuration.Instance().ConnectionString);
			SqlCommand comm		= new SqlCommand();
			Album myAlbum		= new Album();

			// setup the connection
			comm.Connection		= conn;
			comm.CommandText	= "ngGetAlbum";
			comm.CommandType	= CommandType.StoredProcedure;

			// pass the parameter
			comm.Parameters.Add("@AlbumID", albumID);

			// execute the statement
			try
			{
				conn.Open();
				SqlDataReader results = comm.ExecuteReader();
				results.Read();

				try
				{
					// put together the return variable
					myAlbum.ID			= results.GetInt32(0);
					myAlbum.Name		= results.GetString(1);
					myAlbum.Description	= results.GetString(2);
					myAlbum.CreateDate	= results.GetDateTime(3);
					myAlbum.ParentAlbumID = results.GetInt32(4);

					myAlbum.Pictures = this.GetAlbumPictures(albumID);
				}
				finally
				{
					if (!results.IsClosed)
					{
						results.Close();
					}
				}
			}
			finally
			{
				// clean up
				if (conn.State == ConnectionState.Open)
				{
					conn.Close();
				}
				conn.Dispose();
				comm.Dispose();
			}
			return myAlbum;
		}

		/// <summary>
		/// This method connects to the database, and retrieves the PictureCollection
		/// for the given album ID.
		/// </summary>
		/// <param name="albumID">The ID of the album that you wish to retrieve the pictures for</param>
		/// <returns>PictureCollection</returns>
		public override PictureCollection GetAlbumPictures(int albumID)
		{
			SqlConnection conn	= new SqlConnection(nGallery.Lib.Configuration.Instance().ConnectionString);
			SqlCommand comm		= new SqlCommand();
			PictureCollection pictures = new PictureCollection();

			comm.Connection		= conn;
			comm.CommandText	= "ngGetAlbumPictures";
			comm.CommandType	= CommandType.StoredProcedure;

			comm.Parameters.Add("@AlbumID", albumID);

			try
			{
				conn.Open();
				SqlDataReader results = comm.ExecuteReader();

				try
				{
					while (results.Read())
					{
						Picture myPicture = new Picture();

						myPicture.ID			= results.GetInt32(0);
						myPicture.Title			= results.GetString(1);
						myPicture.Caption		= results.GetString(2);
						myPicture.FileName		= results.GetString(3);
						myPicture.HighlightPicture = results.GetBoolean(4);
						myPicture.CreateDate	= results.GetDateTime(5);
						myPicture.ViewCount		= results.GetInt32(6);

						myPicture.Comments = this.GetPictureComments(albumID, myPicture.ID);
	
						pictures.Add(myPicture);
					}
				}
				finally
				{
					if (!results.IsClosed)
					{
						results.Close();
					}
				}

			}
			finally
			{
				if (conn.State == ConnectionState.Open)
				{
					conn.Close();
				}
				conn.Dispose();
				comm.Dispose();
			}

			return pictures;
		}

		/// <summary>
		/// This method connects to the database, and returns all the albums in it.
		/// </summary>
		/// <returns>AlbumCollection</returns>
		public override AlbumCollection GetAlbums()
		{
			SqlConnection conn	= new SqlConnection(nGallery.Lib.Configuration.Instance().ConnectionString);
			SqlCommand comm		= new SqlCommand();
			AlbumCollection albums = new AlbumCollection();

			comm.Connection		= conn;
			comm.CommandText	= "ngGetAlbums";
			comm.CommandType	= CommandType.StoredProcedure;

			try
			{
				conn.Open();
				SqlDataReader results = comm.ExecuteReader();

				try
				{
					while (results.Read())
					{
						Album myAlbum = new Album();

						myAlbum.ID			= results.GetInt32(0);
						myAlbum.Name		= results.GetString(1);
						myAlbum.Description	= results.GetString(2);
						myAlbum.CreateDate	= results.GetDateTime(3);
						myAlbum.ParentAlbumID = results.GetInt32(4);

						myAlbum.Pictures = this.GetAlbumPictures(myAlbum.ID);
	
						albums.Add(myAlbum);
					}
				}
				finally
				{
					if (!results.IsClosed)
					{
						results.Close();
					}
				}

			}
			finally
			{
				if (conn.State == ConnectionState.Open)
				{
					conn.Close();
				}
				conn.Dispose();
				comm.Dispose();
			}

			return albums;
		}

		/// <summary>
		/// Gets the ID of the next unique album.
		/// </summary>
		/// <returns>int</returns>
		public override int GetNextAlbumID()
		{
			SqlConnection conn	= new SqlConnection(nGallery.Lib.Configuration.Instance().ConnectionString);
			SqlCommand comm		= new SqlCommand();
			int nextID;

			// setup the connection
			comm.Connection		= conn;
			comm.CommandText	= "ngGetNextAlbumID";
			comm.CommandType	= CommandType.StoredProcedure;

			// execute the statement
			try
			{
				conn.Open();
				SqlDataReader results = comm.ExecuteReader();
				results.Read();

				try
				{
					// put together the return variable
					nextID = results.GetInt32(0);
				}
				finally
				{
					if (!results.IsClosed)
					{
						results.Close();
					}
				}
			}
			finally
			{
				// clean up
				if (conn.State == ConnectionState.Open)
				{
					conn.Close();
				}
				conn.Dispose();
				comm.Dispose();
			}
			return nextID;
		}

		/// <summary>
		/// Gets the ID of the next unique picture.
		/// </summary>
		/// <param name="albumID">Album ID for the album the picture is in (not used in SQL Server implementation)</param>
		/// <returns>int</returns>
		public override int GetNextPictureID(int albumID)
		{
			SqlConnection conn	= new SqlConnection(nGallery.Lib.Configuration.Instance().ConnectionString);
			SqlCommand comm		= new SqlCommand();
			int nextID;

			// setup the connection
			comm.Connection		= conn;
			comm.CommandText	= "ngGetNextPictureID";
			comm.CommandType	= CommandType.StoredProcedure;

			// execute the statement
			try
			{
				conn.Open();
				SqlDataReader results = comm.ExecuteReader();
				results.Read();

				try
				{
					// put together the return variable
					nextID = results.GetInt32(0);
				}
				finally
				{
					if (!results.IsClosed)
					{
						results.Close();
					}
				}
			}
			finally
			{
				// clean up
				if (conn.State == ConnectionState.Open)
				{
					conn.Close();
				}
				conn.Dispose();
				comm.Dispose();
			}
			return nextID;
		}

		/// <summary>
		/// This method connects to the database, and attempts to retrieve the Picture
		/// object for the given album ID and picture ID.
		/// </summary>
		/// <param name="albumID">The ID of the album you wish to look in</param>
		/// <param name="pictureID">The ID of the picture you wish to retrieve</param>
		/// <returns>Picture</returns>
		public override Picture GetPicture(int albumID, int pictureID)
		{
			SqlConnection conn	= new SqlConnection(nGallery.Lib.Configuration.Instance().ConnectionString);
			SqlCommand comm		= new SqlCommand();
			Picture myPicture	= new Picture();

			// setup the connection
			comm.Connection		= conn;
			comm.CommandText	= "ngGetPicture";
			comm.CommandType	= CommandType.StoredProcedure;

			// pass the parameter
			comm.Parameters.Add("@PictureID", pictureID);

			// execute the statement
			try
			{
				conn.Open();
				SqlDataReader results = comm.ExecuteReader();
				results.Read();

				try
				{
					// put together the return variable
					myPicture.ID			= results.GetInt32(0);
					myPicture.Title			= results.GetString(1);
					myPicture.Caption		= results.GetString(2);
					myPicture.FileName		= results.GetString(3);
					myPicture.HighlightPicture = results.GetBoolean(4);
					myPicture.CreateDate	= results.GetDateTime(5);
					myPicture.ViewCount		= results.GetInt32(6);

					myPicture.Comments = this.GetPictureComments(albumID, pictureID);
				}
				finally
				{
					if (!results.IsClosed)
					{
						results.Close();
					}
				}
			}
			finally
			{
				// clean up
				if (conn.State == ConnectionState.Open)
				{
					conn.Close();
				}
				conn.Dispose();
				comm.Dispose();
			}
			return myPicture;
		}

		/// <summary>
		/// This method connects to the database, and attempts to update the Album
		/// in the AlbumCollection based on Album.ID.
		/// </summary>
		/// <param name="album">The Album instance you wish to update</param>
		public override void UpdateAlbum(Album album)
		{
			SqlConnection conn	= new SqlConnection(nGallery.Lib.Configuration.Instance().ConnectionString);
			SqlCommand comm		= new SqlCommand();

			// setup the connection
			comm.Connection		= conn;
			comm.CommandText	= "ngUpdateAlbum";
			comm.CommandType	= CommandType.StoredProcedure;

			// pass the parameters
			comm.Parameters.Add("@AlbumID", album.ID);
			comm.Parameters.Add("@AlbumName", album.Name);
			comm.Parameters.Add("@AlbumDesc", album.Description);
			comm.Parameters.Add("@ParentAlbumID", album.ParentAlbumID);

			// execute the statement
			conn.Open();
			comm.ExecuteNonQuery();

			// clean up
			if (conn.State == ConnectionState.Open)
			{
				conn.Close();
			}
			conn.Dispose();
			comm.Dispose();
		}

		/// <summary>
		/// This method sets the given picture as the highlighted Picture for the given
		/// album ID.
		/// </summary>
		/// <param name="albumID">The ID of the album you wish to set a highlighted picture for</param>
		/// <param name="pictureID">The ID of the picture you wish to set as the highlighted picture</param>
		public override void SetHighlightedPicture(int albumID, int pictureID)
		{
			SqlConnection conn	= new SqlConnection(nGallery.Lib.Configuration.Instance().ConnectionString);
			SqlCommand comm		= new SqlCommand();

			// setup the connection
			comm.Connection		= conn;
			comm.CommandText	= "ngSetHighlightedPicture";
			comm.CommandType	= CommandType.StoredProcedure;

			// pass the parameters
			comm.Parameters.Add("@AlbumID", albumID);
			comm.Parameters.Add("@PictureID", pictureID);

			// execute the statement
			conn.Open();
			comm.ExecuteNonQuery();

			// clean up
			if (conn.State == ConnectionState.Open)
			{
				conn.Close();
			}
			conn.Dispose();
			comm.Dispose();
		}

		/// <summary>
		/// This method connects to the database, and attempts to update the Picture object based
		/// on the given album ID and picture.ID.
		/// </summary>
		/// <param name="albumID">The ID of the album to look in for the update</param>
		/// <param name="picture">The Picture object to update in the album</param>
		public override void UpdatePicture(int albumID, Picture picture)
		{
			SqlConnection conn	= new SqlConnection(nGallery.Lib.Configuration.Instance().ConnectionString);
			SqlCommand comm		= new SqlCommand();

			// setup the connection
			comm.Connection		= conn;
			comm.CommandText	= "ngUpdatePicture";
			comm.CommandType	= CommandType.StoredProcedure;

			// pass the parameters
			comm.Parameters.Add("@PictureID", picture.ID);
			comm.Parameters.Add("@FileName", picture.FileName);
			comm.Parameters.Add("@Title", picture.Title);
			comm.Parameters.Add("@Caption", picture.Caption);
			comm.Parameters.Add("@Highlight", picture.HighlightPicture);
			comm.Parameters.Add("@AlbumID", albumID);
			comm.Parameters.Add("@Height", picture.Height);
			comm.Parameters.Add("@Width", picture.Width);

			// execute the statement
			conn.Open();
			comm.ExecuteNonQuery();

			// clean up
			if (conn.State == ConnectionState.Open)
			{
				conn.Close();
			}
			conn.Dispose();
			comm.Dispose();
		}

		/// <summary>
		/// Gets the next unique ID for a comment.
		/// </summary>
		/// <param name="albumID">The album ID for the comment (ignored in SQL Server implementation)</param>
		/// <param name="pictureID">The picture ID for the comment (ignored in SQL Server implementation)</param>
		/// <returns>int</returns>
		public override int GetNextCommentID(int albumID, int pictureID)
		{
			SqlConnection conn	= new SqlConnection(nGallery.Lib.Configuration.Instance().ConnectionString);
			SqlCommand comm		= new SqlCommand();
			int nextID;

			// setup the connection
			comm.Connection		= conn;
			comm.CommandText	= "ngGetNextCommentID";
			comm.CommandType	= CommandType.StoredProcedure;

			// execute the statement
			try
			{
				conn.Open();
				SqlDataReader results = comm.ExecuteReader();
				results.Read();

				try
				{
					// put together the return variable
					nextID = results.GetInt32(0);
				}
				finally
				{
					if (!results.IsClosed)
					{
						results.Close();
					}
				}
			}
			finally
			{
				// clean up
				if (conn.State == ConnectionState.Open)
				{
					conn.Close();
				}
				conn.Dispose();
				comm.Dispose();
			}
			return nextID;
		}

		/// <summary>
		/// This method returns the CommentCollection containing all Comment objects for
		/// a given album ID and picture ID.
		/// </summary>
		/// <param name="albumID">The ID of the respective album.</param>
		/// <param name="pictureID">The ID of the respective picture.</param>
		/// <returns>CommentCollection</returns>
		public override CommentCollection GetPictureComments(int albumID, int pictureID)
		{
			SqlConnection conn			= new SqlConnection(nGallery.Lib.Configuration.Instance().ConnectionString);
			SqlCommand comm				= new SqlCommand();
			CommentCollection comments	= new CommentCollection();

			comm.Connection		= conn;
			comm.CommandText	= "ngGetPictureComments";
			comm.CommandType	= CommandType.StoredProcedure;

			comm.Parameters.Add("@AlbumID", albumID);
			comm.Parameters.Add("@PictureID", pictureID);

			try
			{
				conn.Open();
				SqlDataReader results = comm.ExecuteReader();

				try
				{
					while (results.Read())
					{
						Comment myComment = new Comment();

						myComment.ID			= results.GetInt32(0);
						myComment.FromName		= results.GetString(1);
						myComment.FromEmailAddr	= results.GetString(2);
						myComment.FromWebURL	= results.GetString(3);
						myComment.CommentText	= results.GetString(4);
						myComment.CreateDate	= results.GetDateTime(5);
	
						comments.Add(myComment);
					}
				}
				finally
				{
					if (!results.IsClosed)
					{
						results.Close();
					}
				}

			}
			finally
			{
				if (conn.State == ConnectionState.Open)
				{
					conn.Close();
				}
				conn.Dispose();
				comm.Dispose();
			}

			return comments;
		}

		/// <summary>
		/// This method returns the specific Comment object for the given Album, Picture and Comment ID.
		/// </summary>
		/// <param name="albumID">The ID of the respective album.</param>
		/// <param name="pictureID">The ID of the respective picture.</param>
		/// <param name="commentID">The ID of the respective comment.</param>
		/// <returns>Comment</returns>
		public override Comment GetComment(int albumID, int pictureID, int commentID)
		{
			SqlConnection conn	= new SqlConnection(nGallery.Lib.Configuration.Instance().ConnectionString);
			SqlCommand comm		= new SqlCommand();
			Comment myComment	= new Comment();

			// setup the connection
			comm.Connection		= conn;
			comm.CommandText	= "ngGetComment";
			comm.CommandType	= CommandType.StoredProcedure;

			// pass the parameter
			comm.Parameters.Add("@AlbumID", albumID);
			comm.Parameters.Add("@PictureID", pictureID);
			comm.Parameters.Add("@CommentID", commentID);

			// execute the statement
			try
			{
				conn.Open();
				SqlDataReader results = comm.ExecuteReader();
				results.Read();

				try
				{
					// put together the return variable
					myComment.ID			= results.GetInt32(0);
					myComment.FromName		= results.GetString(1);
					myComment.FromEmailAddr	= results.GetString(2);
					myComment.FromWebURL	= results.GetString(3);
					myComment.CommentText	= results.GetString(4);
					myComment.CreateDate	= results.GetDateTime(5);
				}
				finally
				{
					if (!results.IsClosed)
					{
						results.Close();
					}
				}
			}
			finally
			{
				// clean up
				if (conn.State == ConnectionState.Open)
				{
					conn.Close();
				}
				conn.Dispose();
				comm.Dispose();
			}
			return myComment;
		}

		/// <summary>
		/// This method attempts to create a comment for a given album ID, picture ID and the respective
		/// Comment object.
		/// </summary>
		/// <param name="albumID">The ID of the album in which to create the Comment</param>
		/// <param name="pictureID">The ID of the picture in which to create a Comment</param>
		/// <param name="comment">The Comment object to create</param>
		public override void CreateComment(int albumID, int pictureID, Comment comment)
		{
			SqlConnection conn	= new SqlConnection(nGallery.Lib.Configuration.Instance().ConnectionString);
			SqlCommand comm		= new SqlCommand();

			// setup the connection
			comm.Connection		= conn;
			comm.CommandText	= "ngCreateComment";
			comm.CommandType	= CommandType.StoredProcedure;

			// pass the parameters
			comm.Parameters.Add("@AlbumID", albumID);
			comm.Parameters.Add("@PictureID", pictureID);
			comm.Parameters.Add("@FromName", comment.FromName);
			comm.Parameters.Add("@FromEmailAddr", comment.FromEmailAddr);
			comm.Parameters.Add("@FromWebURL", comment.FromWebURL);
			comm.Parameters.Add("@Text", comment.CommentText);

			// execute the statement
			conn.Open();
			comm.ExecuteNonQuery();

			// clean up
			if (conn.State == ConnectionState.Open)
			{
				conn.Close();
			}
			conn.Dispose();
			comm.Dispose();
		}

		/// <summary>
		/// This method deletes a comment for the given album ID, picture ID and comment ID.
		/// </summary>
		/// <param name="albumID">The ID of the respective album.</param>
		/// <param name="pictureID">The ID of the respective picture.</param>
		/// <param name="commentID">The ID of the respective comment.</param>
		public override void DeleteComment(int albumID, int pictureID, int commentID)
		{
			SqlConnection conn	= new SqlConnection(nGallery.Lib.Configuration.Instance().ConnectionString);
			SqlCommand comm		= new SqlCommand();

			// setup the connection
			comm.Connection		= conn;
			comm.CommandText	= "ngDeleteComment";
			comm.CommandType	= CommandType.StoredProcedure;

			// pass the parameters
			comm.Parameters.Add("@AlbumID", albumID);
			comm.Parameters.Add("@PictureID", pictureID);
			comm.Parameters.Add("@CommentID", commentID);

			// execute the statement
			conn.Open();
			comm.ExecuteNonQuery();

			// clean up
			if (conn.State == ConnectionState.Open)
			{
				conn.Close();
			}
			conn.Dispose();
			comm.Dispose();
		}

		/// <summary>
		/// This method attempts to update a Comment for a given album ID, picture ID and Comment.
		/// </summary>
		/// <param name="albumID">The ID of the album in which to update the Comment</param>
		/// <param name="pictureID">The ID of the picture in which to update the Comment</param>
		/// <param name="comment"></param>
		public override void UpdateComment(int albumID, int pictureID, Comment comment)
		{
			SqlConnection conn	= new SqlConnection(nGallery.Lib.Configuration.Instance().ConnectionString);
			SqlCommand comm		= new SqlCommand();

			// setup the connection
			comm.Connection		= conn;
			comm.CommandText	= "ngUpdateComment";
			comm.CommandType	= CommandType.StoredProcedure;

			// pass the parameters
			comm.Parameters.Add("@AlbumID", albumID);
			comm.Parameters.Add("@PictureID", pictureID);
			comm.Parameters.Add("@CommentID", comment.ID);
			comm.Parameters.Add("@FromName", comment.FromName);
			comm.Parameters.Add("@FromEmailAddr", comment.FromEmailAddr);
			comm.Parameters.Add("@FromWebURL", comment.FromWebURL);
			comm.Parameters.Add("@Text", comment.CommentText);

			// execute the statement
			conn.Open();
			comm.ExecuteNonQuery();

			// clean up
			if (conn.State == ConnectionState.Open)
			{
				conn.Close();
			}
			conn.Dispose();
			comm.Dispose();
		}

		/// <summary>
		/// Increments the view count for the specified picture.
		/// </summary>
		/// <param name="albumID">ID of the album containing the picture.</param>
		/// <param name="pictureID">ID of the picture.</param>
		public override void UpdateViewCount(int albumID, int pictureID)
		{
			SqlConnection conn	= new SqlConnection(nGallery.Lib.Configuration.Instance().ConnectionString);
			SqlCommand comm		= new SqlCommand();

			// setup the connection
			comm.Connection		= conn;
			comm.CommandText	= "ngUpdateViewCount";
			comm.CommandType	= CommandType.StoredProcedure;

			// pass the parameters
			comm.Parameters.Add("@AlbumID", albumID);
			comm.Parameters.Add("@PictureID", pictureID);

			// execute the statement
			conn.Open();
			comm.ExecuteNonQuery();

			// clean up
			if (conn.State == ConnectionState.Open)
			{
				conn.Close();
			}
			conn.Dispose();
			comm.Dispose();
		}

		/// <summary>
		/// This method returns the previous picture's ID for the given album ID and picture ID.
		/// </summary>
		/// <param name="albumID">The ID of the album for the current picture.</param>
		/// <param name="pictureID">The ID of the current picture.</param>
		/// <returns>int</returns>
		public override int GetPreviousPictureID(int albumID, int pictureID)
		{
			SqlConnection conn	= new SqlConnection(nGallery.Lib.Configuration.Instance().ConnectionString);
			SqlCommand comm		= new SqlCommand();
			int prevID;

			// setup the connection
			comm.Connection		= conn;
			comm.CommandText	= "ngGetPreviousPictureID";
			comm.CommandType	= CommandType.StoredProcedure;

			// pass the parameters
			comm.Parameters.Add("@AlbumID", albumID);
			comm.Parameters.Add("@PictureID", pictureID);

			// execute the statement
			try
			{
				conn.Open();
				SqlDataReader results = comm.ExecuteReader();
				results.Read();

				try
				{
					// put together the return variable
					prevID = results.GetInt32(0);
				}
				finally
				{
					if (!results.IsClosed)
					{
						results.Close();
					}
				}
			}
			finally
			{
				// clean up
				if (conn.State == ConnectionState.Open)
				{
					conn.Close();
				}
				conn.Dispose();
				comm.Dispose();
			}
			return prevID;
		}


		/// <summary>
		/// This method returns the next picture's ID for the given album ID and picture ID.
		/// </summary>
		/// <param name="albumID">The ID of the album for the current picture.</param>
		/// <param name="pictureID">The ID of the current picture.</param>
		/// <returns>int</returns>
		public override int GetNextActualPictureID(int albumID, int pictureID)
		{
			SqlConnection conn	= new SqlConnection(nGallery.Lib.Configuration.Instance().ConnectionString);
			SqlCommand comm		= new SqlCommand();
			int nextID;

			// setup the connection
			comm.Connection		= conn;
			comm.CommandText	= "ngGetNextActualPictureID";
			comm.CommandType	= CommandType.StoredProcedure;

			// pass the parameters
			comm.Parameters.Add("@AlbumID", albumID);
			comm.Parameters.Add("@PictureID", pictureID);

			// execute the statement
			try
			{
				conn.Open();
				SqlDataReader results = comm.ExecuteReader();
				results.Read();

				try
				{
					// put together the return variable
					nextID = results.GetInt32(0);
				}
				finally
				{
					if (!results.IsClosed)
					{
						results.Close();
					}
				}
			}
			finally
			{
				// clean up
				if (conn.State == ConnectionState.Open)
				{
					conn.Close();
				}
				conn.Dispose();
				comm.Dispose();
			}
			return nextID;
		}

		/// <summary>
		/// This method returns the previous album's ID for the given album ID.
		/// </summary>
		/// <param name="albumID">The ID of the current album.</param>
		/// <returns>int</returns>
		public override int GetPreviousAlbumID(int albumID)
		{
			SqlConnection conn	= new SqlConnection(nGallery.Lib.Configuration.Instance().ConnectionString);
			SqlCommand comm		= new SqlCommand();
			int prevID;

			// setup the connection
			comm.Connection		= conn;
			comm.CommandText	= "ngGetPreviousAlbumID";
			comm.CommandType	= CommandType.StoredProcedure;

			// pass the parameters
			comm.Parameters.Add("@AlbumID", albumID);

			// execute the statement
			try
			{
				conn.Open();
				SqlDataReader results = comm.ExecuteReader();
				results.Read();

				try
				{
					// put together the return variable
					prevID = results.GetInt32(0);
				}
				finally
				{
					if (!results.IsClosed)
					{
						results.Close();
					}
				}
			}
			finally
			{
				// clean up
				if (conn.State == ConnectionState.Open)
				{
					conn.Close();
				}
				conn.Dispose();
				comm.Dispose();
			}
			return prevID;
		}

		/// <summary>
		/// This method returns the next album's ID for the given album ID.
		/// </summary>
		/// <param name="albumID">The ID of the current album.</param>
		/// <returns>int</returns>
		public override int GetNextActualAlbumID(int albumID)
		{
			SqlConnection conn	= new SqlConnection(nGallery.Lib.Configuration.Instance().ConnectionString);
			SqlCommand comm		= new SqlCommand();
			int nextID;

			// setup the connection
			comm.Connection		= conn;
			comm.CommandText	= "ngGetNextActualAlbumID";
			comm.CommandType	= CommandType.StoredProcedure;

			// pass the parameters
			comm.Parameters.Add("@AlbumID", albumID);

			// execute the statement
			try
			{
				conn.Open();
				SqlDataReader results = comm.ExecuteReader();
				results.Read();

				try
				{
					// put together the return variable
					nextID = results.GetInt32(0);
				}
				finally
				{
					if (!results.IsClosed)
					{
						results.Close();
					}
				}
			}
			finally
			{
				// clean up
				if (conn.State == ConnectionState.Open)
				{
					conn.Close();
				}
				conn.Dispose();
				comm.Dispose();
			}
			return nextID;
		}

		/// <summary>
		/// Retrieves all of the information of the sub-ablbums of a particular album.
		/// </summary>
		/// <param name="albumID">The albumID for the album you want the sub-albums of</param>
		/// <returns>AlbumCollection</returns>
		public override AlbumCollection GetSubAlbums(int albumID)
		{
			SqlConnection conn	= new SqlConnection(nGallery.Lib.Configuration.Instance().ConnectionString);
			SqlCommand comm		= new SqlCommand();
			AlbumCollection albums = new AlbumCollection();

			comm.Connection		= conn;
			comm.CommandText	= "ngGetSubAlbums";
			comm.CommandType	= CommandType.StoredProcedure;

			comm.Parameters.Add("@ParentAlbumID", albumID);

			try
			{
				conn.Open();
				SqlDataReader results = comm.ExecuteReader();

				try
				{
					while (results.Read())
					{
						Album myAlbum = new Album();

						myAlbum.ID			= results.GetInt32(0);
						myAlbum.Name		= results.GetString(1);
						myAlbum.Description	= results.GetString(2);
						myAlbum.CreateDate	= results.GetDateTime(3);
						myAlbum.ParentAlbumID = results.GetInt32(4);

						myAlbum.Pictures = this.GetAlbumPictures(myAlbum.ID);
	
						albums.Add(myAlbum);
					}
				}
				finally
				{
					if (!results.IsClosed)
					{
						results.Close();
					}
				}

			}
			finally
			{
				if (conn.State == ConnectionState.Open)
				{
					conn.Close();
				}
				conn.Dispose();
				comm.Dispose();
			}

			return albums;
		}


		/// <summary>
		/// Retrieves all of the top level albums.
		/// </summary>
		/// <returns>AlbumCollection</returns>
		public override AlbumCollection GetParentAlbums()
		{
			return this.GetSubAlbums(0);
		}


		/// <summary>
		/// Gets the rating for a given picture.
		/// </summary>
		/// <param name="albumID">The album's ID</param>
		/// <param name="pictureID">The picture's ID</param>
		/// <returns>Rating</returns>
		public override Rating GetPictureRating(int albumID, int pictureID)
		{
			SqlConnection conn	= new SqlConnection(nGallery.Lib.Configuration.Instance().ConnectionString);
			SqlCommand comm		= new SqlCommand();
			Rating myRating		= new Rating();

			// setup the connection
			comm.Connection		= conn;
			comm.CommandText	= "ngGetPictureRating";
			comm.CommandType	= CommandType.StoredProcedure;

			// pass the parameter
			comm.Parameters.Add("@PictureID", pictureID);

			// execute the statement
			try
			{
				conn.Open();
				SqlDataReader results = comm.ExecuteReader();
				results.Read();

				try
				{
					// put together the return variable
					myRating.Rating1		= results.GetInt32(0);
					myRating.Rating2		= results.GetInt32(1);
					myRating.Rating3		= results.GetInt32(2);
					myRating.Rating4		= results.GetInt32(3);
					myRating.Rating5		= results.GetInt32(4);
				}
				finally
				{
					if (!results.IsClosed)
					{
						results.Close();
					}
				}
			}
			finally
			{
				// clean up
				if (conn.State == ConnectionState.Open)
				{
					conn.Close();
				}
				conn.Dispose();
				comm.Dispose();
			}
			return myRating;
		}

		
		/// <summary>
		/// Updates the rating for a picture.
		/// </summary>
		/// <param name="albumID">The ID of the album of the respective current picture.</param>
		/// <param name="pictureID">The ID of the picture.</param>
		/// <param name="PictureRating">The picture rating information.</param>
		public override void UpdatePictureRating(int albumID, int pictureID, Rating PictureRating)
		{
			SqlConnection conn	= new SqlConnection(nGallery.Lib.Configuration.Instance().ConnectionString);
			SqlCommand comm		= new SqlCommand();

			// setup the connection
			comm.Connection		= conn;
			comm.CommandText	= "ngUpdatePictureRating";
			comm.CommandType	= CommandType.StoredProcedure;

			// pass the parameters
			comm.Parameters.Add("@PictureID", pictureID);
			comm.Parameters.Add("@Rating1", PictureRating.Rating1);
			comm.Parameters.Add("@Rating2", PictureRating.Rating2);
			comm.Parameters.Add("@Rating3", PictureRating.Rating3);
			comm.Parameters.Add("@Rating4", PictureRating.Rating4);
			comm.Parameters.Add("@Rating5", PictureRating.Rating5);

			// execute the statement
			conn.Open();
			comm.ExecuteNonQuery();

			// clean up
			if (conn.State == ConnectionState.Open)
			{
				conn.Close();
			}
			conn.Dispose();
			comm.Dispose();
		}


		/// <summary>
		/// This method connects to the database, and returns the AlbumID of an
		/// album based on its name.
		/// </summary>
		/// <param name="albumName">The name of the album.</param>
		/// <returns>int</returns>
		public override int GetAlbumIDByName(string albumName)
		{
			SqlConnection conn	= new SqlConnection(nGallery.Lib.Configuration.Instance().ConnectionString);
			SqlCommand comm		= new SqlCommand();
			int albumID;

			// setup the connection
			comm.Connection		= conn;
			comm.CommandText	= "ngGetAlbumIDByName";
			comm.CommandType	= CommandType.StoredProcedure;

			// pass the album name
			comm.Parameters.Add("@AlbumName", albumName);

			// execute the statement
			try
			{
				conn.Open();
				SqlDataReader results = comm.ExecuteReader();
				if(results.Read() == false) return 0;			// return 0 if nothing returned, meaning no records found

				try
				{
					// put together the return variable
					albumID = results.GetInt32(0);
				}
				finally
				{
					if (!results.IsClosed)
					{
						results.Close();
					}
				}
			}
			finally
			{
				// clean up
				if (conn.State == ConnectionState.Open)
				{
					conn.Close();
				}
				conn.Dispose();
				comm.Dispose();
			}
			return albumID;
		}

		// Address Book Methods

		/// <summary>
		/// Returns the next contiguous contact ID available.
		/// </summary>
		/// <returns>int</returns>
		public override int GetNextContactID()
		{
			SqlConnection conn	= new SqlConnection(nGallery.Lib.Configuration.Instance().ConnectionString);
			SqlCommand comm		= new SqlCommand();
			int nextID;

			// setup the connection
			comm.Connection		= conn;
			comm.CommandText	= "ngGetNextContactID";
			comm.CommandType	= CommandType.StoredProcedure;

			// execute the statement
			try
			{
				conn.Open();
				SqlDataReader results = comm.ExecuteReader();
				results.Read();

				try
				{
					// put together the return variable
					nextID = results.GetInt32(0);
				}
				finally
				{
					if (!results.IsClosed)
					{
						results.Close();
					}
				}
			}
			finally
			{
				// clean up
				if (conn.State == ConnectionState.Open)
				{
					conn.Close();
				}
				conn.Dispose();
				comm.Dispose();
			}
			return nextID;
		}


		/// <summary>
		/// Returns all the contacts in the system.
		/// </summary>
		/// <returns>ContactCollection</returns>
		public override ContactCollection GetContacts()
		{
			SqlConnection conn	= new SqlConnection(nGallery.Lib.Configuration.Instance().ConnectionString);
			SqlCommand comm		= new SqlCommand();
			ContactCollection contacts = new ContactCollection();

			comm.Connection		= conn;
			comm.CommandText	= "ngGetContacts";
			comm.CommandType	= CommandType.StoredProcedure;

			try
			{
				conn.Open();
				SqlDataReader results = comm.ExecuteReader();

				try
				{
					while (results.Read())
					{
						Contact myContact = new Contact();

						myContact.ID			= results.GetInt32(0);
						myContact.FirstName		= results.GetString(1);
						myContact.MiddleName	= results.GetString(2);
						myContact.LastName		= results.GetString(3);
						myContact.NickName		= results.GetString(4);
						myContact.EmailAddress	= results.GetString(5);
						myContact.HomePhone		= results.GetString(6);
						myContact.WorkPhone		= results.GetString(7);
						myContact.MobilePhone	= results.GetString(8);
						myContact.Address1		= results.GetString(9);
						myContact.Address2		= results.GetString(10);
						myContact.City			= results.GetString(11);
						myContact.State			= results.GetString(12);
						myContact.Zip			= results.GetString(13);
						myContact.WebsiteUrl	= results.GetString(14);

						contacts.Add(myContact);
					}
				}
				finally
				{
					if (!results.IsClosed)
					{
						results.Close();
					}
				}

			}
			finally
			{
				if (conn.State == ConnectionState.Open)
				{
					conn.Close();
				}
				conn.Dispose();
				comm.Dispose();
			}

			return contacts;
		}


		/// <summary>
		/// Creates a contact record for the given Contact object passed.
		/// </summary>
		/// <param name="contact">The Contact object to create.</param>
		public override void CreateContact(Contact contact)
		{
			SqlConnection conn	= new SqlConnection(nGallery.Lib.Configuration.Instance().ConnectionString);
			SqlCommand comm		= new SqlCommand();

			// setup the connection
			comm.Connection		= conn;
			comm.CommandText	= "ngCreateContact";
			comm.CommandType	= CommandType.StoredProcedure;

			// pass the parameters
			comm.Parameters.Add("@FirstName", contact.FirstName);
			comm.Parameters.Add("@MiddleName", contact.MiddleName);
			comm.Parameters.Add("@LastName", contact.LastName);
			comm.Parameters.Add("@NickName", contact.NickName);
			comm.Parameters.Add("@EmailAddress", contact.EmailAddress);
			comm.Parameters.Add("@HomePhone", contact.HomePhone);
			comm.Parameters.Add("@WorkPhone", contact.WebsiteUrl);
			comm.Parameters.Add("@MobilePhone", contact.MobilePhone);
			comm.Parameters.Add("@Address1", contact.Address1);
			comm.Parameters.Add("@Address2", contact.Address2);
			comm.Parameters.Add("@City", contact.City);
			comm.Parameters.Add("@State", contact.State);
			comm.Parameters.Add("@Zip", contact.Zip);
			comm.Parameters.Add("@WebsiteURL", contact.WebsiteUrl);

			// execute the statement
			conn.Open();
			comm.ExecuteNonQuery();

			// clean up
			if (conn.State == ConnectionState.Open)
			{
				conn.Close();
			}
			conn.Dispose();
			comm.Dispose();
		}


		/// <summary>
		/// Returns the Contact object for the given contact ID.
		/// </summary>
		/// <param name="contactID">The ID of the contact that you wish to retrieve.</param>
		/// <returns>Contact</returns>
		public override Contact GetContact(int contactID)
		{
			SqlConnection conn	= new SqlConnection(nGallery.Lib.Configuration.Instance().ConnectionString);
			SqlCommand comm		= new SqlCommand();
			Contact myContact	= new Contact();

			// setup the connection
			comm.Connection		= conn;
			comm.CommandText	= "ngGetContact";
			comm.CommandType	= CommandType.StoredProcedure;

			// pass the parameter
			comm.Parameters.Add("@ContactID", contactID);

			// execute the statement
			try
			{
				conn.Open();
				SqlDataReader results = comm.ExecuteReader();
				results.Read();

				try
				{
					// put together the return variable
					myContact.ID			= results.GetInt32(0);
					myContact.FirstName		= results.GetString(1);
					myContact.MiddleName	= results.GetString(2);
					myContact.LastName		= results.GetString(3);
					myContact.NickName		= results.GetString(4);
					myContact.EmailAddress	= results.GetString(5);
					myContact.HomePhone		= results.GetString(6);
					myContact.WorkPhone		= results.GetString(7);
					myContact.MobilePhone	= results.GetString(8);
					myContact.Address1		= results.GetString(9);
					myContact.Address2		= results.GetString(10);
					myContact.City			= results.GetString(11);
					myContact.State			= results.GetString(12);
					myContact.Zip			= results.GetString(13);
					myContact.WebsiteUrl	= results.GetString(14);
				}
				finally
				{
					if (!results.IsClosed)
					{
						results.Close();
					}
				}
			}
			finally
			{
				// clean up
				if (conn.State == ConnectionState.Open)
				{
					conn.Close();
				}
				conn.Dispose();
				comm.Dispose();
			}
			return myContact;
		}


		/// <summary>
		/// Updates the contact information for the given Contact object, keying off the contact ID.
		/// </summary>
		/// <param name="contact">The Contact object, with the new values, that you wish to update.</param>
		public override void UpdateContact(Contact contact)
		{
			SqlConnection conn	= new SqlConnection(nGallery.Lib.Configuration.Instance().ConnectionString);
			SqlCommand comm		= new SqlCommand();

			// setup the connection
			comm.Connection		= conn;
			comm.CommandText	= "ngUpdateContact";
			comm.CommandType	= CommandType.StoredProcedure;

			// pass the parameters
			comm.Parameters.Add("@ContactID", contact.ID);
			comm.Parameters.Add("@FirstName", contact.FirstName);
			comm.Parameters.Add("@MiddleName", contact.MiddleName);
			comm.Parameters.Add("@LastName", contact.LastName);
			comm.Parameters.Add("@NickName", contact.NickName);
			comm.Parameters.Add("@EmailAddress", contact.EmailAddress);
			comm.Parameters.Add("@HomePhone", contact.HomePhone);
			comm.Parameters.Add("@WorkPhone", contact.WebsiteUrl);
			comm.Parameters.Add("@MobilePhone", contact.MobilePhone);
			comm.Parameters.Add("@Address1", contact.Address1);
			comm.Parameters.Add("@Address2", contact.Address2);
			comm.Parameters.Add("@City", contact.City);
			comm.Parameters.Add("@State", contact.State);
			comm.Parameters.Add("@Zip", contact.Zip);
			comm.Parameters.Add("@WebsiteURL", contact.WebsiteUrl);

			// execute the statement
			conn.Open();
			comm.ExecuteNonQuery();

			// clean up
			if (conn.State == ConnectionState.Open)
			{
				conn.Close();
			}
			conn.Dispose();
			comm.Dispose();
		}


		/// <summary>
		/// Deletes a contact record for the given contact ID.
		/// </summary>
		/// <param name="contactID">The ID of the contact that you wish to delete.</param>
		public override void DeleteContact(int contactID)
		{
			SqlConnection conn	= new SqlConnection(nGallery.Lib.Configuration.Instance().ConnectionString);
			SqlCommand comm		= new SqlCommand();

			// setup the connection
			comm.Connection		= conn;
			comm.CommandText	= "ngDeleteContact";
			comm.CommandType	= CommandType.StoredProcedure;

			// pass the parameters
			comm.Parameters.Add("@ContactID", contactID);

			// execute the statement
			conn.Open();
			comm.ExecuteNonQuery();

			// clean up
			if (conn.State == ConnectionState.Open)
			{
				conn.Close();
			}
			conn.Dispose();
			comm.Dispose();
		}

		// Invitation Methods

		/// <summary>
		/// Returns all invitations within the system.
		/// </summary>
		/// <returns>InvitationCollection</returns>
		public override InvitationCollection GetInvitations()
		{
			SqlConnection conn	= new SqlConnection(nGallery.Lib.Configuration.Instance().ConnectionString);
			SqlCommand comm		= new SqlCommand();
			InvitationCollection invitations = new InvitationCollection();

			comm.Connection		= conn;
			comm.CommandText	= "ngGetInvitations";
			comm.CommandType	= CommandType.StoredProcedure;

			try
			{
				conn.Open();
				SqlDataReader results = comm.ExecuteReader();

				try
				{
					while (results.Read())
					{
						Invitation myInvite = new Invitation();

						myInvite.ID			= results.GetInt32(0);
						myInvite.AlbumID	= results.GetInt32(1);
						myInvite.Message	= results.GetString(2);
						myInvite.CreateDate	= results.GetDateTime(3);

						this.GetInvitationRecipients(myInvite.ID);

						invitations.Add(myInvite);
					}
				}
				finally
				{
					if (!results.IsClosed)
					{
						results.Close();
					}
				}

			}
			finally
			{
				if (conn.State == ConnectionState.Open)
				{
					conn.Close();
				}
				conn.Dispose();
				comm.Dispose();
			}

			return invitations;
		}


		/// <summary>
		/// Returns the next available, contiguous invitation ID.
		/// </summary>
		/// <returns>int</returns>
		public override int GetNextInvitationID()
		{
			SqlConnection conn	= new SqlConnection(nGallery.Lib.Configuration.Instance().ConnectionString);
			SqlCommand comm		= new SqlCommand();
			int nextID;

			// setup the connection
			comm.Connection		= conn;
			comm.CommandText	= "ngGetNextInvitationID";
			comm.CommandType	= CommandType.StoredProcedure;

			// execute the statement
			try
			{
				conn.Open();
				SqlDataReader results = comm.ExecuteReader();
				results.Read();

				try
				{
					// put together the return variable
					nextID = results.GetInt32(0);
				}
				finally
				{
					if (!results.IsClosed)
					{
						results.Close();
					}
				}
			}
			finally
			{
				// clean up
				if (conn.State == ConnectionState.Open)
				{
					conn.Close();
				}
				conn.Dispose();
				comm.Dispose();
			}
			return nextID;
		}


		/// <summary>
		/// Creates an invitation for the given Invitation object.
		/// </summary>
		/// <param name="invite">The Invitation object that you wish to create.</param>
		public override void CreateInvitation(Invitation invite)
		{
			SqlConnection conn	= new SqlConnection(nGallery.Lib.Configuration.Instance().ConnectionString);
			SqlCommand comm		= new SqlCommand();

			// setup the connection
			comm.Connection		= conn;
			comm.CommandText	= "ngCreateInvitation";
			comm.CommandType	= CommandType.StoredProcedure;

			// pass the parameters
			comm.Parameters.Add("@AlbumID", invite.AlbumID);
			comm.Parameters.Add("@Message", invite.Message);
			comm.Parameters.Add("@CreateDate", invite.CreateDate);

			// execute the statement
			conn.Open();
			if(comm.ExecuteNonQuery() > 0)
			{
				// insert all of the recipients
				for(int i = 0; i < invite.Recipients.Count; i++)
				{
					System.Collections.ArrayList recipientValues = (System.Collections.ArrayList) invite.Recipients[i];
                    
					this.CreateInvitationContact(invite.ID, Convert.ToInt32(recipientValues[0]), recipientValues[1].ToString());
				}
			}

			// clean up
			if (conn.State == ConnectionState.Open)
			{
				conn.Close();
			}
			conn.Dispose();
			comm.Dispose();
		}


		/// <summary>
		/// Deletes an invitation for the given invitation ID.
		/// </summary>
		/// <param name="inviteID">The ID of the invitation that you wish to delete.</param>
		public override void DeleteInvitation(int inviteID)
		{
			SqlConnection conn	= new SqlConnection(nGallery.Lib.Configuration.Instance().ConnectionString);
			SqlCommand comm		= new SqlCommand();

			// setup the connection
			comm.Connection		= conn;
			comm.CommandText	= "ngDeleteInvitation";
			comm.CommandType	= CommandType.StoredProcedure;

			// pass the parameters
			comm.Parameters.Add("@InvitationID", inviteID);

			// execute the statement
			conn.Open();
			comm.ExecuteNonQuery();

			// clean up
			if (conn.State == ConnectionState.Open)
			{
				conn.Close();
			}
			conn.Dispose();
			comm.Dispose();
		}


		/// <summary>
		/// Sets the invitation read values for a given invitation's GUID.
		/// </summary>
		/// <param name="inviteGuid">The GUID of the invitation that you wish to mark as read.</param>
		public override void MarkInvitationRead(string inviteGuid)
		{
			SqlConnection conn	= new SqlConnection(nGallery.Lib.Configuration.Instance().ConnectionString);
			SqlCommand comm		= new SqlCommand();

			// setup the connection
			comm.Connection		= conn;
			comm.CommandText	= "ngMarkInvitationRead";
			comm.CommandType	= CommandType.StoredProcedure;

			// pass the parameters
			comm.Parameters.Add("@GUID", inviteGuid);

			// execute the statement
			conn.Open();
			comm.ExecuteNonQuery();

			// clean up
			if (conn.State == ConnectionState.Open)
			{
				conn.Close();
			}
			conn.Dispose();
			comm.Dispose();
		}


		/// <summary>
		/// Returns the Contact object for the given GUID.
		/// </summary>
		/// <param name="invitationGuid">The GUID of the Contact that you wish to look-up.</param>
		/// <returns>Contact</returns>
		public override Contact GetContactByGuid(string invitationGuid)
		{
			SqlConnection conn	= new SqlConnection(nGallery.Lib.Configuration.Instance().ConnectionString);
			SqlCommand comm		= new SqlCommand();
			Contact myContact	= new Contact();

			// setup the connection
			comm.Connection		= conn;
			comm.CommandText	= "ngGetContactByGuid";
			comm.CommandType	= CommandType.StoredProcedure;

			// pass the parameter
			comm.Parameters.Add("@GUID", invitationGuid);

			// execute the statement
			try
			{
				conn.Open();
				SqlDataReader results = comm.ExecuteReader();
				results.Read();

				try
				{
					// put together the return variable
					myContact.ID			= results.GetInt32(0);
					myContact.FirstName		= results.GetString(1);
					myContact.MiddleName	= results.GetString(2);
					myContact.LastName		= results.GetString(3);
					myContact.NickName		= results.GetString(4);
					myContact.EmailAddress	= results.GetString(5);
					myContact.HomePhone		= results.GetString(6);
					myContact.WorkPhone		= results.GetString(7);
					myContact.MobilePhone	= results.GetString(8);
					myContact.Address1		= results.GetString(9);
					myContact.Address2		= results.GetString(10);
					myContact.City			= results.GetString(11);
					myContact.State			= results.GetString(12);
					myContact.Zip			= results.GetString(13);
					myContact.WebsiteUrl	= results.GetString(14);
				}
				finally
				{
					if (!results.IsClosed)
					{
						results.Close();
					}
				}
			}
			finally
			{
				// clean up
				if (conn.State == ConnectionState.Open)
				{
					conn.Close();
				}
				conn.Dispose();
				comm.Dispose();
			}
			return myContact;
		}


		/// <summary>
		/// Returns the Invitation object for the given GUID.
		/// </summary>
		/// <param name="invitationGuid">The GUID that you wish to use to look-up the invitation.</param>
		/// <returns>Invitation</returns>
		public override Invitation GetInvitationByGuid(string invitationGuid)
		{
			SqlConnection conn	= new SqlConnection(nGallery.Lib.Configuration.Instance().ConnectionString);
			SqlCommand comm		= new SqlCommand();
			Invitation myInvite	= new Invitation();

			// setup the connection
			comm.Connection		= conn;
			comm.CommandText	= "ngGetInvitationByGuid";
			comm.CommandType	= CommandType.StoredProcedure;

			// pass the parameter
			comm.Parameters.Add("@GUID", invitationGuid);

			// execute the statement
			try
			{
				conn.Open();
				SqlDataReader results = comm.ExecuteReader();
				results.Read();

				try
				{
					// put together the return variable
					myInvite.ID			= results.GetInt32(0);
					myInvite.AlbumID	= results.GetInt32(1);
					myInvite.Message	= results.GetString(2);
					myInvite.CreateDate	= results.GetDateTime(3);
				}
				finally
				{
					if (!results.IsClosed)
					{
						results.Close();
					}
				}
			}
			finally
			{
				// clean up
				if (conn.State == ConnectionState.Open)
				{
					conn.Close();
				}
				conn.Dispose();
				comm.Dispose();
			}
			return myInvite;
		}


		/// <summary>
		/// Returns all recipients of a given invitation ID.
		/// </summary>
		/// <param name="inviteID">The ID of the invitation that you want the recipients for.</param>
		/// <returns>ArrayList</returns>
		public override System.Collections.ArrayList GetInvitationRecipients(int inviteID)
		{
			SqlConnection conn	= new SqlConnection(nGallery.Lib.Configuration.Instance().ConnectionString);
			SqlCommand comm		= new SqlCommand();
			System.Collections.ArrayList recipients = new System.Collections.ArrayList();

			// setup the connection
			comm.Connection		= conn;
			comm.CommandText	= "ngGetInvitationRecipients";
			comm.CommandType	= CommandType.StoredProcedure;

			// pass the parameter
			comm.Parameters.Add("@InvitationID", inviteID);

			// execute the statement
			try
			{
				conn.Open();
				SqlDataReader results = comm.ExecuteReader();

				try
				{
					while (results.Read())
					{
						System.Collections.ArrayList recipientValues = new System.Collections.ArrayList();
			
						recipientValues.Add(results.GetInt32(0).ToString());
						recipientValues.Add(results.GetString(1));
						recipientValues.Add(results.GetBoolean(2).ToString().ToLower());

						recipients.Add(recipientValues);
					}
				}
				finally
				{
					if (!results.IsClosed)
					{
						results.Close();
					}
				}

			}
			finally
			{
				if (conn.State == ConnectionState.Open)
				{
					conn.Close();
				}
				conn.Dispose();
				comm.Dispose();
			}

			return recipients;
		}


		/// <summary>
		/// Returns the total number of pictures, including sub-albums, in the given album.
		/// </summary>
		/// <param name="albumID">The ID of the album in which you want the total count.</param>
		/// <returns>int</returns>
		public override int GetTotalPictureCount(int albumID)
		{
			SqlConnection conn	= new SqlConnection(nGallery.Lib.Configuration.Instance().ConnectionString);
			SqlCommand comm		= new SqlCommand();
			Invitation myInvite	= new Invitation();
			int total			= 0;

			// setup the connection
			comm.Connection		= conn;
			comm.CommandText	= "ngGetTotalPictureCount";
			comm.CommandType	= CommandType.StoredProcedure;

			// pass the parameter
			comm.Parameters.Add("@AlbumID", albumID);

			// execute the statement
			try
			{
				conn.Open();
				SqlDataReader results = comm.ExecuteReader();
				results.Read();

				try
				{
					// put together the return variable
					total = results.GetInt32(0);
				}
				finally
				{
					if (!results.IsClosed)
					{
						results.Close();
					}
				}
			}
			finally
			{
				// clean up
				if (conn.State == ConnectionState.Open)
				{
					conn.Close();
				}
				conn.Dispose();
				comm.Dispose();
			}
			return total;
		}


		#endregion

	}
}
