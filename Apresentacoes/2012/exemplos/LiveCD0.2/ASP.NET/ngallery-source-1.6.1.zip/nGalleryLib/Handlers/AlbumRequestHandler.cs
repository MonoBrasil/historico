#region Copyright and License
/*
Copyright 2003 Jason Alexander, nGallery.org
Design work copyright Thomas Johansen (http://www.aylarsolutions.com/)

GOTDOTNET WORKSPACES COMMERCIAL DERIVATIVES LICENSE
Copyright (C) 2003 Microsoft Corporation

You can use this Software for any commercial or noncommercial purpose, 
including distributing derivative works.

In return, we simply require that you agree:

1. Not to remove any copyright notices from the Software. 
2. That if you distribute the Software in source code form you do so only 
   under this License (i.e. you must include a complete copy of this License 
   with your distribution), and if you distribute the Software solely in 
   object form you only do so under a license that complies with this License. 
3. That the Software comes "as is", with no warranties. None whatsoever. This 
   means no express, implied or statutory warranty, including without 
   limitation, warranties of merchantability or fitness for a particular 
   purpose or any warranty of noninfringement. Also, you must pass this 
   disclaimer on whenever you distribute the Software.
4. That neither Microsoft nor any contributor to the Software will be liable 
   for any of those types of damages known as indirect, special, consequential, 
   or incidental related to the Software or this License, to the maximum extent 
   the law permits, no matter what legal theory it�s based on. Also, you must 
   pass this limitation of liability on whenever you distribute the Software.
5. That if you sue anyone over patents that you think may apply to the 
   Software for a person's use of the Software, your license to the Software 
   ends automatically. 
6. That the patent rights, if any, licensed hereunder only apply to the 
   Software, not to any derivative works you make. 
7. That your rights under this License end automatically if you breach it in 
   any way.
*/
#endregion
using System;
using System.Web;
using System.Text;
using System.Collections;

namespace nGallery.Lib
{

	/// <summary>
	/// Summary description for AlbumRequestHandler.
	/// </summary>
	public class AlbumRequestHandler : IHttpHandler
	{
		#region IHttpHandler Members


		/// <summary>
		/// This method processes the incoming request.
		/// </summary>
		/// <param name="context">The HTTP context in which the request was called from.</param>
		public void ProcessRequest(HttpContext context)
		{
			nGallery.Lib.BL galleryBL	= new nGallery.Lib.BL(context.Server.MapPath(nGallery.Lib.Configuration.Instance().DataDirectory));
			StringBuilder targetURL		= new StringBuilder();
			string[] initialURLElements	= context.Request.ServerVariables["SCRIPT_NAME"].Split('/');
			ArrayList urlElements		= new ArrayList();
			RewriteType rewrite			= Configuration.Instance().AlbumRewriting;


			bool startGrabbing = false;
			for (int i = 0; i < initialURLElements.Length; i++)
			{
				if (initialURLElements[i] == "albums") startGrabbing = true;

				if (startGrabbing) urlElements.Add(initialURLElements[i]);
			}
			
			
			string albumName			= context.Server.UrlDecode(urlElements[1].ToString().Replace(".aspx", ""));
			int albumID = 0;
			
			// This is where it gets a little wacky --
			// If the user has URL rewriting on by name, then albumName is really the name of the album. BUT,
			// if the user has rewriting on by ID, then albumName is really the ID of the album.

			// Actually, we'll try to be a little more adaptive. If the user attempts to visit via an ID, let's 
			// try to use that, regardless of the configuration (in case they're visiting an old bookmark or something.
			try
			{
				albumID = int.Parse(albumName);

				rewrite = RewriteType.ById;
			}
			catch
			{
				rewrite = RewriteType.ByName;
			}

			if (rewrite == RewriteType.ByName)
			{
				albumID = galleryBL.GetAlbumIDByName(albumName);
			}
			else if (rewrite == RewriteType.ById)
			{
				albumID = int.Parse(albumName);

				// Now, let's look up the real album name.
				albumName = galleryBL.GetAlbum(albumID).Name;
			}
			string page					= context.Request.QueryString["page"];
			


			targetURL.Append("~/");

			// Assumes something like: http://mysite.com/photos/rss.aspx
			if (albumName == "rss")
			{

				targetURL.Append("rss.aspx");
				context.Server.Transfer(targetURL.ToString());

			}

			if (albumID == 0)
			{
				context.Response.Write("Unable to find album \"" + albumName + "\". Try again.");
				context.Response.End();
			}

			// Assumes something like: http://mysite.com/albums/My%20Test%20Album/2/rss.aspx
			if (urlElements.Count > 3)
			{
				string name = urlElements[3].ToString().Replace(".aspx", "");
				string pictureID = urlElements[2].ToString();

				if (name == "rss")
				{
					targetURL.Append("rss.aspx?" + 
						"albumID=" +
						albumID + "&PictureID=" + 
						pictureID);
				} 

			}
			// Assumes something like: http://mysite.com/albums/My%20Test%20Album/2.aspx
			else if (urlElements.Count > 2)
			{
				string pictureID = urlElements[2].ToString().Replace(".aspx", "");

				if (pictureID == "rss")
				{
					targetURL.Append("rss.aspx?" + 
						"albumID=" +
						albumID);
				} 
				else 
				{

					targetURL.Append("viewPicture.aspx?" + 
						"pictureID=" +
						pictureID + 
						"&albumID=" +
						albumID +
						"&albumName=" +
						context.Server.UrlEncode(albumName));

				}

			}
			else
			{
				// Assumes something like: http://mysite.com/albums/My%20Test%20Album.aspx
				albumName = albumName.Replace(".aspx", "");

				targetURL.Append("albumListing.aspx?" +
					"albumID=" + 
					albumID + 
					"&albumName=" + 
					context.Server.UrlEncode(albumName));
				
				// Was this request from an invitation?
				if (context.Request.QueryString["InviteID"] != null)
				{
					// If so, carry on the value.
					targetURL.Append("&InviteID=" + context.Request.QueryString["InviteID"]);
			}

			if (page != null && page.Length > 0)
				{
					targetURL.AppendFormat("&page={0}", page);
				}

			}

			
			//context.RewritePath(targetURL.ToString(), "", "");		
			context.Server.Transfer(targetURL.ToString());
		}


		/// <summary>
		/// Is this handler reusable?
		/// </summary>
		public bool IsReusable
		{
			get
			{
				return true;
			}
		}

		#endregion
	}
}
