#region Copyright and License
/*
Copyright 2003 Jason Alexander, nGallery.org
Design work copyright Thomas Johansen (http://www.aylarsolutions.com/)

GOTDOTNET WORKSPACES COMMERCIAL DERIVATIVES LICENSE
Copyright (C) 2003 Microsoft Corporation

You can use this Software for any commercial or noncommercial purpose, 
including distributing derivative works.

In return, we simply require that you agree:

1. Not to remove any copyright notices from the Software. 
2. That if you distribute the Software in source code form you do so only 
   under this License (i.e. you must include a complete copy of this License 
   with your distribution), and if you distribute the Software solely in 
   object form you only do so under a license that complies with this License. 
3. That the Software comes "as is", with no warranties. None whatsoever. This 
   means no express, implied or statutory warranty, including without 
   limitation, warranties of merchantability or fitness for a particular 
   purpose or any warranty of noninfringement. Also, you must pass this 
   disclaimer on whenever you distribute the Software.
4. That neither Microsoft nor any contributor to the Software will be liable 
   for any of those types of damages known as indirect, special, consequential, 
   or incidental related to the Software or this License, to the maximum extent 
   the law permits, no matter what legal theory it�s based on. Also, you must 
   pass this limitation of liability on whenever you distribute the Software.
5. That if you sue anyone over patents that you think may apply to the 
   Software for a person's use of the Software, your license to the Software 
   ends automatically. 
6. That the patent rights, if any, licensed hereunder only apply to the 
   Software, not to any derivative works you make. 
7. That your rights under this License end automatically if you breach it in 
   any way.
*/
#endregion
using System;
using System.Web;

namespace nGallery.Lib
{
	/// <summary>
	/// Summary description for PhotosHandler.
	/// </summary>
	public class PhotosRequestHandler : IHttpHandler
	{

		#region IHttpHandler Methods


		/// <summary>
		/// This method processes the incoming request.
		/// </summary>
		/// <param name="context">The HttpContact in which the request was initiated.</param>
		public void ProcessRequest(HttpContext context) 
		{
			string[] parts = context.Request.FilePath.Replace(nGallery.Lib.Configuration.Instance().PhotosDirectory, "").Replace(".aspx", "").Split(new char[] {'/', 'x'});
			int albumID = 0;
			int pictureID = 0;
			int width = 0;
			int height = 0;
			string cacheFile = "";
			string fileExtra = "";

			BL galleryBL = new BL(context.Server.MapPath(nGallery.Lib.Configuration.Instance().DataDirectory), context.Server.MapPath(nGallery.Lib.Configuration.Instance().PhotosDirectory));

			switch(parts.Length)
			{
				case 1:
					// default folder picture
					cacheFile = context.Server.MapPath(nGallery.Lib.Configuration.Instance().PhotosDirectory + "default_highlight_image.jpg");
					context.Response.ContentType = "image/jpeg";
					context.Response.Cache.SetCacheability(HttpCacheability.Public);
					context.Response.Cache.SetExpires(DateTime.Now.AddDays(1));
					context.Response.WriteFile(cacheFile);
					context.Response.End();
					break;
				case 2:
					// original
					albumID = int.Parse(parts[0]);
					pictureID = int.Parse(parts[1]);
					if(nGallery.Lib.Configuration.Instance().OriginalPictureWatermark == true)
					{
						cacheFile = context.Server.MapPath(nGallery.Lib.Configuration.Instance().PhotosDirectory + "cache/" + albumID + "." + pictureID + ".original_watermark");
						if(!System.IO.File.Exists(cacheFile))
						{
							galleryBL.CreatePhotoCache(albumID, pictureID).GetOriginalPicture();
						}
					}
					else
						cacheFile = context.Server.MapPath(nGallery.Lib.Configuration.Instance().PhotosDirectory + albumID + "/" + pictureID);
					break;
				case 3:
					// scaled folder picture
					albumID = int.Parse(parts[0]);
					pictureID = int.Parse(parts[1]);
					if(parts[2] == "highlighted")
					{
						cacheFile = context.Server.MapPath(nGallery.Lib.Configuration.Instance().PhotosDirectory + "cache/" + albumID + "." + pictureID + ".highlighted");
						fileExtra = ".highlighted";
					}
					break;
				case 4:
					// scaled picture
					albumID = int.Parse(parts[0]);
					pictureID = int.Parse(parts[1]);
					width = int.Parse(parts[2]);
					height = int.Parse(parts[3]);
					cacheFile = context.Server.MapPath(nGallery.Lib.Configuration.Instance().PhotosDirectory + "cache/" + albumID + "." + pictureID + "." + width + "x" + height);
					fileExtra = "." + width + "x" + height;
					break;
			}
			
			Picture picture = galleryBL.GetPicture(albumID, pictureID);
			
			System.IO.FileInfo fileInfo = new System.IO.FileInfo(picture.FileName);
			fileExtra = fileInfo.Name.Replace(fileInfo.Extension, fileExtra + fileInfo.Extension);
			
			context.Response.ContentType = "image/jpeg; name=\"" + fileExtra + "\"";
			context.Response.AddHeader("Content-disposition", "inline; filename=\"" + fileExtra + "\"");
			context.Response.Cache.SetCacheability(HttpCacheability.Public);
			context.Response.Cache.SetExpires(DateTime.Now.AddDays(1));
			context.Response.WriteFile(cacheFile);
		}
		

		/// <summary>
		/// Is this handler reusable?
		/// </summary>
		public bool IsReusable 
		{
			get 
			{
				return true;
			}
		} 

	
		#endregion

	}
}
