#region Copyright and License
/*
Copyright 2003 Jason Alexander, nGallery.org
Design work copyright Thomas Johansen (http://www.aylarsolutions.com/)

GOTDOTNET WORKSPACES COMMERCIAL DERIVATIVES LICENSE
Copyright (C) 2003 Microsoft Corporation

You can use this Software for any commercial or noncommercial purpose, 
including distributing derivative works.

In return, we simply require that you agree:

1. Not to remove any copyright notices from the Software. 
2. That if you distribute the Software in source code form you do so only 
   under this License (i.e. you must include a complete copy of this License 
   with your distribution), and if you distribute the Software solely in 
   object form you only do so under a license that complies with this License. 
3. That the Software comes "as is", with no warranties. None whatsoever. This 
   means no express, implied or statutory warranty, including without 
   limitation, warranties of merchantability or fitness for a particular 
      purpose or any warranty of noninfringement. Also, you must pass this 
   disclaimer on whenever you distribute the Software.
4. That neither Microsoft nor any contributor to the Software will be liable 
   for any of those types of damages known as indirect, special, consequential, 
   or incidental related to the Software or this License, to the maximum extent 
   the law permits, no matter what legal theory it�s based on. Also, you must 
   pass this limitation of liability on whenever you distribute the Software.
5. That if you sue anyone over patents that you think may apply to the 
   Software for a person's use of the Software, your license to the Software 
   ends automatically. 
6. That the patent rights, if any, licensed hereunder only apply to the 
   Software, not to any derivative works you make. 
7. That your rights under this License end automatically if you breach it in 
   any way.
*/
#endregion
using System;
using System.Configuration;
using System.Text;
using System.Text.RegularExpressions;
using System.IO;
using System.Web;
using System.Web.Mail;
using System.Collections;
using System.Collections.Specialized;


namespace nGallery.Lib
{


	/// <summary>
	/// This class holds any "global" utility methods that may need to be called statically across the site.
	/// </summary>
	public class Util
	{


		/// <summary>
		/// This method checks to see if the nGallery is configured to use a site password. If so, this handles
		/// redirecting the user to the login page, if no cookie has been set previously (they haven't logged in
		/// before).
		/// </summary>
		/// <param name="hostPage">The instance of the page they are attempting to access.</param>
		public static void CheckSitePassword(System.Web.UI.Page hostPage)
		{
			string sitePassword = "";


			sitePassword = nGallery.Lib.Configuration.Instance().SitePassword;
			if (sitePassword != "")
			{
				if (hostPage.Request.Cookies[Definitions.CookieNames.AS_SITE_AUTHENTICATED] == null)
				{
					hostPage.Response.Redirect("siteLogin.aspx?ReturnURL=" + hostPage.Server.UrlEncode(hostPage.Request.ServerVariables["SCRIPT_NAME"]));
				}
				else
				{
				}
			}
		}


		/// <summary>
		/// This method checks a given file type and returns whether it's a valid image file type.
		/// </summary>
		/// <param name="fileType">The file type of the file, minus any period.</param>
		/// <returns>bool</returns>
		public static bool IsValidImageFile(string fileType)
		{
			fileType = fileType.ToLower();
			if (fileType == "jpg" || fileType == "jpeg" || fileType == "gif" || fileType == "png")
			{
				return true;
			}
			else
			{
				return false;
			}
		}


		/// <summary>
		/// This method takes a file name or path and attempts to extract the file extension from it.
		/// </summary>
		/// <param name="fileName">A full file name or path.</param>
		/// <returns>string</returns>
		public static string DeriveFileType(string fileName)
		{
			string fileType = "";
			string[] fileParts;


			if (fileName.IndexOf(System.IO.Path.DirectorySeparatorChar) != -1)
			{
				string[] filePieces = fileName.Split(System.IO.Path.DirectorySeparatorChar);
				fileParts = filePieces[filePieces.Length - 1].Split('.');
			}
			else
			{
				fileParts = fileName.Split('.');	
			}

			fileType = fileParts[fileParts.Length - 1];

			if (fileType == "")
			{
				throw new Exception("Invalid file name passed to DeriveFileType().");
			}
			else
			{
				return fileType;
			}
		}


		/// <summary>
		/// This method takes a file name or path and attempts to extract the file extension from it.
		/// </summary>
		/// <param name="fileName">A full file name or path.</param>
		/// <returns>string</returns>
		public static string DeriveFileName(string fileName)
		{
			string finalName = "";
			string[] fileParts;


			if (fileName.IndexOf(System.IO.Path.DirectorySeparatorChar) != -1)
			{
				string[] filePieces = fileName.Split(System.IO.Path.DirectorySeparatorChar);
				fileParts = filePieces[filePieces.Length - 1].Split('.');
			}
			else
			{
				fileParts = fileName.Split('.');
			}

			finalName = fileParts[fileParts.Length - 2];

			if (finalName == "")
			{
				throw new Exception("Invalid file name passed to DeriveFileName().");
			}
			else
			{
				return finalName;
			}
		}

		/// <summary>
		/// Gets the encoder information for the specified mimetype.  Used in imagescaling
		/// </summary>
		/// <param name="mimeType">The mimetype of the picture.</param>
		/// <returns>System.Drawing.Imaging.ImageCodecInfo</returns>
		public static System.Drawing.Imaging.ImageCodecInfo GetEncoderInfo(string mimeType)
		{
			System.Drawing.Imaging.ImageCodecInfo [] myEncoders =
				System.Drawing.Imaging.ImageCodecInfo.GetImageEncoders();

			foreach (System.Drawing.Imaging.ImageCodecInfo myEncoder in myEncoders)
				if (myEncoder.MimeType == mimeType)
					return myEncoder;
			return null;
		}


		/// <summary>
		/// This method strips all HTML from any given string.
		/// </summary>
		/// <param name="origString">The original string containing any HTML you want to strip.</param>
		/// <returns>string</returns>
		public static string StripHTML(string origString)
		{
			StringBuilder outputString = new StringBuilder();
			Regex regularExpression = new Regex("<(.|\n)+?>", RegexOptions.IgnoreCase);

			outputString = new StringBuilder(regularExpression.Replace(origString, ""));

			outputString.Replace("<", "&lt;");
			outputString.Replace(">", "&gt;");

			return outputString.ToString();
		}


		public static void SendHtmlEmail(string from, string to, string subject, string body)
		{
			MailMessage mail = new MailMessage();


			mail.From = from;
			mail.To = to;
			mail.Subject = subject;
			mail.Body = body;
			mail.BodyFormat = MailFormat.Html;

			SmtpMail.SmtpServer = Configuration.Instance().SmtpServer;

			SmtpMail.Send(mail);

		}

	}
}
