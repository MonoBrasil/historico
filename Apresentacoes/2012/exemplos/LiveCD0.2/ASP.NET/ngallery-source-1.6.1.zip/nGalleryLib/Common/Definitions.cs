#region Copyright and License
/*
Copyright 2003 Jason Alexander, nGallery.org
Design work copyright Thomas Johansen (http://www.aylarsolutions.com/)

GOTDOTNET WORKSPACES COMMERCIAL DERIVATIVES LICENSE
Copyright (C) 2003 Microsoft Corporation

You can use this Software for any commercial or noncommercial purpose, 
including distributing derivative works.

In return, we simply require that you agree:

1. Not to remove any copyright notices from the Software. 
2. That if you distribute the Software in source code form you do so only 
   under this License (i.e. you must include a complete copy of this License 
   with your distribution), and if you distribute the Software solely in 
   object form you only do so under a license that complies with this License. 
3. That the Software comes "as is", with no warranties. None whatsoever. This 
   means no express, implied or statutory warranty, including without 
   limitation, warranties of merchantability or fitness for a particular 
   purpose or any warranty of noninfringement. Also, you must pass this 
   disclaimer on whenever you distribute the Software.
4. That neither Microsoft nor any contributor to the Software will be liable 
   for any of those types of damages known as indirect, special, consequential, 
   or incidental related to the Software or this License, to the maximum extent 
   the law permits, no matter what legal theory it�s based on. Also, you must 
   pass this limitation of liability on whenever you distribute the Software.
5. That if you sue anyone over patents that you think may apply to the 
   Software for a person's use of the Software, your license to the Software 
   ends automatically. 
6. That the patent rights, if any, licensed hereunder only apply to the 
   Software, not to any derivative works you make. 
7. That your rights under this License end automatically if you breach it in 
   any way.
*/
#endregion
using System;


namespace nGallery.Lib
{


	/// <summary>
	/// This class file contains all constants necessary for the entire nGallery application.
	/// </summary>
	public class Definitions
	{


		
		/// <summary>
		/// Enumerates the known EXIF codes.
		/// </summary>
		public enum exifCode : int
		{

			/// <summary>
			/// 
			/// </summary>
			InteroperabilityIndex = 1,

			/// <summary>
			/// 
			/// </summary>
			ImageWidth = 256,

			/// <summary>
			/// 
			/// </summary>
			ImageLength = 257,

			/// <summary>
			/// 
			/// </summary>
			BitsPerSample = 258,

			/// <summary>
			/// 
			/// </summary>
			Compression = 259,

			/// <summary>
			/// 
			/// </summary>
			PhotometricInterpretation = 262,

			/// <summary>
			/// 
			/// </summary>
			Orientation = 274,

			/// <summary>
			/// 
			/// </summary>
			SamplesPerPixel = 277, 

			/// <summary>
			/// 
			/// </summary>
			PlanarConfiguration = 284,

			/// <summary>
			/// 
			/// </summary>
			YCbCrSubSampling = 530,

			/// <summary>
			/// 
			/// </summary>
			YCbCrPositioning = 531,

			/// <summary>
			/// 
			/// </summary>
			XResolution = 282,

			/// <summary>
			/// 
			/// </summary>
			YResolution = 283,

			/// <summary>
			///
			/// </summary>
			ResolutionUnit = 296,

			/// <summary>
			/// 
			/// </summary>
			StripOffsets = 273,

			/// <summary>
			/// 
			/// </summary>
			RowsPerStrip = 278,

			/// <summary>
			/// 
			/// </summary>
			StripByteCounts = 279,

			/// <summary>
			/// 
			/// </summary>
			JPEGInterchangeFormatLength = 514,

			/// <summary>
			/// 
			/// </summary>
			TransferFunction = 301,

			/// <summary>
			/// 
			/// </summary>
			WhitePoint = 318, 

			/// <summary>
			/// 
			/// </summary>
			PrimaryChromaticities = 319,

			/// <summary>
			/// 
			/// </summary>
			YCbCrCoefficients = 529,

			/// <summary>
			/// 
			/// </summary>
			ReferenceBlackWhite = 532,

			/// <summary>
			/// 
			/// </summary>
			DateTime = 306,

			/// <summary>
			/// 
			/// </summary>
			ImageDescription = 270,

			/// <summary>
			/// 
			/// </summary>
			Make = 271, 

			/// <summary>
			/// 
			/// </summary>
			Model = 272,

			/// <summary>
			/// 
			/// </summary>
			Software = 305,

			/// <summary>
			/// 
			/// </summary>
			Artist = 315,

			/// <summary>
			/// 
			/// </summary>
			Copyright = 33432,

			/// <summary>
			/// 
			/// </summary>
			ExifVersion = 36864,

			/// <summary>
			/// 
			/// </summary>
			FlashpixVersion = 40960,

			/// <summary>
			/// 
			/// </summary>
			ColorSpace = 40961,

			/// <summary>
			/// 
			/// </summary>
			PixelXDimension = 40962,

			/// <summary>
			/// 
			/// </summary>
			PixelYDimension = 40963,

			/// <summary>
			/// 
			/// </summary>
			ComponentsConfiguration = 37121,

			/// <summary>
			/// 
			/// </summary>
			CompressedBitsPerPixel = 37122,

			/// <summary>
			/// 
			/// </summary>
			MakerNote = 37500,

			/// <summary>
			/// 
			/// </summary>
			UserComment = 37510,

			/// <summary>
			/// 
			/// </summary>
			RelatedSoundFile = 40964,

			/// <summary>
			/// 
			/// </summary>
			DateTimeOriginal = 36867,

			/// <summary>
			/// 
			/// </summary>
			DateTimeDigitized = 36868,

			/// <summary>
			/// 
			/// </summary>
			SubsecTime = 37520,

			/// <summary>
			/// 
			/// </summary>
			SubsecTimeOriginal = 37521,

			/// <summary>
			/// 
			/// </summary>
			SubsecTimeDigitized = 37522,

			/// <summary>
			/// 
			/// </summary>
			ExposureTime = 33434,

			/// <summary>
			/// 
			/// </summary>
			FNumber = 33437,

			/// <summary>
			/// 
			/// </summary>
			ExposureProgram = 34850,

			/// <summary>
			/// 
			/// </summary>
			SpectralSensitivity = 34852,

			/// <summary>
			/// 
			/// </summary>
			ISOSpeedRatings = 34855,

			/// <summary>
			/// 
			/// </summary>
			OECF = 34856,

			/// <summary>
			/// 
			/// </summary>
			ShutterSpeedValue = 37377,

			/// <summary>
			/// 
			/// </summary>
			ApertureValue = 37378,

			/// <summary>
			/// 
			/// </summary>
			BrightnessValue = 37379,

			/// <summary>
			/// 
			/// </summary>
			ExposureBiasValue = 37380,

			/// <summary>
			/// 
			/// </summary>
			MaxApertureValue = 37381,

			/// <summary>
			/// 
			/// </summary>
			SubjectDistance = 37382,

			/// <summary>
			/// 
			/// </summary>
			MeteringMode = 37383,

			/// <summary>
			/// 
			/// </summary>
			LightSource = 37384,

			/// <summary>
			/// 
			/// </summary>
			Flash = 37385,

			/// <summary>
			/// 
			/// </summary>
			SubjectArea = 37396,

			/// <summary>
			/// 
			/// </summary>
			FocalLength = 37386,

			/// <summary>
			/// 
			/// </summary>
			FlashEnergy = 41483,

			/// <summary>
			/// 
			/// </summary>
			SpatialFrequencyResponse = 41484,

			/// <summary>
			/// 
			/// </summary>
			FocalPlaneXResolution = 41486,

			/// <summary>
			/// 
			/// </summary>
			FocalPlaneYResolution = 41487,

			/// <summary>
			/// 
			/// </summary>
			FocalPlaneResolutionUnit = 41488,

			/// <summary>
			/// 
			/// </summary>
			SubjectLocation = 41492,

			/// <summary>
			/// 
			/// </summary>
			ExposureIndex = 41493,

			/// <summary>
			/// 
			/// </summary>
			SensingMethod = 41495,

			/// <summary>
			/// 
			/// </summary>
			FileSource = 41728,

			/// <summary>
			/// 
			/// </summary>
			SceneType = 41729,

			/// <summary>
			/// 
			/// </summary>
			CFAPattern = 41730,

			/// <summary>
			/// 
			/// </summary>
			CustomRendered = 41985,

			/// <summary>
			/// 
			/// </summary>
			ExposureMode = 41986,

			/// <summary>
			/// 
			/// </summary>
			WhiteBalance = 41987,

			/// <summary>
			/// 
			/// </summary>
			DigitalZoomRatio = 41988,

			/// <summary>
			/// 
			/// </summary>
			FocalLengthIn35mmFilm = 41989,

			/// <summary>
			/// 
			/// </summary>
			SceneCaptureType = 41990,

			/// <summary>
			/// 
			/// </summary>
			GainControl = 41991,

			/// <summary>
			/// 
			/// </summary>
			Contrast = 41992,

			/// <summary>
			/// 
			/// </summary>
			Saturation = 41993,

			/// <summary>
			/// 
			/// </summary>
			Sharpness = 41994,

			/// <summary>
			/// 
			/// </summary>
			DeviceSettingDescription = 41995,

			/// <summary>
			/// 
			/// </summary>
			SubjectDistanceRange = 41996,

			/// <summary>
			/// 
			/// </summary>
			ImageUniqueID = 42016
		}

		public enum SortOrder
		{

			/// <summary>
			/// This sorts the collection by the name column in ascending order.
			/// </summary>
			NAME_ASCENDING,

			/// <summary>
			/// This sorts the collection by the name column in descending order.
			/// </summary>
			NAME_DESCENDING,

			/// <summary>
			/// This sorts the collection by date in ascending order.
			/// </summary>
			DATE_ASCENDING,

			/// <summary>
			/// This sorts the collection by date in descending order.
			/// </summary>
			DATE_DESCENDING
		}


		/// <summary>
		/// This enum tells the ControlNavigation control which page it's being used for. This
		/// dictates what template it loads, 
		/// </summary>
		public enum NavigationType
		{
			/// <summary>
			/// This enum is the album list navigation.
			/// </summary>
			NAV_ALBUM_LIST,

			/// <summary>
			/// This enum is the picture list navigation.
			/// </summary>
			NAV_PICTURE_LIST,

			/// <summary>
			/// This enum is the picture details navigation.
			/// </summary>
			NAV_PICTURE_DETAILS

		}


		/// <summary>
		/// This enum is used to distinguish heterogenous controls (such as ControlNoItems) so that
		/// they know what context they're used in.
		/// </summary>
		public enum ListType
		{


			/// <summary>
			/// This enum is album list.
			/// </summary>
			ALBUM_LIST,


			/// <summary>
			/// This enum is the picture list.
			/// </summary>
			PICTURE_LIST,


			/// <summary>
			/// This enum is the comment listing.
			/// </summary>
			COMMENT_LIST,


			/// <summary>
			/// This enum is the sub-album listing.
			/// </summary>
			SUBALBUM_LIST
		}


		/// <summary>
		/// This enum is used to define the type of watermark being used.
		/// </summary>
		public enum WatermarkType
		{
			/// <summary>
			/// This enum is a text watermark
			/// </summary>
			WM_TEXT,


			/// <summary>
			/// This enum is an image watermark
			/// </summary>
			WM_IMAGE
		}


		/// <summary>
		/// This enum is used to define the position of the watermark.
		/// </summary>
		public enum WatermarkPosition
		{
			/// <summary>
			/// This enum is for the top left corner
			/// </summary>
			WM_TOP_LEFT,


			/// <summary>
			/// This enum is for the top right corner
			/// </summary>
			WM_TOP_RIGHT,


			/// <summary>
			/// This enum is for the bottom right corner
			/// </summary>
			WM_BOTTOM_RIGHT,


			/// <summary>
			/// This enum is for the bottom left corner
			/// </summary>
			WM_BOTTOM_LEFT
		}



		/// <summary>
		/// This is the file name of the image that is displayed in the album listing when an
		/// album has not chosen a highlight image.
		/// </summary>
		public static readonly string DEFAULT_HIGHLIGHT_IMAGE = "default_highlight_image.jpg";


		/// <summary>
		/// This struct contains all constants necessary for interfacing any cookies that are
		/// set/retrieved on the website.
		/// </summary>
		public struct CookieNames
		{

			/// <summary>
			/// This cookie represents the value of whether or not a user has been authenticated
			/// on the site, when using a SitePassword.
			/// </summary>
			public static readonly string AS_SITE_AUTHENTICATED = "NGSA";


		}

		/// <summary>
		/// This struct contains all constants necessary for interfacing the web.config AppSettings
		/// variables.
		/// </summary>
		public struct AppSettingVariables
		{


			/// <summary>
			/// The site title - this is the title that will be displayed on all pages on
			/// the site. This also is used in replacing the [$NG_SITE_TITLE$] template
			/// variable.
			/// </summary>
			public static readonly string AS_SITE_TITLE				= "SiteTitle";


			/// <summary>
			/// The site skin name - this is the name of the skin directory within the templates
			/// directory.
			/// </summary>
			public static readonly string AS_SITE_SKIN				= "SiteSkin";


			/// <summary>
			/// This key determines whether or not to show the comments features on the nGallery site.
			/// </summary>
			public static readonly string AS_ENABLE_COMMENTS		= "EnableComments";


			/// <summary>
			/// This key determines whether or not to show the ratings features on the nGallery site.
			/// </summary>
			public static readonly string AS_ENABLE_RATINGS			= "EnableRatings";


			/// <summary>
			/// The site password.
			/// </summary>
			public static readonly string AS_SITE_PASSWORD			= "SitePassword";


			/// <summary>
			/// The data directory - this is the key for the value that represents the directory
			/// that all file-based data stores will be kept.
			/// </summary>
			public static readonly string AS_DATA_DIRECTORY			= "DataDirectory";

	
			/// <summary>
			/// The connection string to connect to SQL Server. This is only applicable if using the
			/// SQL Server data store type.
			/// </summary>
			public static readonly string AS_CONNECTION_STRING		= "ConnectionString";


			/// <summary>
			/// The data store type - this is the key for the value that represents the type of
			/// data store that the application should be using - XML or SQLServer.
			/// </summary>
			public static readonly string AS_DATA_STORE_TYPE		= "DataStoreType";


			/// <summary>
			/// The name of the admin directory - this is the key for the value that represents
			/// the name of the admin directory for the application.
			/// </summary>
			public static readonly string AS_ADMIN_DIRECTORY		= "AdminDirectory";


			/// <summary>
			/// The admin user name - this is the key for the value that is the admin user
			/// name, used to access the admin interface.
			/// </summary>
			public static readonly string AS_ADMIN_USER_NAME		= "AdminUserName";


			/// <summary>
			/// The admin user password - this is the key for the value that is the admin user
			/// password, used to access the admin interface.
			/// </summary>
			public static readonly string AS_ADMIN_PASSWORD			= "AdminPassword";


			/// <summary>
			/// The type of remarks system that should be used in picture details. Typically either
			/// "Comment" or "Caption".
			/// </summary>
			public static readonly string AS_COMMENT_TYPE			= "CommentType";


			/// <summary>
			/// The admin email address - this is the key for the value that is the admin's email
			/// address. This is also used in replacing the [$NG_ADMIN_EMAIL_ADDRESS$] template
			/// variable.
			/// </summary>
			public static readonly string AS_ADMIN_EMAIL_ADDRESS	= "AdminEmailAddress";


			/// <summary>
			/// The admin's full name - this is just the admin's full name. This is also used
			/// in replacing the [$NG_ADMIN_FULL_NAME$] template variable.
			/// </summary>
			public static readonly string AS_ADMIN_FULL_NAME		= "AdminFullName";


			/// <summary>
			/// The template directory - this is the key of the value that represents the directory
			/// that all site templates are placed.
			/// </summary>
			public static readonly string AS_TEMPLATE_DIRECTORY		= "TemplateDirectory";


			/// <summary>
			/// The photos directory - this is the key of the value that represents the directory
			/// where all photos are uploaded to.
			/// </summary>
			public static readonly string AS_PHOTOS_DIRECTORY		= "PhotosDirectory";


			/// <summary>
			/// The height that you wish for the images to be on the album listing page.
			/// </summary>
			public static readonly string AS_ALBUM_LIST_IMAGE_HT	= "AlbumListImageHeight";


			/// <summary>
			/// The width that you wish for the images to be on the album listing page.
			/// </summary>
			public static readonly string AS_ALBUM_LIST_IMAGE_WD	= "AlbumListImageWidth";


			/// <summary>
			/// This defines how many albums are shown on the album list before it is paged.
			/// </summary>
			public static readonly string AS_ALBUM_LIST_RPP			= "AlbumListRecordsPerPage";


			/// <summary>
			/// This defines the length of the description string for the album listing page.
			/// </summary>
			public static readonly string AS_ALBUM_LIST_DESC_LEN	= "AlbumListDescLength";


			/// <summary>
			/// This defines the height a picture is to be displayed on the picture listing page.
			/// </summary>
			public static readonly string AS_PICTURE_LIST_IMAGE_HT	= "PictureListImageHeight";


			/// <summary>
			/// This defines the width a picture is to be displayed on the picture listing page.
			/// </summary>
			public static readonly string AS_PICTURE_LIST_IMAGE_WD	= "PictureListImageWidth";


			/// <summary>
			/// This defines whether the aspect ratio is maintained on the picture listing page.
			/// </summary>
			public static readonly string AS_PICTURE_LIST_MAINTAIN_RATIO = "PictureListMaintainRatio";


			/// <summary>
			/// This defines the height of a picture to be displayed on the picture details page.
			/// </summary>
			public static readonly string AS_PICTURE_DETAILS_IMAGE_HT = "PictureDetailsImageHeight";


			/// <summary>
			/// This defines the width of a picture to be displayed on the picture details page.
			/// </summary>
			public static readonly string AS_PICTURE_DETAILS_IMAGE_WD = "PictureDetailsImageWidth";


			/// <summary>
			/// This defines whether the aspect ratio is maintained on the picture listing page.
			/// </summary>
			public static readonly string AS_PICTURE_DETAILS_MAINTAIN_RATIO = "PictureDetailsMaintainRatio";


			/// <summary>
			/// This defines how many pictures are shown on the picture list before it is paged.
			/// </summary>
			public static readonly string AS_PICTURE_LIST_RPP		= "PictureListRecordsPerPage";


			/// <summary>
			/// This defines how many pictures are shown on the picture list before it is paged.
			/// </summary>
			public static readonly string AS_PICTURE_LIST_CPR		= "PictureListColumnsPerRow";


			/// <summary>
			/// This defines the max height an image can be scaled to.
			/// </summary>
			public static readonly string AS_PICTURE_MAX_HEIGHT		= "PictureMaxHeight";


			/// <summary>
			/// This defines the max width an image can be scaled to.
			/// </summary>
			public static readonly string AS_PICTURE_MAX_WIDTH		= "PictureMaxWidth";


			/// <summary>
			/// This defines the SMTP server to use for relaying mail through for purposes for Send To
			/// Friend, etc...
			/// </summary>
			public static readonly string AS_SMTP_SERVER			= "SmtpServer";


			/// <summary>
			/// This is the delay (in milliseconds) between each image in the slide show.
			/// </summary>
			public static readonly string AS_SLIDESHOW_DELAY = "SlideShowDelay";


			/// <summary>
			/// This is the height of the image shown in the slideshow.
			/// </summary>
			public static readonly string AS_SLIDESHOW_IMG_HEIGHT = "SlideShowImageHeight";


			/// <summary>
			/// This is the width of the image shown in the slideshow.
			/// </summary>
			public static readonly string AS_SLIDESHOW_IMG_WIDTH = "SlideShowImageWidth";


			/// <summary>
			/// This is the height of the image to be displayed on the album summary.
			/// </summary>
			public static readonly string AS_SUMMARY_IMAGE_HEIGHT = "SummaryImageHeight";


			/// <summary>
			/// This is the width of the image to be displayed on the album summary.
			/// </summary>
			public static readonly string AS_SUMMARY_IMAGE_WIDTH = "SummaryImageWidth";


			/// <summary>
			/// This is whether or not the summary image should attempt to maintain ratios.
			/// </summary>
			public static readonly string AS_SUMMARY_IMAGE_MAINTAIN_RATIO = "SummaryImageMaintainRatio";


			/// <summary>
			/// This key determines whether or not the paging disables or disappears.
			/// </summary>
			public static readonly string AS_ALBUM_LISTING_PAGING_DISPLAY_TYPE = "AlbumListPagingDisplayType";


			/// <summary>
			/// This key determines whether or not the paging disables or disappears.
			/// </summary>
			public static readonly string AS_PICTURE_LISTING_PAGING_DISPLAY_TYPE = "PictureListPagingDisplayType";


		}


		/// <summary>
		/// This struct containts constants for all templates used in the nGallery application.
		/// </summary>
		public struct Templates
		{


			/// <summary>
			/// The header HTML template.
			/// </summary>
			public static readonly string T_HEADER_TEMPLATE				= "template.header.html";


			/// <summary>
			/// The footer HTML template.
			/// </summary>
			public static readonly string T_FOOTER_TEMPLATE				= "template.footer.html";


			/// <summary>
			/// This template is displayed before any album listing file.
			/// </summary>
			public static readonly string T_ALBUM_LISTING_BEGIN_TAG		= "template.albumlisting.begintag.html";


			/// <summary>
			/// This template is displayed after any album listing file.
			/// </summary>
			public static readonly string T_ALBUM_LISTING_END_TAG		= "template.albumlisting.endtag.html";


			/// <summary>
			/// This template is the individual album control's HTML.
			/// </summary>
			public static readonly string T_ALBUM_ITEM					= "template.album.item.html";


			/// <summary>
			/// This template is the album list navigation HTML.
			/// </summary>
			public static readonly string T_ALBUM_LISTING_NAV			= "template.albumlisting.navigation.html";


			/// <summary>
			/// This template is used when there are no albums in the system.
			/// </summary>
			public static readonly string T_ALBUM_LISTING_NO_ITEMS		= "template.albumlisting.noitems.html";


			/// <summary>
			/// This template is the picture list navigation HTML.
			/// </summary>
			public static readonly string T_PICTURE_LISTING_NAV			= "template.picturelisting.navigation.html";


			/// <summary>
			/// This template is displayed before the picture listing.
			/// </summary>
			public static readonly string T_PICTURE_LISTING_BEGIN_TAG	= "template.picturelisting.begintag.html";


			/// <summary>
			/// This template is displayed after the picture listing.
			/// </summary>
			public static readonly string T_PICTURE_LISTING_END_TAG		= "template.picturelisting.endtag.html";


			/// <summary>
			/// This template is displayed at the start of all the pictures when using columned listings.
			/// </summary>
			public static readonly string T_PICTURE_LISTING_BEGIN_TABLE	= "template.picturelisting.begintable.html";


			/// <summary>
			/// This template is displayed at the end of a all the pictures when using columned listings.
			/// </summary>
			public static readonly string T_PICTURE_LISTING_END_TABLE	= "template.picturelisting.endtable.html";


			/// <summary>
			/// This template is displayed at the start of row when using columned listings.
			/// </summary>
			public static readonly string T_PICTURE_LISTING_BEGIN_ROW	= "template.picturelisting.beginrow.html";


			/// <summary>
			/// This template is displayed at the end of a row when using columned listings.
			/// </summary>
			public static readonly string T_PICTURE_LISTING_END_ROW		= "template.picturelisting.endrow.html";


			/// <summary>
			/// This template is displayed at the start of row when using columned listings.
			/// </summary>
			public static readonly string T_PICTURE_LISTING_BEGIN_COLUMN = "template.picturelisting.begincolumn.html";


			/// <summary>
			/// This template is displayed at the end of a row when using columned listings.
			/// </summary>
			public static readonly string T_PICTURE_LISTING_END_COLUMN	= "template.picturelisting.endcolumn.html";


			/// <summary>
			/// This template is displayed in the picture listing when an album contains no pictures.
			/// </summary>
			public static readonly string T_PICTURE_LISTING_NO_ITEMS	= "template.picturelisting.noitems.html";


			/// <summary>
			/// This template is what is displayed for each picture.
			/// </summary>
			public static readonly string T_PICTURE_ITEM				= "template.picture.item.html";


			/// <summary>
			/// This template is what's displayed when you click on a picture from the picture listing.
			/// </summary>
			public static readonly string T_PICTURE_DETAILS				= "template.picture.details.html";


			/// <summary>
			/// This template is what's displayed for the navigation when you click on a picture from the picture listing.
			/// </summary>
			public static readonly string T_PICTURE_DETAILS_NAV			= "template.picture.details.navigation.html";


			/// <summary>
			/// This template is what's displayed for the picture rating information.
			/// </summary>
			public static readonly string T_PICTURE_DETAILS_RATING		= "template.picture.details.rating.html";


			/// <summary>
			/// This template is displayed in the comment listing when a picture has no comments.
			/// </summary>
			public static readonly string T_COMMENT_LISTING_NO_ITEMS	= "template.commentlisting.noitems.html";


			/// <summary>
			/// This template is displayed before the start of a comment listing.
			/// </summary>
			public static readonly string T_COMMENT_LISTING_BEGIN_TAG	= "template.commentlisting.begintag.html";


			/// <summary>
			/// This template is displayed after a comment listing.
			/// </summary>
			public static readonly string T_COMMENT_LISTING_END_TAG		= "template.commentlisting.endtag.html";


			/// <summary>
			/// This template is used to display each comment.
			/// </summary>
			public static readonly string T_COMMENT_ITEM				= "template.comment.item.html";


			/// <summary>
			/// This template is used for displaying the form that's used to add comments.
			/// </summary>
			public static readonly string T_COMMENT_FORM				= "template.comment.addform.html";


			/// <summary>
			/// This template is used for the send to friend form.
			/// </summary>
			public static readonly string T_SEND_TO_FRIEND				= "template.sendtofriend.html";


			/// <summary>
			/// This template is used to create the HTML email that is sent out for STF for the main gallery/album list.
			/// </summary>
			public static readonly string T_SEND_TO_FRIEND_GALLERY_EMAIL = "template.sendtofriend.email.gallery.html";


			/// <summary>
			/// This template is used to create the HTML email that is sent out for STF for the picture listing.
			/// </summary>
			public static readonly string T_SEND_TO_FRIEND_PIC_LIST_EMAIL = "template.sendtofriend.email.picturelist.html";


			/// <summary>
			/// This template is used to create the HTML email that is sent out from the STF for the picture details.
			/// </summary>
			public static readonly string T_SEND_TO_FRIEND_PIC_DETAILS_EMAIL = "template.sendtofriend.email.picturedetails.html";


			/// <summary>
			/// This template is displayed when an unhandled exception in the application makes it to the CLR.
			/// </summary>
			public static readonly string T_CUSTOM_ERROR_PAGE = "template.errorpage.html";


			/// <summary>
			/// This template is displayed when there are no sub-albums to display.
			/// </summary>
			public static readonly string T_SUBALBUM_LISTING_NO_ITEMS = "template.subalbumlisting.noitems.html";


			/// <summary>
			/// This template is displayed before each subalbum listing.
			/// </summary>
			public static readonly string T_SUBALBUM_LISTING_BEGIN_TAG = "template.subalbumlisting.begintag.html";


			/// <summary>
			/// This template is displayed at the end of each subalbum listing.
			/// </summary>
			public static readonly string T_SUBALBUM_LISTING_END_TAG = "template.subalbumlisting.endtag.html";


			/// <summary>
			/// This template is displayed for each subalbum to be displayed.
			/// </summary>
			public static readonly string T_SUBALBUM_LISTING_ITEM = "template.subalbumlisting.item.html";


			/// <summary>
			/// This template is displayed at the beginning of the EXIF properties to be displayed.
			/// </summary>
			public static readonly string T_EXIF_BEGIN_TAG = "template.exif.begintag.html";


			/// <summary>
			/// This template is displayed for each EXIF property to be displayed.
			/// </summary>
			public static readonly string T_EXIF_ITEM = "template.exif.item.html";


			/// <summary>
			/// This template is displayed at the end of the EXIF properties to be displayed.
			/// </summary>
			public static readonly string T_EXIF_END_TAG = "template.exif.endtag.html";


			public static readonly string T_INVITATION = "template.invitation.email.html";


			public static readonly string T_PICTURE_STATS = "template.picture.details.stats.html";


		}


		/// <summary>
		/// This struct contains constants for any global template variables used site-wide for 
		/// template variables.
		/// </summary>
		public struct GlobalTemplateVariables
		{


			/// <summary>
			/// This variable represents the site's title.
			/// </summary>
			public static readonly string T_SITE_TITLE			= "[$NG_SITE_TITLE$]";


			/// <summary>
			/// This variable displays the Content-Type meta tag for the specific character set encoding.
			/// </summary>
			public static readonly string T_META_CONTENT_TYPE   = "[$NG_META_CONTENT_TYPE$]";


			/// <summary>
			/// This variable represents the admin's email address.
			/// </summary>
			public static readonly string T_ADMIN_EMAIL_ADDRESS	= "[$NG_ADMIN_EMAIL_ADDRESS$]";


			/// <summary>
			/// This variable represents the admin's full name.
			/// </summary>
			public static readonly string T_ADMIN_FULL_NAME		= "[$NG_ADMIN_FULL_NAME$]";


			/// <summary>
			///  This variable represents the header. Anywhere this variable is placed (in a nGalleryPage)
			///  the header HTML is generated and placed.
			/// </summary>
			public static readonly string T_HEADER_VAR			= "[$NG_HEADER$]";


			/// <summary>
			/// This variable represents the footer. Anywhere this variable is placed (in a nGalleryPage)
			/// the footer HTML is generated and placed.
			/// </summary>
			public static readonly string T_FOOTER_VAR			= "[$NG_FOOTER$]";


			/// <summary>
			/// This variable is replaced with any global style sheets that need to be added on a page.
			/// </summary>
			public static readonly string T_STYLE_SHEETS		= "[$NG_STYLE_SHEETS$]";


			/// <summary>
			/// This variable is replaced with the skin name that is being used. Corresponds to the skin's
			/// respective folder in the templates/ folder as well.
			/// </summary>
			public static readonly string T_SKIN_NAME			= "[$NG_SKIN_NAME$]";


		}


		/// <summary>
		/// This struct contains constants for any template variables used in specific composite
		/// controls throughout the code-base and HTML template files.
		/// </summary>
		public struct TemplateVariables
		{


			public struct Invitations
			{
				public static readonly string T_SITE_ADMIN_NAME = "[$NG_SITE_ADMIN_NAME$]";
				public static readonly string T_ALBUM_URL = "[$NG_ALBUM_URL$]";
				public static readonly string T_HIGHLIGHT_IMAGE = "[$NG_HIGHLIGHT_PICTURE$]";
				public static readonly string T_ALBUM_TITLE = "[$NG_ALBUM_TITLE$]";
				public static readonly string T_ALBUM_DESCRIPTION = "[$NG_ALBUM_DESCRIPTION$]";
				public static readonly string T_INVITATION_MESSAGE = "[$NG_INVITATION_MESSAGE$]";
				public static readonly string T_SOURCE_SERVER = "[$NG_SOURCE_SERVER$]";
				public static readonly string T_SKIN_NAME = "[$NG_SKIN_NAME$]";
			}


			/// <summary>
			/// This struct contains any template variables specific to SendToFriend controls.
			/// </summary>
			public struct SendToFriend
			{

				/// <summary>
				/// This template variable is used to display the text box for entering your email address.
				/// </summary>
				public static readonly string T_YOUR_EMAIL_ADDR			= "[$NG_YOUR_EMAIL_ADDR$]";


				/// <summary>
				/// This template variable is used to display the textbox for entering the email addresses to send to.
				/// </summary>
				public static readonly string T_TO_EMAIL_ADDR			= "[$NG_TO_EMAIL_ADDR$]";


				/// <summary>
				/// This template variable is used to display the textbox for entering the email subject.
				/// </summary>
				public static readonly string T_EMAIL_SUBJECT			= "[$NG_EMAIL_SUBJECT$]";


				/// <summary>
				/// This template variable is used to display the textbox for entering the email body.
				/// </summary>
				public static readonly string T_EMAIL_BODY				= "[$NG_EMAIL_BODY$]";


				/// <summary>
				/// This template variable is used to display the submit button.
				/// </summary>
				public static readonly string T_SUBMIT_BUTTON			= "[$NG_SUBMIT_BUTTON$]";


				/// <summary>
				/// This template variable is used to show the status of the form.
				/// </summary>
				public static readonly string T_STATUS_LABEL			= "[$NG_STATUS_LABEL$]";


				/// <summary>
				/// This template variable is used to display the target URL for the STF URL.
				/// </summary>
				public static readonly string T_TARGET_URL				= "[$NG_TARGET_URL$]";


				/// <summary>
				/// This template variable is used to represent the album ID in the STF when sending
				/// a picture list.
				/// </summary>
				public static readonly string T_ALBUM_ID				= "[$NG_ALBM_ID$]";


				/// <summary>
				/// This template variable is used to represent the album name in the STF when sending
				/// a picture listing.
				/// </summary>
				public static readonly string T_ALBUM_NAME				= "[$NG_ALBUM_NAME$]";


				/// <summary>
				/// This template variable is used to represent the picture ID in the STF when sending
				/// from a picture detail page.
				/// </summary>
				public static readonly string T_PICTURE_ID				= "[$NG_PICTURE_ID$]";


				/// <summary>
				/// This template variable is used to represent the picture's name in the STF when sending
				/// from a picture detail page.
				/// </summary>
				public static readonly string T_PICTURE_NAME			= "[$NG_PICTURE_NAME$]";


			}


			/// <summary>
			/// This struct contains any template variables specific to Comment controls.
			/// </summary>
			public struct Comments
			{


				/// <summary>
				/// This template variable is used to display the comment's ID.
				/// </summary>
				public static readonly string T_COMMENT_ID				= "[$NG_COMMENT_ID$]";


				/// <summary>
				/// This template variable is used to display the commenter's name.
				/// </summary>
				public static readonly string T_COMMENT_FROM_NAME		= "[$NG_COMMENT_FROM_NAME$]";


				/// <summary>
				/// This template variable is used to display the commenter's email address.
				/// </summary>
				public static readonly string T_COMMENT_FROM_EMAIL_ADDR	= "[$NG_COMMENT_FROM_EMAIL_ADDR$]";


				/// <summary>
				/// This template variable is used to display the commenter's web URL.
				/// </summary>
				public static readonly string T_COMMENT_FROM_WEB_URL	= "[$NG_COMMENT_FROM_WEB_URL$]";


				/// <summary>
				/// This template variable is used to display the comment's creation date.
				/// </summary>
				public static readonly string T_COMMENT_CREATE_DATE		= "[$NG_COMMENT_CREATE_DATE$]";


				/// <summary>
				/// This template variable is used to display the actual comment text
				/// </summary>
				public static readonly string T_COMMENT_TEXT			= "[$NG_COMMENT_TEXT$]";


				/// <summary>
				/// This template variable is used to display the textbox for commenter's name.
				/// </summary>
				public static readonly string T_COMMENT_FRM_NAME_TXT		= "[$NG_COMMENT_NAME_TXT$]";


				/// <summary>
				/// This template variable is used to display the textbox for the commenter's email address.
				/// </summary>
				public static readonly string T_COMMENT_FRM_EMAIL_ADDR_TXT	= "[$NG_COMMENT_EMAIL_ADDR_TXT$]";


				/// <summary>
				/// This template variable is used to display the textbox for the commenter's website URL.
				/// </summary>
				public static readonly string T_COMMENT_FRM_WEBSITE_URL_TXT = "[$NG_COMMENT_WEBSITE_URL_TXT$]";


				/// <summary>
				/// This template variable is used to display the commenter's actual comment text.
				/// </summary>
				public static readonly string T_COMMENT_FRM_TEXT_AREA		= "[$NG_COMMENT_TEXT_AREA$]";


				/// <summary>
				/// This template variable is used to display the add comment form's submit button.
				/// </summary>
				public static readonly string T_COMMENT_FRM_SUBMIT_BUTTON	= "[$NG_COMMENT_SUBMIT_BUTTON$]";


				/// <summary>
				/// This template variable is used to display the title for the comment type, as configured in
				/// the web.config.
				/// </summary>
				public static readonly string T_COMMENT_TYPE_TITLE			= "[$NG_COMMENT_TYPE_TITLE$]";


			}


			/// <summary>
			/// This struct contains any template variables specific to Album controls.
			/// </summary>
			public struct Albums
			{


				/// <summary>
				/// This template variable is used to get the ID of the album.
				/// </summary>
				public static readonly string T_ALBUM_ID		= "[$NG_ALBUM_ID$]";


				/// <summary>
				/// This template variable is used to get the name of the album.
				/// </summary>
				public static readonly string T_ALBUM_NAME		= "[$NG_ALBUM_NAME$]";


				/// <summary>
				/// This template variable is used to show the total number of albums in the respective context.
				/// </summary>
				public static readonly string T_ALBUM_COUNT		= "[$NG_ALBUM_COUNT$]";


				/// <summary>
				/// This template variable is used to show the number of pictures that are contained within an album.
				/// </summary>
				public static readonly string T_ALBUM_PICTURE_COUNT	= "[$NG_ALBUM_PICTURE_COUNT$]";


				/// <summary>
				/// This template variable is used to show the total number of pictures in the gallery.
				/// </summary>
				public static readonly string T_TOTAL_PICTURE_COUNT	= "[$NG_TOTAL_PICTURE_COUNT$]";


				/// <summary>
				/// This template variable is used to get the description of the album.
				/// </summary>
				public static readonly string T_ALBUM_DESC		= "[$NG_ALBUM_DESC$]";


				/// <summary>
				/// This template variable is used to get the creation date (update date?) of the album.
				/// </summary>
				public static readonly string T_ALBUM_CREATE_DT	= "[$NG_ALBUM_CREATE_DT$]";


				/// <summary>
				/// This template variable is used to get the HTML image tag pointing to the album's highlighted image.
				/// </summary>
				public static readonly string T_ALBUM_HIGHLIGHT_IMAGE = "[$NG_ALBUM_HIGHLIGHT_IMAGE$]";


				/// <summary>
				/// This template variable is used to display the current page in the navigation control.
				/// </summary>
				public static readonly string T_CURRENT_PAGE = "[$NG_CURRENT_PAGE$]";


				/// <summary>
				/// This template variable is used to display the total number of pages in the navigation control.
				/// </summary>
				public static readonly string T_TOTAL_PAGES = "[$NG_TOTAL_PAGES$]";


				/// <summary>
				/// This template variable is used to display a canned paging navigation.
				/// </summary>
				public static readonly string T_PAGING_NAVIGATION = "[$NG_PAGING_NAVIGATION$]";


				/// <summary>
				/// This template variable is used to display the next page number. Will be empty if there is no next page.
				/// </summary>
				public static readonly string T_NEXT_PAGE = "[$NG_NEXT_PAGE$]";

				
				/// <summary>
				/// This template variable is used to display the previous page number. Will be empty if there is no previous page.
				/// </summary>
				public static readonly string T_PREVIOUS_PAGE = "[$NG_PREVIOUS_PAGE$]";


				public static readonly string T_SORT_ORDER_DROP_DOWN = "[$NG_ORDER_BY_DROP_DOWN$]";


				public static readonly string T_ALBUM_URL = "[$NG_ALBUM_URL$]";


				public static readonly string T_GRAND_TOTAL_PICTURE_COUNT = "[$NG_GRAND_TOTAL_PICTURE_COUNT$]";


				public static readonly string T_SUBALBUM_COUNT = "[$NG_SUBALBUM_COUNT$]";

                                
			}


			/// <summary>
			/// This struct contains any template variables specific to Picture controls.
			/// </summary>
			public struct Pictures
			{


				/// <summary>
				/// This template variable will display the picture's respective album ID.
				/// </summary>
				public static readonly string T_PICTURE_ALBUM_ID	= "[$NG_PICTURE_ALBUM_ID$]";


				/// <summary>
				/// This template variable will display the picture's respective album description.
				/// </summary>
				public static readonly string T_PICTURE_ALBUM_DESC  = "[$NG_PICTURE_ALBUM_DESC$]";


				/// <summary>
				/// This template variable will display the picture's respective album's highlight picture.
				/// </summary>
				public static readonly string T_SUMMARY_HIGHLIGHT_PICTURE = "[$NG_SUMMARY_HIGHLIGHT_PICTURE$]";


				/// <summary>
				/// This template variable will display the picture's respective album name.
				/// </summary>
				public static readonly string T_PICTURE_ALBUM_NAME	= "[$NG_PICTURE_ALBUM_NAME$]";


				/// <summary>
				/// This template variable will display the number of pictures in the current album.
				/// </summary>
				public static readonly string T_PICTURE_COUNT		= "[$NG_PICTURE_COUNT$]";


				/// <summary>
				/// This template variable will display the respective picture's ID.
				/// </summary>
				public static readonly string T_PICTURE_ID			= "[$NG_PICTURE_ID$]";


				/// <summary>
				/// This template variable will display the title of the picture.
				/// </summary>
				public static readonly string T_PICTURE_TITLE		= "[$NG_PICTURE_TITLE$]";


				/// <summary>
				/// This template variable will display the respective picture's caption.
				/// </summary>
				public static readonly string T_PICTURE_CAPTION		= "[$NG_PICTURE_CAPTION$]";


				/// <summary>
				/// This template variable will display the amount of times the picture has been viewed.
				/// </summary>
				public static readonly string T_PICTURE_VIEW_COUNT	= "[$NG_PICTURE_VIEW_COUNT$]";


				/// <summary>
				/// This template variable will display the respective picture's literal file name.
				/// </summary>
				public static readonly string T_PICTURE_FILE_NAME	= "[$NG_PICTURE_FILE_NAME$]";


				/// <summary>
				/// This template variable will display the pictures create (or last updated) date.
				/// </summary>
				public static readonly string T_PICTURE_CREATE_DT	= "[$NG_PICTURE_CREATE_DT$]";


				/// <summary>
				/// This template variable will display the full HTML necessary for displaying a picture
				/// properly, based on the thumbnail settings set in the web.config.
				/// </summary>
				public static readonly string T_PICTURE_THUMBNAIL	= "[$NG_PICTURE_THUMBNAIL$]";


				/// <summary>
				/// This template variable will display the full HTML necessary for displaying the picture
				/// fully, not thumbnailed but in it's original entireity.
				/// </summary>
				public static readonly string T_PICTURE_IMAGE		= "[$NG_PICTURE_IMAGE$]";


				/// <summary>
				/// This template variable is used to display the current page in the navigation control.
				/// </summary>
				public static readonly string T_CURRENT_PAGE		= "[$NG_CURRENT_PAGE$]";


				/// <summary>
				/// This template variable is used to display a canned paging navigation.
				/// </summary>
				public static readonly string T_PAGING_NAVIGATION = "[$NG_PAGING_NAVIGATION$]";


				/// <summary>
				/// This template variable is used to display the total number of pages in the navigation control.
				/// </summary>
				public static readonly string T_TOTAL_PAGES			= "[$NG_TOTAL_PAGES$]";


				/// <summary>
				/// This template variable is used to display the next page number. Will be empty if there is no next page.
				/// </summary>
				public static readonly string T_NEXT_PAGE			= "[$NG_NEXT_PAGE$]";

				
				/// <summary>
				/// This template variable is used to display the previous page number. Will be empty if there is no previous page.
				/// </summary>
				public static readonly string T_PREVIOUS_PAGE		= "[$NG_PREVIOUS_PAGE$]";


				/// <summary>
				/// This template variable is used to display a link to the previous album listing, if applicable.
				/// </summary>
				public static readonly string T_PREVIOUS_ALBUM		= "[$NG_PREV_ALBUM$]";


				/// <summary>
				/// This template variable is used to display a link to the next album listing, if applicable.
				/// </summary>
				public static readonly string T_NEXT_ALBUM			= "[$NG_NEXT_ALBUM$]";


				/// <summary>
				/// This template variable is used to display the return URL. This is specifically used when transferring a file
				/// to Shutterfly for printing.
				/// </summary>
				public static readonly string T_RETURN_URL			= "[$NG_RETURN_URL$]";


				/// <summary>
				/// This template variable is used to display the full URL to the photo. This is specifically used when transferring a file
				/// to Shutterfly for printing.
				/// </summary>
				public static readonly string T_PHOTO_URL			= "[$NG_PHOTO_URL$]";


				/// <summary>
				/// This template variable is used to display the full URL to the thumbnail. This is specifically used when transferring a file
				/// to Shutterfly for printing.
				/// </summary>
				public static readonly string T_THUMBNAIL_URL		= "[$NG_THUMBNAIL_URL$]";


				/// <summary>
				/// This template variable is used to display the URL for the previous picture, if applicable.
				/// </summary>
				public static readonly string T_PREV_PICTURE_URL	= "[$NG_PREV_PICTURE$]";


				/// <summary>
				/// This template variable is used to display the URL for the next picture, if applicable.
				/// </summary>
				public static readonly string T_NEXT_PICTURE_URL	= "[$NG_NEXT_PICTURE$]";


				/// <summary>
				/// This template variable is used to display the sub-album listing.
				/// </summary>
				public static readonly string T_SUBALBUM_LISTING	= "[$NG_SUB_ALBUM_CONTROL$]";


				/// <summary>
				/// This template variable is used to display the entire link to this album's parent album,
				/// if applicable.
				/// </summary>
				public static readonly string T_PARENT_ALBUM_LINK	= "[$NG_PARENT_ALBUM_LINK$]";


				/// <summary>
				/// This template variable is used to display the average rating for a picture.
				/// </summary>
				public static readonly string T_PICTURE_RATING		= "[$NG_PICTURE_RATING$]";
				
				
				/// <summary>
				/// This template variable is used to display the number of votes for rating 1.
				/// </summary>
				public static readonly string T_PICTURE_RATING_1	= "[$NG_PICTURE_RATING_1$]";
				
				
				/// <summary>
				/// This template variable is used to display the number of votes for rating 2. 
				/// </summary>
				public static readonly string T_PICTURE_RATING_2	= "[$NG_PICTURE_RATING_2$]";
				
				
				/// <summary>
				/// This template variable is used to display the number of votes for rating 3.
				/// </summary>
				public static readonly string T_PICTURE_RATING_3	= "[$NG_PICTURE_RATING_3$]";
				
				
				/// <summary>
				/// This template variable is used to display the number of votes for rating 4.
				/// </summary>
				public static readonly string T_PICTURE_RATING_4	= "[$NG_PICTURE_RATING_4$]";
				
				
				/// <summary>
				/// This template variable is used to display the number of votes for rating 5.
				/// </summary>
				public static readonly string T_PICTURE_RATING_5	= "[$NG_PICTURE_RATING_5$]";


				/// <summary>
				/// This template variable is used to display the total number of votes for a picture.
				/// </summary>
				public static readonly string T_PICTURE_RATING_TOT_VOTES = "[$NG_PICTURE_RATING_TOT_VOTES$]";


				/// <summary>
				/// This template variable is used to display the percent of votes for rating 1.
				/// </summary>
				public static readonly string T_PICTURE_RATING_PERCENT_1 = "[$NG_PICTURE_RATING_PERCENT_1$]";

			
				/// <summary>
				/// This template variable is used to display the percent of votes for rating 2.
				/// </summary>
				public static readonly string T_PICTURE_RATING_PERCENT_2 = "[$NG_PICTURE_RATING_PERCENT_2$]";
			
			
				/// <summary>
				/// This template variable is used to display the percent of votes for rating 3.
				/// </summary>
				public static readonly string T_PICTURE_RATING_PERCENT_3 = "[$NG_PICTURE_RATING_PERCENT_3$]";
			
			
				/// <summary>
				/// This template variable is used to display the percent of votes for rating 4.
				/// </summary>
				public static readonly string T_PICTURE_RATING_PERCENT_4 = "[$NG_PICTURE_RATING_PERCENT_4$]";
			
			
				/// <summary>
				/// This template variable is used to display the percent of votes for rating 5.
				/// </summary>
				public static readonly string T_PICTURE_RATING_PERCENT_5 = "[$NG_PICTURE_RATING_PERCENT_5$]";


				/// <summary>
				/// This template variable is used to display the check box for voting for rating 1.
				/// </summary>
				public static readonly string T_PICTURE_VOTE_1 = "[$NG_PICTURE_VOTE_1$]";

			
				/// <summary>
				/// This template variable is used to display the check box for voting for rating 2.
				/// </summary>
				public static readonly string T_PICTURE_VOTE_2 = "[$NG_PICTURE_VOTE_2$]";
			
			
				/// <summary>
				/// This template variable is used to display the check box for voting for rating 3.
				/// </summary>
				public static readonly string T_PICTURE_VOTE_3 = "[$NG_PICTURE_VOTE_3$]";
			
			
				/// <summary>
				/// This template variable is used to display the check box for voting for rating 4.
				/// </summary>
				public static readonly string T_PICTURE_VOTE_4 = "[$NG_PICTURE_VOTE_4$]";
			
			
				/// <summary>
				/// This template variable is used to display the check box for voting for rating 5.
				/// </summary>
				public static readonly string T_PICTURE_VOTE_5 = "[$NG_PICTURE_VOTE_5$]";


				/// <summary>
				/// This template variable is used to display the submit button when voting.
				/// </summary>
				public static readonly string T_PICTURE_SUBMIT_VOTE = "[$NG_PICTURE_SUBMIT_VOTE$]";


				/// <summary>
				/// This template variable is used to display the URL to the picture details page.
				/// </summary>
				public static readonly string T_PICTURE_URL = "[$NG_PICTURE_URL$]";


				/// <summary>
				/// This template variable is used to show the number of comments for a specific picture.
				/// </summary>
				public static readonly string T_PICTURE_COMMENT_COUNT = "[$NG_PICTURE_COMMENT_COUNT$]";


				/// <summary>
				/// This template variable is used to show the averating rating of a picture.
				/// </summary>
				public static readonly string T_PICTURE_AVERAGE_RATING = "[$NG_PICTURE_AVERAGE_RATING$]";


				/// <summary>
				/// This template variable is used to display the picture's height.
				/// </summary>
				public static readonly string T_PICTURE_HEIGHT = "[$NG_PICTURE_HEIGHT$]";


				/// <summary>
				/// This template variable is used to display the picture's width.
				/// </summary>
				public static readonly string T_PICTURE_WIDTH = "[$NG_PICTURE_WIDTH$]";


			}
			


			/// <summary>
			/// This struct contains any template variables specific to Unhandled Exception controls.
			/// </summary>
			public struct UnhandledException
			{
				/// <summary>
				/// This template variable is used to get the message of the exception.
				/// </summary>
				public static readonly string T_MESSAGE		= "[$NG_MESSAGE$]";


				/// <summary>
				/// This template variable is used to get the source of the exception.
				/// </summary>
				public static readonly string T_SOURCE		= "[$NG_SOURCE$]";


				/// <summary>
				/// This template variable is used to get stack trace of the exception.
				/// </summary>
				public static readonly string T_STACK_TRACE	= "[$NG_STACK_TRACE$]";
			}



			/// <summary>
			/// This struct is used to set the EXIF property and its corresponding value.
			/// </summary>
			public struct EXIF
			{
				/// <summary>
				/// This template variable is used to set the EXIF propertyvalue.
				/// </summary>
				public static readonly string T_EXIFPROPERTY = "[$NG_EXIFPROPERTY$]";


				/// <summary>
				/// This template variable is used to set the EXIF value.
				/// </summary>
				public static readonly string T_EXIFVALUE = "[$NG_EXIFVALUE$]";
			}
		}



	}
}
