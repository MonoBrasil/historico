#region Copyright and License
/*
Copyright 2003 Jason Alexander, nGallery.org
Design work copyright Thomas Johansen (http://www.aylarsolutions.com/)

GOTDOTNET WORKSPACES COMMERCIAL DERIVATIVES LICENSE
Copyright (C) 2003 Microsoft Corporation

You can use this Software for any commercial or noncommercial purpose, 
including distributing derivative works.

In return, we simply require that you agree:

1. Not to remove any copyright notices from the Software. 
2. That if you distribute the Software in source code form you do so only 
   under this License (i.e. you must include a complete copy of this License 
   with your distribution), and if you distribute the Software solely in 
   object form you only do so under a license that complies with this License. 
3. That the Software comes "as is", with no warranties. None whatsoever. This 
   means no express, implied or statutory warranty, including without 
   limitation, warranties of merchantability or fitness for a particular 
   purpose or any warranty of noninfringement. Also, you must pass this 
   disclaimer on whenever you distribute the Software.
4. That neither Microsoft nor any contributor to the Software will be liable 
   for any of those types of damages known as indirect, special, consequential, 
   or incidental related to the Software or this License, to the maximum extent 
   the law permits, no matter what legal theory it�s based on. Also, you must 
   pass this limitation of liability on whenever you distribute the Software.
5. That if you sue anyone over patents that you think may apply to the 
   Software for a person's use of the Software, your license to the Software 
   ends automatically. 
6. That the patent rights, if any, licensed hereunder only apply to the 
   Software, not to any derivative works you make. 
7. That your rights under this License end automatically if you breach it in 
   any way.
*/
#endregion
using System;
using System.Collections;


namespace nGallery.Lib
{
	/// <summary>
	/// Summary description for GenericSorter.
	/// </summary>
	public class GenericSorter : IComparer
	{


		#region Private Members


		private Definitions.SortOrder _sortOrder;


		#endregion


		#region Constructor(s)


		public GenericSorter()
		{
		}

		
		public GenericSorter(Definitions.SortOrder sortOrder)
		{
			_sortOrder = sortOrder;
		}


		#endregion


		#region Public Properties


		public Definitions.SortOrder SortOrder
		{
			get
			{
				return _sortOrder;
			}
			set
			{
				_sortOrder = value;
			}
		}


		#endregion


		#region IComparer Members

		public int Compare(object x, object y)
		{
			BaseGalleryObject obj1 = (BaseGalleryObject) x;
			BaseGalleryObject obj2 = (BaseGalleryObject) y;


			switch (_sortOrder)
			{
				case Definitions.SortOrder.NAME_ASCENDING:
					
					if (obj1.Name == obj2.Name)
						return 0;
					else
						return obj1.Name.CompareTo(obj2.Name);

					//break;
				case Definitions.SortOrder.NAME_DESCENDING:
					if (obj1.Name == obj2.Name)
						return 0;
					else
						return obj2.Name.CompareTo(obj1.Name);

					//break;
				case Definitions.SortOrder.DATE_ASCENDING:
					if (obj1.CreateDate == obj2.CreateDate)
						return 0;
					else
						return obj1.CreateDate.CompareTo(obj2.CreateDate);

					//break;
				case Definitions.SortOrder.DATE_DESCENDING:
					if (obj1.CreateDate == obj2.CreateDate)
						return 0;
					else
						return obj2.CreateDate.CompareTo(obj1.CreateDate);

					//break;
				default:
					if (obj1.CreateDate == obj2.CreateDate)
						return 0;
					else
						return obj2.CreateDate.CompareTo(obj1.CreateDate);

					//break;
			}
		}
		#endregion


	}
}
