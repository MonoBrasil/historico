#region Copyright and License
/*
Copyright 2003 Jason Alexander, nGallery.org
Design work copyright Thomas Johansen (http://www.aylarsolutions.com/)

GOTDOTNET WORKSPACES COMMERCIAL DERIVATIVES LICENSE
Copyright (C) 2003 Microsoft Corporation

You can use this Software for any commercial or noncommercial purpose, 
including distributing derivative works.

In return, we simply require that you agree:

1. Not to remove any copyright notices from the Software. 
2. That if you distribute the Software in source code form you do so only 
   under this License (i.e. you must include a complete copy of this License 
   with your distribution), and if you distribute the Software solely in 
   object form you only do so under a license that complies with this License. 
3. That the Software comes "as is", with no warranties. None whatsoever. This 
   means no express, implied or statutory warranty, including without 
   limitation, warranties of merchantability or fitness for a particular 
   purpose or any warranty of noninfringement. Also, you must pass this 
   disclaimer on whenever you distribute the Software.
4. That neither Microsoft nor any contributor to the Software will be liable 
   for any of those types of damages known as indirect, special, consequential, 
   or incidental related to the Software or this License, to the maximum extent 
   the law permits, no matter what legal theory it�s based on. Also, you must 
   pass this limitation of liability on whenever you distribute the Software.
5. That if you sue anyone over patents that you think may apply to the 
   Software for a person's use of the Software, your license to the Software 
   ends automatically. 
6. That the patent rights, if any, licensed hereunder only apply to the 
   Software, not to any derivative works you make. 
7. That your rights under this License end automatically if you breach it in 
   any way.
*/
#endregion
using System;
using System.Web;
using System.IO;
using System.Xml.Serialization;

namespace nGallery.Lib
{
	
	
	#region RewriteType Enum


	public enum RewriteType
	{
		ById,
		ByName
	}


	#endregion

	
	/// <summary>
	/// <c>Configuration</c> provides an object that contains all
	/// the application configuration settings.
	/// </summary>
	[Serializable]
	public class Configuration
	{


		#region Private Members

		private static string _configurationFilePath = System.IO.Path.Combine(System.AppDomain.CurrentDomain.BaseDirectory.Replace("/",System.IO.Path.DirectorySeparatorChar.ToString()),"data" + System.IO.Path.DirectorySeparatorChar + "ngallery.config"); 
		private static Configuration _currentConfiguration;
		private string _siteTitle;
		private string _siteSkin;
		private bool _enableComments;
		private bool _enableRatings;
		private bool _enableExif;
		private bool _enableStats;
		private string _sitePassword;
		private string _datastoreType;
		private string _connectionString;
		private string _adminUserName;
		private string _adminPassword;
		private string _adminFullName;
		private string _adminEmailAddress;
		private string _smtpServer;
		private string _commentType;
		private int _albumListImageHeight;
		private int _albumListImageWidth;
		private int _albumListImageQuality;
		private int _albumListRecordsPerPage;
		private int _albumListDescLength;
		private string _albumListPagingDisplayType;
		private bool _originalPictureWatermark;
		private int _pictureListImageHeight;
		private int _pictureListImageWidth;
		private bool _pictureListMaintainRatio;
		private int _pictureListImageQuality;
		private int _pictureDetailsImageHeight;
		private int _pictureDetailsImageWidth;
		private bool _pictureDetailsMaintainRatio;
		private int _pictureDetailsImageQuality;
		private bool _pictureDetailsWatermark;
		private int _pictureListRecordsPerPage;
		private int _pictureListColumnsPerPage;
		private string _pictureListPagingDisplayType;
		private int _pictureMaxHeight;
		private int _pictureMaxWidth;
		private string _adminDirectory;
		private string _dataDirectory;
		private string _templateDirectory;
		private string _photosDirectory;
		private bool _customErrorPageEnabled;
		private int _slideShowDelay;
		private int _slideShowImageHeight;
		private int _slideShowImageWidth;
		private int _slideShowImageQuality;
		private bool _slideShowWatermark;
		private int _summaryImageHeight;
		private int _summaryImageWidth;
		private bool _summaryMaintainRatio;
		private int _summaryImageQuality;
		private bool _summaryWatermark;
		private string _watermarkImage;
		private string _watermarkText;
		private Definitions.WatermarkType _watermarkType;
		private Definitions.WatermarkPosition _watermarkPosition;
		private string _characterSet;
		private string _exifProperties;
		private RewriteType _rewriteType;


		#endregion


		#region Constructor


		public Configuration()
		{
		}


		#endregion


		#region Public Properties


		public RewriteType AlbumRewriting
		{
			get { return _rewriteType; }
			set { _rewriteType = value; }
		}

		public string CharacterSet
		{
			get { return _characterSet; }
			set { _characterSet = value; }
		}

		public string SiteTitle
		{
			get { return _siteTitle; }
			set { _siteTitle = value; }
		}

		public string SiteSkin
		{
			get { return _siteSkin; }
			set { _siteSkin = value; }
		}

		public bool EnableComments
		{
			get { return _enableComments; }
			set { _enableComments = value; }
		}

		public bool EnableRatings
		{
			get { return _enableRatings; }
			set { _enableRatings = value; }
		}

		public bool EnableExif
		{
			get { return _enableExif; }
			set { _enableExif = value; }
		}

		public bool EnableStats
		{
			get { return _enableStats; }
			set { _enableStats = value; }
		}

		public string SitePassword
		{
			get { return _sitePassword; }
			set { _sitePassword = value; }
		}

		public string DatastoreType
		{
			get { return _datastoreType; }
			set { _datastoreType = value; }
		}

		public string ConnectionString
		{
			get { return _connectionString; }
			set { _connectionString = value; }
		}

		public string AdminUserName
		{
			get { return _adminUserName; }
			set { _adminUserName = value; }
		}

		public string AdminPassword
		{
			get { return _adminPassword; }
			set { _adminPassword = value; }
		}

		public string AdminFullName
		{
			get { return _adminFullName; }
			set { _adminFullName = value; }
		}

		public string AdminEmailAddress
		{
			get { return _adminEmailAddress; }
			set { _adminEmailAddress = value; }
		}

		public string SmtpServer
		{
			get { return _smtpServer; }
			set { _smtpServer = value; }
		}

		public string CommentType
		{
			get { return _commentType; }
			set { _commentType = value; }
		}

		public int AlbumListImageHeight
		{
			get { return _albumListImageHeight; }
			set { _albumListImageHeight = value; }
		}

		public int AlbumListImageWidth
		{
			get { return _albumListImageWidth; }
			set { _albumListImageWidth = value; }
		}

		public int AlbumListImageQuality
		{
			get { return _albumListImageQuality; }
			set { if((value > 0) && (value <= 100)) _albumListImageQuality = value; }
		}

		public int AlbumListRecordsPerPage
		{
			get { return _albumListRecordsPerPage; }
			set { _albumListRecordsPerPage = value; }
		}

		public int AlbumListDescLength
		{
			get { return _albumListDescLength; }
			set { _albumListDescLength = value; }
		}

		public string AlbumListPagingDisplayType
		{
			get { return _albumListPagingDisplayType; }
			set { _albumListPagingDisplayType = value; }
		}

		public bool OriginalPictureWatermark
		{
			get { return _originalPictureWatermark; }
			set { _originalPictureWatermark = value; }
		}

		public int PictureListImageHeight
		{
			get { return _pictureListImageHeight; }
			set { _pictureListImageHeight = value; }
		}

		public int PictureListImageWidth
		{
			get { return _pictureListImageWidth; }
			set { _pictureListImageWidth = value; }
		}

		public bool PictureListMaintainRatio
		{
			get { return _pictureListMaintainRatio; }
			set { _pictureListMaintainRatio = value; }
		}

		public int PictureListImageQuality
		{
			get { return _pictureListImageQuality; }
			set { if((value > 0) && (value <= 100)) _pictureListImageQuality = value; }
		}

		public int PictureDetailsImageHeight
		{
			get { return _pictureDetailsImageHeight; }
			set { _pictureDetailsImageHeight = value; }
		}

		public int PictureDetailsImageWidth
		{
			get { return _pictureDetailsImageWidth; }
			set { _pictureDetailsImageWidth = value; }
		}

		public bool PictureDetailsMaintainRatio
		{
			get { return _pictureDetailsMaintainRatio; }
			set { _pictureDetailsMaintainRatio = value; }
		}

		public int PictureDetailsImageQuality
		{
			get { return _pictureDetailsImageQuality; }
			set { if((value > 0) && (value <= 100)) _pictureDetailsImageQuality = value; }
		}

		public bool PictureDetailsWatermark
		{
			get { return _pictureDetailsWatermark; }
			set { _pictureDetailsWatermark = value; }
		}

		public int PictureListRecordsPerPage
		{
			get { return _pictureListRecordsPerPage; }
			set { _pictureListRecordsPerPage = value; }
		}

		public int PictureListColumnsPerPage
		{
			get { return _pictureListColumnsPerPage; }
			set { _pictureListColumnsPerPage = value; }
		}

		public string PictureListPagingDisplayType
		{
			get { return _pictureListPagingDisplayType; }
			set { _pictureListPagingDisplayType = value; }
		}

		public int PictureMaxHeight
		{
			get { return _pictureMaxHeight; }
			set { _pictureMaxHeight = value; }
		}

		public int PictureMaxWidth
		{
			get { return _pictureMaxWidth; }
			set { _pictureMaxWidth = value; }
		}

		public string AdminDirectory
		{
			get { return _adminDirectory; }
			set { _adminDirectory = value; }
		}

		public string DataDirectory
		{
			get { return _dataDirectory; }
			set { _dataDirectory = value; }
		}

		public string TemplateDirectory
		{
			get { return _templateDirectory; }
			set { _templateDirectory = value; }
		}

		public string PhotosDirectory
		{
			get { return _photosDirectory; }
			set { _photosDirectory = value; }
		}

		public bool CustomErrorPageEnabled
		{
			get { return _customErrorPageEnabled; }
			set { _customErrorPageEnabled = value; }
		}

		public int SlideShowDelay
		{
			get { return _slideShowDelay; }
			set { _slideShowDelay = value; }
		}

		public int SlideShowImageHeight
		{
			get { return _slideShowImageHeight; }
			set { _slideShowImageHeight = value; }
		}

		public int SlideShowImageWidth
		{
			get { return _slideShowImageWidth; }
			set { _slideShowImageWidth = value; }
		}

		public int SlideShowImageQuality
		{
			get { return _slideShowImageQuality; }
			set { if((value > 0) && (value <= 100)) _slideShowImageQuality = value; }
		}

		public bool SlideShowWatermark
		{
			get { return _slideShowWatermark; }
			set { _slideShowWatermark = value; }
		}

		public int SummaryImageHeight
		{
			get { return _summaryImageHeight; }
			set { _summaryImageHeight = value; }
		}

		public int SummaryImageWidth
		{
			get { return _summaryImageWidth; }
			set { _summaryImageWidth = value; }
		}

		public bool SummaryMaintainRatio
		{
			get { return _summaryMaintainRatio; }
			set { _summaryMaintainRatio = value; }
		}

		public int SummaryImageQuality
		{
			get { return _summaryImageQuality; }
			set { if((value > 0) && (value <= 100)) _summaryImageQuality = value; }
		}

		public bool SummaryWatermark
		{
			get { return _summaryWatermark; }
			set { _summaryWatermark = value; }
		}

		public string WatermarkImage
		{
			get { return _watermarkImage; }
			set { _watermarkImage = value; }
		}

		public string WatermarkText
		{
			get { return _watermarkText; }
			set { _watermarkText = value; }
		}

		public Definitions.WatermarkType WatermarkType
		{
			get { return _watermarkType; }
			set { _watermarkType = value; }
		}

		public Definitions.WatermarkPosition WatermarkPosition
		{
			get { return _watermarkPosition; }
			set { _watermarkPosition = value; }
		}

		public string EXIFProperties
		{
			get {return _exifProperties;}
			set {_exifProperties = value;}
		}

		#endregion


		#region Static Methods

		public static Configuration Instance()
		{
			if (_currentConfiguration == null)
			{
				Configuration.Load();

				if (_currentConfiguration == null)
					_currentConfiguration = new Configuration();
			}

			return _currentConfiguration;
		}

		public static void Load()
		{
			if (!File.Exists(_configurationFilePath))
			{
				_currentConfiguration = new Configuration();
			}
			else
			{
				XmlSerializer ser	= new XmlSerializer(typeof(Configuration));
				StreamReader reader	= new StreamReader(_configurationFilePath);


				// Deserialize the object into a AlbumCollection and return it.
				_currentConfiguration = (Configuration) ser.Deserialize(reader);

				reader.Close();

			}

		}

		public static void Load(string configFile)
		{
			_configurationFilePath = configFile;
			Load();
		}

		public static void Save()
		{
			XmlSerializer ser	= new XmlSerializer(typeof(Configuration));
			FileStream fileOut;


			if (!File.Exists(_configurationFilePath))
			{
				fileOut = new FileStream(_configurationFilePath, FileMode.CreateNew, FileAccess.ReadWrite, FileShare.ReadWrite);
			}
			else
			{
				fileOut	= new FileStream(_configurationFilePath, FileMode.Truncate, FileAccess.ReadWrite, FileShare.ReadWrite);
			}
			

			// Serialize the object in XML to the given file stream.
			ser.Serialize(fileOut, _currentConfiguration);

			// Close the file stream.
			fileOut.Close();
		}


		#endregion


	}
}
