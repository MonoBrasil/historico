#region Copyright and License
/*
Copyright 2003 Jason Alexander, nGallery.org
Design work copyright Thomas Johansen (http://www.aylarsolutions.com/)

GOTDOTNET WORKSPACES COMMERCIAL DERIVATIVES LICENSE
Copyright (C) 2003 Microsoft Corporation

You can use this Software for any commercial or noncommercial purpose, 
including distributing derivative works.

In return, we simply require that you agree:

1. Not to remove any copyright notices from the Software. 
2. That if you distribute the Software in source code form you do so only 
   under this License (i.e. you must include a complete copy of this License 
   with your distribution), and if you distribute the Software solely in 
   object form you only do so under a license that complies with this License. 
3. That the Software comes "as is", with no warranties. None whatsoever. This 
   means no express, implied or statutory warranty, including without 
   limitation, warranties of merchantability or fitness for a particular 
   purpose or any warranty of noninfringement. Also, you must pass this 
   disclaimer on whenever you distribute the Software.
4. That neither Microsoft nor any contributor to the Software will be liable 
   for any of those types of damages known as indirect, special, consequential, 
   or incidental related to the Software or this License, to the maximum extent 
   the law permits, no matter what legal theory it�s based on. Also, you must 
   pass this limitation of liability on whenever you distribute the Software.
5. That if you sue anyone over patents that you think may apply to the 
   Software for a person's use of the Software, your license to the Software 
   ends automatically. 
6. That the patent rights, if any, licensed hereunder only apply to the 
   Software, not to any derivative works you make. 
7. That your rights under this License end automatically if you breach it in 
   any way.
*/
#endregion
using System;
using System.Collections;
using System.Configuration;
using System.Drawing;
using System.Drawing.Imaging;
using System.Web.UI;
using System.Web.Mail;
using System.Text;
using nGallery.Lib;


namespace nGallery.Lib
{

	
	/// <summary>
	/// This is the business layer of the application. The purpose of this object
	/// really is to only box the DL into the specific data store implementation (set
	/// in the web.config) and to proxy calls in and out.
	/// 
	/// NOTE: Due to the heterogenous nature of the data layer, it's necessary to pass
	/// the data directory into the constructor the majority of the time, unfortunately.
	/// Please let me know if you can think of a better way to clean this up.
	/// </summary>
	public class BL
	{


		#region Private Members


		private string _dataDirectory;
		private string _photoDirectory;
		private string _dataType;
		private nGallery.Lib.DL.DLBase _galleryDL;


		#endregion


		#region Constructors


		/// <summary>
		/// The base constructor for the BL class. This method is what handles grabbing the data type from the
		/// web.config file, and boxing the DL back to the specific implementation.
		/// </summary>
		public BL()
		{
			_dataType		= nGallery.Lib.Configuration.Instance().DatastoreType.Trim().ToLower();

			if (_dataType == "xml")
			{
				_galleryDL = new nGallery.Lib.DL.XML();
			}
			else if (_dataType == "sqlserver")
			{
				_galleryDL = new nGallery.Lib.DL.SQL();
			}
			else
			{
				// TODO: Add custom exceptions
				// here, we need to throw InvalidConfiguration exception
			}
		}

		
		/// <summary>
		/// Constructor to pass in a data directory. This is necessary for the XML data store. Unfortunately, I've found
		/// no good way to do this otherwise, because of the need to user Server.Mappath on the data directory found in the
		/// web.config file settings.
		/// </summary>
		/// <param name="dataDirectory">The directory that the data file is located within.</param>
		public BL(string dataDirectory) : this()
		{
			_dataDirectory = dataDirectory;

			_galleryDL.DataDirectory = _dataDirectory + System.IO.Path.DirectorySeparatorChar + "ngallery.xml";;
		}


		/// <summary>
		/// Constructor to pass in a data directory, and a photo directory. Some operations in the BL require the photo
		/// directory, as well, so this constructor helps set up those requirements.
		/// </summary>
		/// <param name="dataDirectory">The directory that the data file is located within.</param>
		/// <param name="photoDirectory">The directory that the photos are located within.</param>
		public BL(string dataDirectory, string photoDirectory) : this(dataDirectory)
		{
			_photoDirectory = photoDirectory;
		}


		#endregion


		#region Public Methods


		/// <summary>
		/// This method returns the count for all pictures in the gallery.
		/// </summary>
		/// <returns>int</returns>
		public int GetTotalPictureCount()
		{
			int totalCount = 0;


			AlbumCollection albums = this.GetAlbums();

			foreach (Album currentAlbum in albums)
			{
				totalCount += currentAlbum.Pictures.Count;
			}

			return totalCount;
		}


		/// <summary>
		/// This method returns all albums loaded in the data layer.
		/// </summary>
		/// <returns>AlbumCollection</returns>
		public AlbumCollection GetAlbums()
		{
			return _galleryDL.GetAlbums();
		}


		/// <summary>
		/// This method returns the specific album you request, via the album ID.
		/// </summary>
		/// <param name="albumID">The ID of the album you would like</param>
		/// <returns>Album</returns>
		public Album GetAlbum(int albumID)
		{
			return _galleryDL.GetAlbum(albumID);
		}


		/// <summary>
		/// This method creates a album, given the Album object.
		/// </summary>
		/// <param name="album">The Album object you'd like to create</param>
		public void CreateAlbum(Album album)
		{
			if(PhotoCache.CreateAlbum(_photoDirectory, _galleryDL.GetNextAlbumID()))
			{
				_galleryDL.CreateAlbum(album);
			}
		}


		/// <summary>
		/// This method updates the given album with the new information. Given the Album object,
		/// this method looks up the Album in the AlbumCollection by the album ID in the reference
		/// passed in; it then updates any other information in the Album object.
		/// </summary>
		/// <param name="album">The album, and album information, you want to update</param>
		public void UpdateAlbum(Album album)
		{
			_galleryDL.UpdateAlbum(album);
		}


		/// <summary>
		/// This method deletes the album with the given album ID.
		/// </summary>
		/// <param name="albumID">The ID of the album you wish to delete</param>
		public void DeleteAlbum(int albumID)
		{
			AlbumCollection subAlbums = this.GetSubAlbums(albumID);


			if (subAlbums.Count > 0)
			{
				for (int i = 0; i < subAlbums.Count; i++)
				{
					this.DeleteAlbum(subAlbums[i].ID);
				}
			}

			PictureCollection albumPictures = this.GetAlbumPictures(albumID);

			if (albumPictures != null)
			{
				for (int i = 0; i < albumPictures.Count; i++)
				{
					Picture currentPicture = albumPictures[i];
				
					this.DeletePicture(albumID, currentPicture.ID);
				}
			}

			if (PhotoCache.DeleteAlbum(_photoDirectory, albumID))
			{
				_galleryDL.DeleteAlbum(albumID);
			}
		}


		/// <summary>
		/// This method returns all pictures for a given album ID.
		/// </summary>
		/// <param name="albumID">The ID of the album you would like the pictures for</param>
		/// <returns>PictureCollection</returns>
		public PictureCollection GetAlbumPictures(int albumID)
		{
			return _galleryDL.GetAlbumPictures(albumID);
		}


		/// <summary>
		/// This method gets a specific Picture object, based on the album ID and picture ID passed in.
		/// </summary>
		/// <param name="albumID">The album ID the picture is in</param>
		/// <param name="pictureID">The picture ID of the Picture object you want</param>
		/// <returns>Picture</returns>
		public Picture GetPicture(int albumID, int pictureID)
		{
			return _galleryDL.GetPicture(albumID, pictureID);
		}


		/// <summary>
		/// This method creates a picture in the given album ID.
		/// </summary>
		/// <param name="albumID">The ID of the album you wish to create a picture in</param>
		/// <param name="picture">The Picture object that you wish to create</param>
		/// <param name="postedFile">The file object of the picture to be saved.</param>
		public void CreatePicture(int albumID, Picture picture, System.Web.HttpPostedFile postedFile)
		{
			if(PhotoCache.CreatePicture(_photoDirectory, albumID, picture.ID, postedFile))
			{
				_galleryDL.CreatePicture(albumID, picture);
			}
		}


		/// <summary>
		/// This method updates a picture for the given album ID.
		/// </summary>
		/// <param name="albumID">The ID of the album that the picture is in</param>
		/// <param name="picture">The Picture object that you wish to update</param>
		public void UpdatePicture(int albumID, Picture picture)
		{
			_galleryDL.UpdatePicture(albumID, picture);
		}


		/// <summary>
		/// This method deletes a picture for the given album ID and picture ID.
		/// </summary>
		/// <param name="albumID">The ID of the album that the picture is in</param>
		/// <param name="pictureID">The ID of the picture that you want to delete</param>
		public void DeletePicture(int albumID, int pictureID)
		{
			CommentCollection pictureComments = this.GetPictureComments(albumID, pictureID);

			if (pictureComments != null)
			{
				for (int i = 0; i < pictureComments.Count; i++)
				{
					Comment currentComment = pictureComments[i];
				
					this.DeleteComment(albumID, pictureID, currentComment.ID);
				}
			}

			if(PhotoCache.DeletePicture(_photoDirectory, albumID, pictureID))
			{
				_galleryDL.DeletePicture(albumID, pictureID);
			}
		}


		/// <summary>
		/// This method returns the next unique album ID.
		/// </summary>
		/// <returns>int</returns>
		public int GetNextAlbumID()
		{
			return _galleryDL.GetNextAlbumID();
		}


		/// <summary>
		/// This method returns the next unique picture ID, for the given album ID.
		/// </summary>
		/// <param name="albumID">The ID of the album that you need a unique picture ID for</param>
		/// <returns>int</returns>
		public int GetNextPictureID(int albumID)
		{
			return _galleryDL.GetNextPictureID(albumID);
		}


		/// <summary>
		/// This method returns the previous picture's ID for the given album ID and picture ID.
		/// </summary>
		/// <param name="albumID">The ID of the album for the current picture.</param>
		/// <param name="pictureID">The ID of the current picture.</param>
		/// <returns>int</returns>
		public int GetPreviousPictureID(int albumID, int pictureID)
		{
			return _galleryDL.GetPreviousPictureID(albumID, pictureID);
		}


		/// <summary>
		/// This method returns the next picture's ID for the given album ID and picture ID.
		/// </summary>
		/// <param name="albumID">The ID of the album for the current picture.</param>
		/// <param name="pictureID">The ID of the current picture.</param>
		/// <returns>int</returns>
		public int GetNextActualPictureID(int albumID, int pictureID)
		{
			return _galleryDL.GetNextActualPictureID(albumID, pictureID);
		}


		/// <summary>
		/// This method sets the given picture as the highlighted Picture for the given
		/// album ID.
		/// </summary>
		/// <param name="albumID">The ID of the album you wish to set a highlighted picture for</param>
		/// <param name="pictureID">The ID of the picture you wish to set as the highlighted picture</param>
		public void SetHighlightedPicture(int albumID, int pictureID)
		{
			_galleryDL.SetHighlightedPicture(albumID, pictureID);
		}


		/// <summary>
		/// This method returns a CommentCollection for the given album ID, and picture ID.
		/// </summary>
		/// <param name="albumID">The ID of the respective album.</param>
		/// <param name="pictureID">The ID of the respective picture.</param>
		/// <returns>CommentCollection</returns>
		public CommentCollection GetPictureComments(int albumID, int pictureID)
		{
			return _galleryDL.GetPictureComments(albumID, pictureID);
		}


		/// <summary>
		/// This method creates a comment for the given album ID, picture ID and the information
		/// in the Comment object.
		/// </summary>
		/// <param name="albumID">The ID of the respective album.</param>
		/// <param name="pictureID">The ID of the respective picture.</param>
		/// <param name="comment">The Comment object to create.</param>
		public void CreateComment(int albumID, int pictureID, Comment comment)
		{
			_galleryDL.CreateComment(albumID, pictureID, comment);
		}


		/// <summary>
		/// This method returns the next unique comment ID for the given album ID and picture ID.
		/// </summary>
		/// <param name="albumID">The ID of the respective album.</param>
		/// <param name="pictureID">The ID of the respective picture.</param>
		/// <returns>int</returns>
		public int GetNextCommentID(int albumID, int pictureID)
		{
			return _galleryDL.GetNextCommentID(albumID, pictureID);
		}


		/// <summary>
		/// This method deletes a comment for the given album ID, picture ID and comment ID.
		/// </summary>
		/// <param name="albumID">The ID of the respective album.</param>
		/// <param name="pictureID">The ID of the respective picture.</param>
		/// <param name="commentID">The ID of the respective comment.</param>
		public void DeleteComment(int albumID, int pictureID, int commentID)
		{
			_galleryDL.DeleteComment(albumID, pictureID, commentID);
		}


		/// <summary>
		/// Increments the view count for the specified picture.
		/// </summary>
		/// <param name="albumID">ID of the album containing the picture.</param>
		/// <param name="pictureID">ID of the picture.</param>
		public void UpdateViewCount(int albumID, int pictureID)
		{
			_galleryDL.UpdateViewCount(albumID, pictureID);
		}
			

		/// <summary>
		/// This method returns the previous album's ID for the given album ID.
		/// </summary>
		/// <param name="albumID">The ID of the current album.</param>
		/// <returns>int</returns>
		public int GetPreviousAlbumID(int albumID)
		{
			return _galleryDL.GetPreviousAlbumID(albumID);
		}


		/// <summary>
		/// This method returns the next album's ID for the given album ID.
		/// </summary>
		/// <param name="albumID">The ID of the current album.</param>
		/// <returns>int</returns>
		public int GetNextActualAlbumID(int albumID)
		{
			return _galleryDL.GetNextActualAlbumID(albumID);
		}


		/// <summary>
		/// Retrieves all of the information of the sub-ablbums of a particular album.
		/// </summary>
		/// <param name="albumID">The albumID for the album you want the sub-albums of</param>
		/// <returns>AlbumCollection</returns>
		public AlbumCollection GetSubAlbums(int albumID)
		{
			return _galleryDL.GetSubAlbums(albumID);
		}


		/// <summary>
		/// Retrieves all of the top level albums.
		/// </summary>
		/// <returns>AlbumCollection</returns>
		public AlbumCollection GetParentAlbums()
		{
			return _galleryDL.GetParentAlbums();
		}


		/// <summary>
		/// Gets the rating information for a picture.
		/// </summary>
		/// <param name="albumID">The ID of the album</param>
		/// <param name="pictureID">The ID of the picture</param>
		/// <returns>Rating</returns>
		public Rating GetPictureRating(int albumID, int pictureID)
		{
			return _galleryDL.GetPictureRating(albumID, pictureID);
		}


		/// <summary>
		/// Updates the rating information for a picture.
		/// </summary>
		/// <param name="albumID">The ID of the album</param>
		/// <param name="pictureID">The ID of the picture</param>
		/// <param name="rate">The rating information to update</param>
		public void UpdatePictureRating(int albumID, int pictureID, Rating rate)
		{
			_galleryDL.UpdatePictureRating(albumID, pictureID, rate);
		}


		/// <summary>
		/// Clears of the cached thumbnails and resized pictures in the photos directory.
		/// </summary>
		public void ClearPictureCache()
		{
			if (_photoDirectory == null || _photoDirectory.Trim() == "")
			{
				// TODO: Throw custom exception for photo directory not set in BL.
				return;
			}

			PhotoCache.ClearCache(_photoDirectory);
		}


		/// <summary>
		/// Creates a new PhotoCache object with the specified album and picture IDs.
		/// </summary>
		/// <param name="albumID">The album ID of the picture.</param>
		/// <param name="pictureID">The picture ID of the picture.</param>
		/// <returns>nGallery.Lib.PhotoCache</returns>
		public PhotoCache CreatePhotoCache(int albumID, int pictureID)
		{
			if (_photoDirectory == null || _photoDirectory.Trim() == "")
			{
				// TODO: Throw custom exception for photo directory not set in BL.
				return null;
			}

			// If the picture ID is null, it is probably from an album that doesn't have a highlighted
			// picture.  Set it to 0.
			if(pictureID.Equals(null)) { pictureID = 0; }

			PhotoCache photos = new PhotoCache(albumID, pictureID, _photoDirectory);

			return photos;
		}


		public int GetAlbumIDByName(string albumName)
		{
			return _galleryDL.GetAlbumIDByName(albumName);
		}


		public ContactCollection GetContacts()
		{
			return _galleryDL.GetContacts();
		}


		public void CreateContact(Contact contact)
		{
			_galleryDL.CreateContact(contact);
		}


		public int GetNextContactID()
		{
			return _galleryDL.GetNextContactID();
		}


		public Contact GetContact(int contactID)
		{
			return _galleryDL.GetContact(contactID);
		}


		public void UpdateContact(Contact contact)
		{
			_galleryDL.UpdateContact(contact);
		}


		public void DeleteContact(int contactID)
		{
			_galleryDL.DeleteContact(contactID);
		}


		public InvitationCollection GetInvitations()
		{
			return _galleryDL.GetInvitations();
		}

		
		public int GetNextInvitationID()
		{
			return _galleryDL.GetNextInvitationID();
		}


		public void CreateInvitation(Invitation invite)
		{
			_galleryDL.CreateInvitation(invite);
		}


		public void ProcessInvitation(Invitation invite, Page page)
		{
			StringBuilder targetServer = new StringBuilder();
			StringBuilder targetUrl = new StringBuilder();
			string toAddress;
			string fromAddress;
			string subject;
			Album album				= this.GetAlbum(invite.AlbumID);



			// Build out the target URL.
			targetServer.Append("http://");
			targetServer.Append(page.Request.ServerVariables["SERVER_NAME"]);
			targetServer.Append(page.Request.ServerVariables["SERVER_PORT"] != "80" ? ":" + page.Request.ServerVariables["SERVER_PORT"] : "");

			targetUrl.Append(targetServer.ToString());

			if (Configuration.Instance().AlbumRewriting == RewriteType.ById)
			{
				targetUrl.Append(page.Request.ServerVariables["SCRIPT_NAME"].Replace("admin/createInvitation.aspx", "albums/" + album.ID + ".aspx"));
			}
			else if (Configuration.Instance().AlbumRewriting == RewriteType.ByName)
			{
				targetUrl.Append(page.Request.ServerVariables["SCRIPT_NAME"].Replace("admin/createInvitation.aspx", "albums/" + page.Server.UrlEncode(album.Name) + ".aspx"));
			}


			// Setup the mail fields
			fromAddress = Configuration.Instance().AdminFullName + " <" + Configuration.Instance().AdminEmailAddress + ">";
			subject = "Photo Album from " + nGallery.Lib.Configuration.Instance().AdminFullName + ": " + album.Name;

			
			// Attempt to send it out.
			for (int i = 0; i < invite.Recipients.Count; i++)
			{
				Template mailTemplate	= new Template(Definitions.Templates.T_INVITATION, page);
				ArrayList recipientValues = (ArrayList) invite.Recipients[i];
				Contact contact = this.GetContact(int.Parse(recipientValues[0].ToString()));
				string inviteID = recipientValues[1].ToString();
				string highlightedPictureImage;
				PhotoCache pictureCache;

				if (album.HighlightedPicture != null)
					pictureCache = this.CreatePhotoCache(album.ID, album.HighlightedPicture.ID);
				else
					pictureCache = this.CreatePhotoCache(album.ID, 0);

				highlightedPictureImage = "<img src=\"" + targetServer.ToString() + pictureCache.GetFolderPicture() + "\" border=\"0\" alt=\"Album: " + album.Name + "\" width=\"" + pictureCache.Width + "\" height=\"" + pictureCache.Height + "\">";


				// Process the template variables.
				mailTemplate.ProcessesVariable(Definitions.TemplateVariables.Invitations.T_SITE_ADMIN_NAME, Configuration.Instance().AdminFullName);
				mailTemplate.ProcessesVariable(Definitions.TemplateVariables.Invitations.T_ALBUM_URL, targetUrl.ToString() + "?InviteID=" + inviteID);
				mailTemplate.ProcessesVariable(Definitions.TemplateVariables.Invitations.T_ALBUM_TITLE, album.Name);
				mailTemplate.ProcessesVariable(Definitions.TemplateVariables.Invitations.T_ALBUM_DESCRIPTION, album.Description);
				mailTemplate.ProcessesVariable(Definitions.TemplateVariables.Invitations.T_HIGHLIGHT_IMAGE, highlightedPictureImage);
				mailTemplate.ProcessesVariable(Definitions.TemplateVariables.Invitations.T_INVITATION_MESSAGE, invite.Message.Replace("\n", "<br>"));
				mailTemplate.ProcessesVariable(Definitions.TemplateVariables.Invitations.T_SOURCE_SERVER, targetServer.ToString() + "/");
				mailTemplate.ProcessesVariable(Definitions.TemplateVariables.Invitations.T_SKIN_NAME, Configuration.Instance().SiteSkin);

				toAddress			= contact.FirstName + " " + contact.LastName + " <" + contact.EmailAddress + ">";

				Util.SendHtmlEmail(fromAddress, toAddress, subject, mailTemplate.GetString());

			}

		}


		public void DeleteInvitation(int inviteID)
		{
			_galleryDL.DeleteInvitation(inviteID);
		}

		
		public void MarkInvitationRead(string invitationGuid)
		{
			Invitation invite	= _galleryDL.GetInvitationByGuid(invitationGuid);

			// Invite will be null if, for some reason, a previous invite was deleted.
			if (invite == null) return;

			Album album			= _galleryDL.GetAlbum(invite.AlbumID);
			Contact contact		= _galleryDL.GetContactByGuid(invitationGuid);
			string toAddress;
			string fromAddress;
			string subject;
			string body;


			_galleryDL.MarkInvitationRead(invitationGuid);

			toAddress	= Configuration.Instance().AdminFullName + " <" + Configuration.Instance().AdminEmailAddress + ">";
			fromAddress = Configuration.Instance().AdminFullName + " <" + Configuration.Instance().AdminEmailAddress + ">";
			subject		= "[ngallery alert] Album \"" + album.Name + "\" has been viewed!";
			body		= "Your album \"" + album.Name + "\" (invite ID#" + invite.ID + ") has been recently viewed by " + contact.FirstName + " " + contact.LastName + " (" + contact.EmailAddress + ").<br>" +
				          "<br>" +
				          "This e-mail is automatically generated from your nGallery installation. Please do not reply.";

			Util.SendHtmlEmail(fromAddress, toAddress, subject, body);
			
		}


		public ArrayList GetInvitationRecipients(int inviteID)
		{
			return _galleryDL.GetInvitationRecipients(inviteID);
		}


		public int GetTotalPictureCount(int albumID)
		{
			return _galleryDL.GetTotalPictureCount(albumID);
		}

		#endregion


	}
}
