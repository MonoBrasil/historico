#region Copyright and License
/*
Copyright 2003 Jason Alexander, nGallery.org
Design work copyright Thomas Johansen (http://www.aylarsolutions.com/)

GOTDOTNET WORKSPACES COMMERCIAL DERIVATIVES LICENSE
Copyright (C) 2003 Microsoft Corporation

You can use this Software for any commercial or noncommercial purpose, 
including distributing derivative works.

In return, we simply require that you agree:

1. Not to remove any copyright notices from the Software. 
2. That if you distribute the Software in source code form you do so only 
   under this License (i.e. you must include a complete copy of this License 
   with your distribution), and if you distribute the Software solely in 
   object form you only do so under a license that complies with this License. 
3. That the Software comes "as is", with no warranties. None whatsoever. This 
   means no express, implied or statutory warranty, including without 
   limitation, warranties of merchantability or fitness for a particular 
   purpose or any warranty of noninfringement. Also, you must pass this 
   disclaimer on whenever you distribute the Software.
4. That neither Microsoft nor any contributor to the Software will be liable 
   for any of those types of damages known as indirect, special, consequential, 
   or incidental related to the Software or this License, to the maximum extent 
   the law permits, no matter what legal theory it�s based on. Also, you must 
   pass this limitation of liability on whenever you distribute the Software.
5. That if you sue anyone over patents that you think may apply to the 
   Software for a person's use of the Software, your license to the Software 
   ends automatically. 
6. That the patent rights, if any, licensed hereunder only apply to the 
   Software, not to any derivative works you make. 
7. That your rights under this License end automatically if you breach it in 
   any way.
*/
#endregion
using System;
using System.Configuration;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Web;

namespace nGallery.Lib
{


	/// <summary>
	/// The PhotoCache class is used to handle all of the image scaling within nGallery.
	/// It is placed within nGallery.Lib to make it transparent to the user (prevent
	/// malicious users) and so that scaled images can be accessed from outside nGallery
	/// using plugins.
	/// </summary>
	public class PhotoCache
	{


		#region Private Members

		private int		_albumID;
		private int		_pictureID;
		private bool	_maintainRatio;
		private bool	_originalSize;
		private bool	_upScale;
		private int		_width;
		private int		_height;
		private int		_quality;
		private bool	_watermark;
		private string	_watermarkText;
		private string	_watermarkImage;
		private string	_photoDirectory;
		private RotateFlipType	_rotation;

		private Definitions.WatermarkType _watermarkType;
		private Definitions.WatermarkPosition _watermarkPosition;

		#endregion


		#region Constructors

		/// <summary>
		/// The base constructor of the PhotoCache object.
		/// </summary>
		public PhotoCache()
		{
			_maintainRatio	= true;
			_originalSize	= false;
			_upScale		= true;
			_width			= 0;
			_height			= 0;
			_quality		= 100;
			_photoDirectory	= "";
		}

		/// <summary>
		/// The constructor that initalizes with a picture and the photo directory.
		/// </summary>
		/// <param name="albumID">The album ID of the picture to be scaled.</param>
		/// <param name="pictureID">The picture ID of the picture to be scaled.</param>
		/// <param name="photoDirectory">The path to the photos directory.</param>
		public PhotoCache(int albumID, int pictureID, string photoDirectory) : this()
		{
			_albumID		= albumID;
			_pictureID		= pictureID;
			_photoDirectory	= photoDirectory;
		}

		#endregion


		#region Public Properties

		/// <summary>
		/// The album ID of the picture to be scaled.
		/// </summary>
		public int AlbumID
		{
			get
			{
				return _albumID;
			}
			set
			{
				_albumID = value;
			}
		}

		/// <summary>
		/// The picture ID of the picture to be scaled.
		/// </summary>
		public int PictureID
		{
			get
			{
				return _pictureID;
			}
			set
			{
				_pictureID = value;
			}
		}


		/// <summary>
		/// Setting of whether or not to maintain the image ratio.
		/// </summary>
		public bool MaintainRatio
		{
			get
			{
				return _maintainRatio;
			}
			set
			{
				_maintainRatio = value;
			}
		}


		/// <summary>
		/// Whether or not an image should be enlarged (for Picture Details)
		/// </summary>
		public bool UpScale
		{
			get
			{
				return _upScale;
			}
			set
			{
				_upScale = value;
			}
		}


		/// <summary>
		/// The width of the image.  You can set it to what you want the image scaled to
		/// and it will update after scaling to the final width (might have changed if
		/// MaintainRatio or UpScale was set).
		/// </summary>
		public int Width
		{
			get
			{
				return _width;
			}
			set
			{
				_width = value;
			}
		}


		/// <summary>
		/// The height of the image.  You can set it to what you want the image scaled to
		/// and it will udpate after scaling to the final height (might have changed if
		/// Maintain Ratio or UpScale was set).
		/// </summary>
		public int Height
		{
			get
			{
				return _height;
			}
			set
			{
				_height = value;
			}
		}


		/// <summary>
		/// Set the quality of the image for when it is cached.
		/// </summary>
		public int Quality
		{
			get
			{
				return _quality;
			}
			set
			{
				_quality = value;
			}
		}


		/// <summary>
		/// This property sets whether or not to add a watermark.
		/// </summary>
		public bool Watermark
		{
			get
			{
				return _watermark;
			}
			set
			{
				_watermark = value;
			}
		}


		/// <summary>
		/// This specifies the type of watermark (either text or image).
		/// </summary>
		public Definitions.WatermarkType WatermarkType
		{
			get
			{
				return _watermarkType;
			}
			set
			{
				_watermarkType = value;
			}
		}


		/// <summary>
		/// This specifies the position of the watermark in one of the four corners.
		/// </summary>
		public Definitions.WatermarkPosition WatermarkPosition
		{
			get
			{
				return _watermarkPosition;
			}
			set
			{
				_watermarkPosition = value;
			}
		}


		/// <summary>
		/// This is the text that would be used in a text watermark.
		/// </summary>
		public string WatermarkText
		{
			get
			{
				return _watermarkText;
			}
			set
			{
				_watermarkText = value;
			}
		}


		/// <summary>
		/// This is the image that would be used in an image watermark.
		/// </summary>
		public string WatermarkImage
		{
			get
			{
				return _watermarkImage;
			}
			set
			{
				_watermarkImage = value;
			}
		}


		/// <summary>
		/// Set the directory to where images are cached.
		/// </summary>
		public string PhotoDirectory
		{
			get
			{
				return _photoDirectory;
			}
			set
			{
				_photoDirectory = value;
			}
		}


		/// <summary>
		/// Specifies how to rotate the image when scaling.
		/// </summary>
		public RotateFlipType Rotation
		{
			get { return _rotation; }
			set { _rotation = value; }
		}


		#endregion


		#region Public Methods

		/// <summary>
		/// Returns the file location of an folder image.  Used to generate folder
		/// icons with a picture highlighted.
		/// </summary>
		/// <returns>string</returns>
		public string GetFolderPicture()
		{
			string targetPictureFile;

			if(_pictureID == 0)
			{
				_width = 127;
				_height = 119;
				return nGallery.Lib.Configuration.Instance().PhotosDirectory + "/highlighted.aspx";
			}

			if (_photoDirectory.Substring(_photoDirectory.Length - 1, 1) == System.IO.Path.DirectorySeparatorChar.ToString() ||
				_photoDirectory.Substring(_photoDirectory.Length - 1, 1) == "/")
			{
				targetPictureFile = _photoDirectory + _albumID + System.IO.Path.DirectorySeparatorChar + _pictureID;
			}
			else
			{
				targetPictureFile = _photoDirectory + System.IO.Path.DirectorySeparatorChar + _albumID + System.IO.Path.DirectorySeparatorChar + _pictureID;
			}
			
			if (File.Exists(_photoDirectory + System.IO.Path.DirectorySeparatorChar + "cache" + System.IO.Path.DirectorySeparatorChar + _albumID + "." + _pictureID + ".highlighted"))
			{
				_width = 127;
				_height = 119;
				return nGallery.Lib.Configuration.Instance().PhotosDirectory + _albumID + "/" + _pictureID + "/highlighted.aspx";
			}
			
			
			Bitmap image;
			Bitmap picture;
			Graphics folderGraphic;
			ImageCodecInfo codec;
			EncoderParameters eps;

			
			image = new Bitmap(127, 119, PixelFormat.Format24bppRgb);
			picture = new Bitmap(Image.FromFile(targetPictureFile, true));
			

			// Make it so we can do some drawing on the blank image
			folderGraphic = Graphics.FromImage(image);
			folderGraphic.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;

			// add on the folder image
			folderGraphic.DrawImage(Image.FromFile(_photoDirectory + System.IO.Path.DirectorySeparatorChar + "default_highlight_image.JPG", true), 0, 0);

			// see if we want to maintain the image ratio
			_width = 102;
			_height = 97;
			if(_width > picture.Width && _height > picture.Height) 
			{
				_width = picture.Width;
				_height = picture.Height;
			}
			else if(_maintainRatio == true)
			{
				double heightRatio = (double)picture.Height / picture.Width;
				double widthRatio = (double)picture.Width / picture.Height;
				
				int desiredHeight = _height;
				int desiredWidth = _width;
				
				_height = desiredHeight;
				_width = Convert.ToInt32(_height * widthRatio);
				if (_width > desiredWidth)
				{
					_width = desiredWidth;
					_height = Convert.ToInt32(_width * heightRatio);
				}
			}

			// add on the highlighted picture
			folderGraphic.DrawImage(picture, 14+((102-_width)/2), 10+((97-_height)/2), _width, _height);

			// get the codec
			codec = Util.GetEncoderInfo("image/jpeg");

			// some encoder parameters (like quality)
			eps = new EncoderParameters();
			eps.Param[0] = new EncoderParameter(Encoder.Quality, (long)75);

			// save the image
			_width = 127;
			_height = 119;
			image.Save(_photoDirectory + System.IO.Path.DirectorySeparatorChar + "cache" + System.IO.Path.DirectorySeparatorChar + _albumID + "." + _pictureID + ".highlighted", codec, eps);
		
			image.Dispose();
			picture.Dispose();
			folderGraphic.Dispose();
			eps.Dispose();

			return nGallery.Lib.Configuration.Instance().PhotosDirectory + "/" + _albumID + "/" + _pictureID + "/highlighted.aspx";

		}


		/// <summary>
		/// Returns the file location of an image scaled to the thumbnail settings.
		/// </summary>
		/// <returns>string</returns>
		public string GetThumbnail()
		{
			_maintainRatio = nGallery.Lib.Configuration.Instance().PictureListMaintainRatio;
			_width = nGallery.Lib.Configuration.Instance().PictureListImageWidth;
			_height = nGallery.Lib.Configuration.Instance().PictureListImageHeight;
			_upScale = false;
			_quality = nGallery.Lib.Configuration.Instance().PictureListImageQuality;
			_watermark = false;

			return this.GetScaledPicture();
		}


		/// <summary>
		/// Returns the file location of an image scaled to the summary image settings.
		/// </summary>
		/// <returns>string</returns>
		public string GetSummary()
		{
			// If there is no specified picture to show, send the default folder image.
			if(_pictureID == 0)
			{
				return this.GetFolderPicture();
			}
			else
			{
				_maintainRatio = nGallery.Lib.Configuration.Instance().SummaryMaintainRatio;
				_width = nGallery.Lib.Configuration.Instance().SummaryImageWidth;
				_height = nGallery.Lib.Configuration.Instance().SummaryImageHeight;
				_upScale = false;
				_quality = nGallery.Lib.Configuration.Instance().SummaryImageQuality;
				_watermark = nGallery.Lib.Configuration.Instance().SummaryWatermark;
				_watermarkImage = nGallery.Lib.Configuration.Instance().WatermarkImage;
				_watermarkText = nGallery.Lib.Configuration.Instance().WatermarkText;
				_watermarkPosition = nGallery.Lib.Configuration.Instance().WatermarkPosition;
				_watermarkType = nGallery.Lib.Configuration.Instance().WatermarkType;


				return this.GetScaledPicture();
			}
		}


		/// <summary>
		/// Returns the file location of an image scaled to the album list settings.
		/// </summary>
		/// <returns>string</returns>
		public string GetAlbumList()
		{
			// If there is no specified picture to show, send the default folder image.
			if(_pictureID == 0)
			{
				return this.GetFolderPicture();
			}
			else
			{
				_maintainRatio = true;
				_width = nGallery.Lib.Configuration.Instance().AlbumListImageWidth;
				_height = nGallery.Lib.Configuration.Instance().AlbumListImageHeight;
				_upScale = false;
				_quality = nGallery.Lib.Configuration.Instance().AlbumListImageQuality;
				_watermark = false;

				return this.GetScaledPicture();
			}
		}


		/// <summary>
		/// Returns the file location of an image scaled to the picture details settings.
		/// </summary>
		/// <returns>string</returns>
		public string GetPictureDetails()
		{
			_maintainRatio = nGallery.Lib.Configuration.Instance().PictureDetailsMaintainRatio;
			_width = nGallery.Lib.Configuration.Instance().PictureDetailsImageWidth;
			_height = nGallery.Lib.Configuration.Instance().PictureDetailsImageHeight;
			_upScale = false;
			_quality = nGallery.Lib.Configuration.Instance().PictureDetailsImageQuality;
			_watermark = nGallery.Lib.Configuration.Instance().PictureDetailsWatermark;
			_watermarkType = nGallery.Lib.Configuration.Instance().WatermarkType;
			_watermarkPosition = nGallery.Lib.Configuration.Instance().WatermarkPosition;
			_watermarkImage = nGallery.Lib.Configuration.Instance().WatermarkImage;
			_watermarkText = nGallery.Lib.Configuration.Instance().WatermarkText;

			return this.GetScaledPicture();
		}

		public string GetSlideShow()
		{
			_maintainRatio = true;
			_width = nGallery.Lib.Configuration.Instance().SlideShowImageWidth;
			_height = nGallery.Lib.Configuration.Instance().SlideShowImageHeight;
			_upScale = false;
			_quality = nGallery.Lib.Configuration.Instance().SlideShowImageQuality;
			_watermark = nGallery.Lib.Configuration.Instance().SlideShowWatermark;
			_watermarkImage = nGallery.Lib.Configuration.Instance().WatermarkImage;
			_watermarkText = nGallery.Lib.Configuration.Instance().WatermarkText;

			return this.GetScaledPicture();
		}
		
		/// <summary>
		/// Returns the file location of a scaled image.
		/// </summary>
		/// <returns>string</returns>
		public string GetScaledPicture()
		{
			// TODO: This will not work in all scenerios.  We need access to the data directory here.
			
			string dataDirectory = HttpContext.Current.Server.MapPath(nGallery.Lib.Configuration.Instance().DataDirectory);
			BL bl = new BL(dataDirectory, PhotoDirectory);
			Bitmap image = null;

			Picture picture = bl.GetPicture(_albumID, _pictureID);
			int originalHeight = picture.Height;
			int originalWidth = picture.Width;
			
			if (originalHeight == 0 || originalWidth == 0)
			{
				if (image == null)
					image = (Bitmap)Bitmap.FromFile(PhotoDirectory + _albumID + System.IO.Path.DirectorySeparatorChar + _pictureID, false);

				originalHeight = image.Height;
				picture.Height = originalHeight;

				originalWidth = image.Width;
				picture.Width = originalWidth;

				bl.UpdatePicture(_albumID, picture);
			}
			
			// see if we want to maintain the image ratio
			if (_originalSize == true)
			{
				_width = originalWidth;
				_height = originalHeight;
			}
			else if (_maintainRatio == true)
			{
				double heightRatio = (double)originalHeight / originalWidth;
				double widthRatio = (double)originalWidth / originalHeight;
				
				int desiredHeight = _height;
				int desiredWidth = _width;
				
				_height = desiredHeight;
				_width = Convert.ToInt32(_height * widthRatio);
				if (_width > desiredWidth)
				{
					_width = desiredWidth;
					_height = Convert.ToInt32(_width * heightRatio);
				}

			}
			
			// in some instances, we might not want to scale it larger
			if(_upScale == false && (_height > originalHeight || _width > originalWidth))
			{
				_height = originalHeight;
				_width = originalWidth;
				return this.GetOriginalPicture();
			}
			//throw new Exception("." + _watermarkType.ToString() + ".");

			// see the image doesn't already exist
			if(!File.Exists(_photoDirectory + "cache" + System.IO.Path.DirectorySeparatorChar + _albumID + "." + _pictureID + "." + _width + "x" + _height))
			{
				if (image == null)
					image = (Bitmap)Bitmap.FromFile(PhotoDirectory + _albumID + System.IO.Path.DirectorySeparatorChar + _pictureID, false);


				Graphics thumb;
				Bitmap bitmap = new Bitmap(_width, _height);
				thumb = Graphics.FromImage(bitmap);
				thumb.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
				thumb.DrawImage(image, 0, 0, _width, _height);

				// add watermark
				if(_watermark == true)
				{
					switch(_watermarkType)
					{
						case Definitions.WatermarkType.WM_IMAGE:
							this.addWatermarkImage(ref thumb);
							break;
						case Definitions.WatermarkType.WM_TEXT:
							this.addWatermarkText(ref thumb);
							break;
					}
				}

				// add rotation
				if(_rotation.Equals(null) == false)
					bitmap.RotateFlip(_rotation);

				// specify codec
				ImageCodecInfo codec = Util.GetEncoderInfo("image/jpeg");

				// set image quality
				EncoderParameters eps = new EncoderParameters(1);
				eps = new EncoderParameters();
				eps.Param[0] = new EncoderParameter(Encoder.Quality, (long)_quality);

				// save to the cache
				if(_originalSize == true)
				{
					bitmap.Save(_photoDirectory + "cache" + System.IO.Path.DirectorySeparatorChar + _albumID + "." + _pictureID + ".original_watermark", codec, eps);
				}
				else
				{
					bitmap.Save(_photoDirectory + "cache" + System.IO.Path.DirectorySeparatorChar + _albumID + "." + _pictureID + "." + _width + "x" + _height, codec, eps);
				}

				thumb.Dispose();
				bitmap.Dispose();
				eps.Dispose();
			}


			if (image != null)
				image.Dispose();
			
			// return the path
			if(_originalSize == true)
			{
				_originalSize = false;
				return nGallery.Lib.Configuration.Instance().PhotosDirectory + _albumID + "/" + _pictureID + ".aspx";
			}
			else
			{
				return nGallery.Lib.Configuration.Instance().PhotosDirectory + _albumID + "/" + _pictureID + "/" + _width + "x" + _height + ".aspx";
			}
		}


		/// <summary>
		/// Returns the location of the original image.
		/// </summary>
		/// <returns>string</returns>
		public string GetOriginalPicture()
		{
			if(nGallery.Lib.Configuration.Instance().OriginalPictureWatermark == true)
			{
				_originalSize = true;
				_watermark = nGallery.Lib.Configuration.Instance().PictureDetailsWatermark;
				_watermarkType = nGallery.Lib.Configuration.Instance().WatermarkType;
				_watermarkPosition = nGallery.Lib.Configuration.Instance().WatermarkPosition;
				_watermarkImage = nGallery.Lib.Configuration.Instance().WatermarkImage;
				_watermarkText = nGallery.Lib.Configuration.Instance().WatermarkText;
				return this.GetScaledPicture();
			}
			return nGallery.Lib.Configuration.Instance().PhotosDirectory + _albumID + "/" + _pictureID + ".aspx";
		}


		#endregion


		#region Private Methods


		/// <summary>
		/// This method adds text as a watermark to the picture.
		/// </summary>
		/// <param name="picture">The picture being added to.</param>
		private void addWatermarkText(ref Graphics picture)
		{
			int[] sizes = new int[]{16,14,12,10,8,6,4};
			Font crFont = null;
			SizeF crSize = new	SizeF();
			for (int i=0 ;i<7; i++)
			{
				crFont = new Font("arial", sizes[i], FontStyle.Bold);
				crSize = picture.MeasureString(_watermarkText, crFont);

				if((ushort)crSize.Width < (ushort)_width)
					break;
			}

			float xpos = 0;
			float ypos = 0;

			switch(_watermarkPosition)
			{
				case Definitions.WatermarkPosition.WM_TOP_LEFT:
					xpos = ((float)_width * (float).01) + (crSize.Width / 2);
					ypos = (float)_height * (float).01;
					break;
				case Definitions.WatermarkPosition.WM_TOP_RIGHT:
					xpos = ((float)_width * (float).99) - (crSize.Width / 2);
					ypos = (float)_height * (float).01;
					break;
				case Definitions.WatermarkPosition.WM_BOTTOM_RIGHT:
					xpos = ((float)_width * (float).99) - (crSize.Width / 2);
					ypos = ((float)_height * (float).99) - crSize.Height;
					break;
				case Definitions.WatermarkPosition.WM_BOTTOM_LEFT:
					xpos = ((float)_width * (float).01) + (crSize.Width / 2);
					ypos = ((float)_height * (float).99) - crSize.Height;
					break;
			}

			StringFormat StrFormat = new StringFormat();
			StrFormat.Alignment = StringAlignment.Center;

			SolidBrush semiTransBrush2 = new SolidBrush(Color.FromArgb(153, 0, 0,0));
			picture.DrawString(_watermarkText, crFont, semiTransBrush2, xpos+1, ypos+1, StrFormat);

			SolidBrush semiTransBrush = new SolidBrush(Color.FromArgb(153, 255, 255, 255));
			picture.DrawString(_watermarkText, crFont, semiTransBrush, xpos, ypos, StrFormat);


			semiTransBrush2.Dispose();
			semiTransBrush.Dispose();
		}


		/// <summary>
		/// This method adds an image as a watermark to the picture.
		/// </summary>
		/// <param name="picture">The picture being added to.</param>
		private void addWatermarkImage(ref Graphics picture)
		{
			Image watermark = new Bitmap(_photoDirectory + System.IO.Path.DirectorySeparatorChar + _watermarkImage);

			ImageAttributes imageAttributes = new ImageAttributes();
			ColorMap colorMap = new ColorMap();

			colorMap.OldColor = Color.FromArgb(255, 0, 255, 0);
			colorMap.NewColor = Color.FromArgb(0, 0, 0, 0);
			ColorMap[] remapTable = {colorMap};

			imageAttributes.SetRemapTable(remapTable, ColorAdjustType.Bitmap);

			float[][] colorMatrixElements = {
												new float[] {1.0f,  0.0f,  0.0f,  0.0f, 0.0f},
												new float[] {0.0f,  1.0f,  0.0f,  0.0f, 0.0f},
												new float[] {0.0f,  0.0f,  1.0f,  0.0f, 0.0f},
												new float[] {0.0f,  0.0f,  0.0f,  0.3f, 0.0f},
												new float[] {0.0f,  0.0f,  0.0f,  0.0f, 1.0f}
											};

			ColorMatrix colorMatrix = new ColorMatrix(colorMatrixElements);

			imageAttributes.SetColorMatrix(colorMatrix, ColorMatrixFlag.Default, ColorAdjustType.Bitmap);

			int xpos = 0;
			int ypos = 0;

			switch(_watermarkPosition)
			{
				case Definitions.WatermarkPosition.WM_TOP_LEFT:
					xpos = 10;
					ypos = 10;
					break;
				case Definitions.WatermarkPosition.WM_TOP_RIGHT:
					xpos = ((_width - watermark.Width) - 10);
					ypos = 10;
					break;
				case Definitions.WatermarkPosition.WM_BOTTOM_RIGHT:
					xpos = ((_width - watermark.Width) - 10);
					ypos = _height - watermark.Height - 10;
					break;
				case Definitions.WatermarkPosition.WM_BOTTOM_LEFT:
					xpos = 10;
					ypos = _height - watermark.Height - 10;
					break;
			}

			picture.DrawImage(watermark, new Rectangle(xpos, ypos, watermark.Width, watermark.Height), 0, 0, watermark.Width, watermark.Height, GraphicsUnit.Pixel, imageAttributes);


			watermark.Dispose();
			imageAttributes.Dispose();
		}

		#endregion


		#region Public Static Methods


		/// <summary>
		/// Returns the photoDirectory without any trailing spaces or / marks.
		/// </summary>
		/// <param name="photoDirectory">The given photoDirectory</param>
		/// <returns>string</returns>
		private static string ScrubPhotoDirectory(string photoDirectory)
		{
			string finalPhotoDirectory = "";

			if (photoDirectory == null || photoDirectory.Trim() == "")
			{
				throw new Exception("No photo directory passed to ClearCache(). Try again.");
			}

			if (photoDirectory.Substring(photoDirectory.Length - 1, 1) == System.IO.Path.DirectorySeparatorChar.ToString())
			{
				finalPhotoDirectory = photoDirectory.Substring(0, photoDirectory.Length - 1);
			}
			else
			{
				finalPhotoDirectory = photoDirectory;
			}

			return finalPhotoDirectory;
		}


		/// <summary>
		/// Clears all of the scaled images in the cache directory.
		/// </summary>
		/// <param name="photoDirectory">The system path of the photos directory.</param>
		/// <returns>bool</returns>
		public static bool ClearCache(string photoDirectory)
		{
			if (photoDirectory == null || photoDirectory.Trim() == "")
			{
				throw new Exception("No photo directory passed to ClearCache(). Try again.");
			}

			photoDirectory = ScrubPhotoDirectory(photoDirectory);

			// Get the list of cached pictures
			string[] cacheFiles = Directory.GetFiles(photoDirectory + System.IO.Path.DirectorySeparatorChar + "cache");

			// Loop through and delete all of them
			foreach(string fileToDelete in cacheFiles)
			{
				File.Delete(fileToDelete);
			}
			return true;
		}


		/// <summary>
		/// Stores a new picture in the photos directory.
		/// </summary>
		/// <param name="photoDirectory">The system path of the photos directory.</param>
		/// <param name="albumID">The album ID of the picture being stored.</param>
		/// <param name="pictureID">The picture ID of the picture being stored.</param>
		/// <param name="photo">The photo file itself for saving.</param>
		/// <returns>bool</returns>
		public static bool CreatePicture(string photoDirectory, int albumID, int pictureID, System.Web.HttpPostedFile photo)
		{
			if (photoDirectory == null || photoDirectory.Trim() == "")
			{
				throw new Exception("No photo directory passed to CreatePicture(). Try again.");
			}

			photoDirectory = ScrubPhotoDirectory(photoDirectory);

			// Try and save the picture
			if (photo != null)
			{
				photo.SaveAs(photoDirectory + System.IO.Path.DirectorySeparatorChar + albumID + System.IO.Path.DirectorySeparatorChar + pictureID);
			}
			return true;
		}


		/// <summary>
		/// This method deletes a picture for the given album ID and picture ID.
		/// </summary>
		/// <param name="photoDirectory">The system path of the photos directory.</param>
		/// <param name="albumID">The ID of the album that the picture is in</param>
		/// <param name="pictureID">The ID of the picture that you want to delete</param>
		/// <returns>bool</returns>
		public static bool DeletePicture(string photoDirectory, int albumID, int pictureID)
		{
			if (photoDirectory == null || photoDirectory.Trim() == "")
			{
				throw new Exception("No photo directory passed to ClearCache(). Try again.");
			}

			photoDirectory = ScrubPhotoDirectory(photoDirectory);

			// Check to see if the file exists in the photo directory.
			if(File.Exists(photoDirectory + System.IO.Path.DirectorySeparatorChar + albumID + System.IO.Path.DirectorySeparatorChar + pictureID))
			{
				File.Delete(photoDirectory + System.IO.Path.DirectorySeparatorChar + albumID + System.IO.Path.DirectorySeparatorChar + pictureID);

				// Delete any cached items that might exist
				string[] cacheFiles = Directory.GetFiles(photoDirectory + System.IO.Path.DirectorySeparatorChar + "cache", albumID + "." + pictureID + ".*");
				foreach(string fileToDelete in cacheFiles)
				{
					File.Delete(fileToDelete);
				}
			}
			return true;
		}


		/// <summary>
		/// This method creates a new album folder in the photos directory for storing pictures.
		/// </summary>
		/// <param name="photoDirectory">The system path to the photos directory.</param>
		/// <param name="albumID">The album ID of the folder to create.</param>
		/// <returns>bool</returns>
		public static bool CreateAlbum(string photoDirectory, int albumID)
		{
			if (photoDirectory == null || photoDirectory.Trim() == "")
			{
				throw new Exception("No photo directory passed to ClearCache(). Try again.");
			}

			// Try and create the album
			Directory.CreateDirectory(photoDirectory + System.IO.Path.DirectorySeparatorChar + albumID);

			return true;
		}


		/// <summary>
		/// This method deletes an album folder in the photos directory.
		/// </summary>
		/// <param name="photoDirectory">The system path to the photos directory.</param>
		/// <param name="albumID">The album ID of the folder to delete.</param>
		/// <returns>bool</returns>
		public static bool DeleteAlbum(string photoDirectory, int albumID)
		{
			string targetDirectory;


			if (photoDirectory == null || photoDirectory.Trim() == "")
			{
				throw new Exception("No photo directory passed to ClearCache(). Try again.");
			}


			photoDirectory = ScrubPhotoDirectory(photoDirectory);
			targetDirectory = photoDirectory + System.IO.Path.DirectorySeparatorChar + albumID;


			// Try and delete the directory and any files within it
			if (Directory.Exists(targetDirectory))
			{
				Directory.Delete(photoDirectory + System.IO.Path.DirectorySeparatorChar + albumID, true);
			}

			// Delete any cached items that might exist for the album
			// TODO: Update to remove sub-albums cached files as well
			string[] cacheFiles = Directory.GetFiles(photoDirectory + System.IO.Path.DirectorySeparatorChar + "cache", albumID + ".*");
			foreach(string fileToDelete in cacheFiles)
			{

				File.Delete(fileToDelete);
			}

			return true;
		}


		#endregion


	}
}
