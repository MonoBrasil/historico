#region Copyright and License
/*
Copyright 2003 Jason Alexander, nGallery.org
Design work copyright Thomas Johansen (http://www.aylarsolutions.com/)

GOTDOTNET WORKSPACES COMMERCIAL DERIVATIVES LICENSE
Copyright (C) 2003 Microsoft Corporation

You can use this Software for any commercial or noncommercial purpose, 
including distributing derivative works.

In return, we simply require that you agree:

1. Not to remove any copyright notices from the Software. 
2. That if you distribute the Software in source code form you do so only 
   under this License (i.e. you must include a complete copy of this License 
   with your distribution), and if you distribute the Software solely in 
   object form you only do so under a license that complies with this License. 
3. That the Software comes "as is", with no warranties. None whatsoever. This 
   means no express, implied or statutory warranty, including without 
   limitation, warranties of merchantability or fitness for a particular 
   purpose or any warranty of noninfringement. Also, you must pass this 
   disclaimer on whenever you distribute the Software.
4. That neither Microsoft nor any contributor to the Software will be liable 
   for any of those types of damages known as indirect, special, consequential, 
   or incidental related to the Software or this License, to the maximum extent 
   the law permits, no matter what legal theory it�s based on. Also, you must 
   pass this limitation of liability on whenever you distribute the Software.
5. That if you sue anyone over patents that you think may apply to the 
   Software for a person's use of the Software, your license to the Software 
   ends automatically. 
6. That the patent rights, if any, licensed hereunder only apply to the 
   Software, not to any derivative works you make. 
7. That your rights under this License end automatically if you breach it in 
   any way.
*/
#endregion
using System;
using System.Configuration;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace nGallery.Lib
{
	/// <summary>
	/// This control is used to display the details of a Picture object. This control is used when clicking
	/// into a picture from the picture listing page.
	/// </summary>
	public class ControlPictureRating : System.Web.UI.WebControls.WebControl, INamingContainer
	{


		#region Private Members


		private int _albumID;
		private int _pictureID;
		private Rating		_rating;
		private RadioButton _vote1;
		private RadioButton _vote2;
		private RadioButton _vote3;
		private RadioButton _vote4;
		private RadioButton _vote5;
		private Button		_submitButton = new Button();


		#endregion

	
		#region Constructor(s)


		/// <summary>
		/// The main constructor for ControlCommentForm.
		/// </summary>
		public ControlPictureRating()
		{
			this.ID = "VoteForm";
			_rating	= new Rating();
			_vote1	= new RadioButton();
			_vote2	= new RadioButton();
			_vote3	= new RadioButton();
			_vote4	= new RadioButton();
			_vote5	= new RadioButton();
		}


		#endregion


		#region Public Properties


		/// <summary>
		/// The ID of the album of the respective picture being rated.
		/// </summary>
		public int AlbumID
		{
			get
			{
				return _albumID;
			}
			set
			{
				_albumID = value;
			}
		}


		/// <summary>
		/// The ID of the picture being rated.
		/// </summary>
		public int PictureID
		{
			get
			{
				return _pictureID;
			}
			set
			{
				_pictureID = value;
			}
		}


		/// <summary>
		/// This property is used to get or set the Rating information that will be displayed.
		/// </summary>
		public Rating Rating
		{
			get
			{
				return _rating;
			}
			set
			{
				_rating = value;
			}
		}

		#endregion


		#region Protected Methods


		/// <summary>
		/// This method is responsible for setting up the control tree for all child controls.
		/// </summary>
		protected override void CreateChildControls()
		{
			// Setup button
			_submitButton.ID = "btnSubmitVote";
			_submitButton.Text = "Vote";
			_submitButton.CommandArgument = "SubmitVote";
			_submitButton.Click += new EventHandler(submitButton_Click);

			// Setup the radio buttons
			_vote1.GroupName = "voteval";
			_vote2.GroupName = "voteval";
			_vote3.GroupName = "voteval";
			_vote4.GroupName = "voteval";
			_vote5.GroupName = "voteval";

			// Add them to the control tree.
			this.Controls.Add(_vote1);
			this.Controls.Add(_vote2);
			this.Controls.Add(_vote3);
			this.Controls.Add(_vote4);
			this.Controls.Add(_vote5);
			this.Controls.Add(_submitButton);
		}

		
		/// <summary> 
		/// Render this control to the output parameter specified.
		/// </summary>
		/// <param name="output"> The HTML writer to write out to </param>
		protected override void Render(HtmlTextWriter output)
		{
			Template template = new Template(Definitions.Templates.T_PICTURE_DETAILS_RATING, this.Page);
			string vote1			= "";
			string vote2			= "";
			string vote3			= "";
			string vote4			= "";
			string vote5			= "";
			string submitButtonText	= "";
			System.Text.StringBuilder controlText   = new System.Text.StringBuilder();
			System.IO.StringWriter stringWriter		= new System.IO.StringWriter(controlText);
			HtmlTextWriter htmlWriter				= new HtmlTextWriter(stringWriter);

			// Render vote1
			_vote1.RenderControl(htmlWriter);
			vote1 = controlText.ToString();
			controlText.Remove(0, controlText.Length);

			// Render vote2
			_vote2.RenderControl(htmlWriter);
			vote2 = controlText.ToString();
			controlText.Remove(0, controlText.Length);

			// Render vote3
			_vote3.RenderControl(htmlWriter);
			vote3 = controlText.ToString();
			controlText.Remove(0, controlText.Length);

			// Render vote4
			_vote4.RenderControl(htmlWriter);
			vote4 = controlText.ToString();
			controlText.Remove(0, controlText.Length);

			// Render vote5
			_vote5.RenderControl(htmlWriter);
			vote5 = controlText.ToString();
			controlText.Remove(0, controlText.Length);

			// Render submit button
			_submitButton.RenderControl(htmlWriter);
			submitButtonText = controlText.ToString();


			// Do the template replacements.
			template.ProcessesVariable(Definitions.TemplateVariables.Pictures.T_PICTURE_RATING_TOT_VOTES,	_rating.TotalVotes);
			template.ProcessesVariable(Definitions.TemplateVariables.Pictures.T_PICTURE_RATING_1,			_rating.Rating1);
			template.ProcessesVariable(Definitions.TemplateVariables.Pictures.T_PICTURE_RATING_2,			_rating.Rating2);
			template.ProcessesVariable(Definitions.TemplateVariables.Pictures.T_PICTURE_RATING_3,			_rating.Rating3);
			template.ProcessesVariable(Definitions.TemplateVariables.Pictures.T_PICTURE_RATING_4,			_rating.Rating4);
			template.ProcessesVariable(Definitions.TemplateVariables.Pictures.T_PICTURE_RATING_5,			_rating.Rating5);
			template.ProcessesVariable(Definitions.TemplateVariables.Pictures.T_PICTURE_RATING_PERCENT_1,	(100 * _rating.Rating1 / ((_rating.TotalVotes != 0) ? _rating.TotalVotes : 1)));
			template.ProcessesVariable(Definitions.TemplateVariables.Pictures.T_PICTURE_RATING_PERCENT_2,	(100 * _rating.Rating2 / ((_rating.TotalVotes != 0) ? _rating.TotalVotes : 1)));
			template.ProcessesVariable(Definitions.TemplateVariables.Pictures.T_PICTURE_RATING_PERCENT_3,	(100 * _rating.Rating3 / ((_rating.TotalVotes != 0) ? _rating.TotalVotes : 1)));
			template.ProcessesVariable(Definitions.TemplateVariables.Pictures.T_PICTURE_RATING_PERCENT_4,	(100 * _rating.Rating4 / ((_rating.TotalVotes != 0) ? _rating.TotalVotes : 1)));
			template.ProcessesVariable(Definitions.TemplateVariables.Pictures.T_PICTURE_RATING_PERCENT_5,	(100 * _rating.Rating5 / ((_rating.TotalVotes != 0) ? _rating.TotalVotes : 1)));
			template.ProcessesVariable(Definitions.TemplateVariables.Pictures.T_PICTURE_RATING,				_rating.GetRating().ToString());

			// Add in the radio buttons
			template.ProcessesVariable(Definitions.TemplateVariables.Pictures.T_PICTURE_VOTE_1, vote1);
			template.ProcessesVariable(Definitions.TemplateVariables.Pictures.T_PICTURE_VOTE_2, vote2);
			template.ProcessesVariable(Definitions.TemplateVariables.Pictures.T_PICTURE_VOTE_3, vote3);
			template.ProcessesVariable(Definitions.TemplateVariables.Pictures.T_PICTURE_VOTE_4, vote4);
			template.ProcessesVariable(Definitions.TemplateVariables.Pictures.T_PICTURE_VOTE_5, vote5);
			template.ProcessesVariable(Definitions.TemplateVariables.Pictures.T_PICTURE_SUBMIT_VOTE, submitButtonText);

			// Write out the template.
			output.Write(template.GetString());
		}


		#endregion


		#region Private Methods


		/// <summary>
		/// This method handles the main processing of the form.
		/// </summary>
		/// <param name="sender">The object that is sending the call.</param>
		/// <param name="e">Any EventArgs being passed.</param>
		private void submitButton_Click(object sender, System.EventArgs e)
		{
			EnsureChildControls();

			nGallery.Lib.BL galleryBL = new nGallery.Lib.BL(this.Page.Server.MapPath(nGallery.Lib.Configuration.Instance().DataDirectory));
			string albumName = galleryBL.GetAlbum(_albumID).Name;
			Rating newRating;


			// Get the current Rating
			newRating = galleryBL.GetPictureRating(_albumID, _pictureID);

			// Add to whichever one they voted for
			if (_vote1.Checked == true) { newRating.Rating1 = newRating.Rating1 + 1; }
			else if (_vote2.Checked == true) { newRating.Rating2 = newRating.Rating2 + 1; }
			else if (_vote3.Checked == true) { newRating.Rating3 = newRating.Rating3 + 1; }
			else if (_vote4.Checked == true) { newRating.Rating4 = newRating.Rating4 + 1; }
			else if (_vote5.Checked == true) { newRating.Rating5 = newRating.Rating5 + 1; }

			galleryBL.UpdatePictureRating(_albumID, _pictureID, newRating);

			if (Configuration.Instance().AlbumRewriting == RewriteType.ById)
				this.Page.Response.Redirect("~/albums/" + _albumID.ToString() + "/" + _pictureID + ".aspx");
			else if (Configuration.Instance().AlbumRewriting == RewriteType.ByName)
				this.Page.Response.Redirect("~/albums/" + this.Page.Server.UrlEncode(albumName) + "/" + _pictureID + ".aspx");
		}


		#endregion


	}
}
