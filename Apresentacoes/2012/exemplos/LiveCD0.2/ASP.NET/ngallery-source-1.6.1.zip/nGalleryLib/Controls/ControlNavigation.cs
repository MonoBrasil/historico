#region Copyright and License
/*
Copyright 2003 Jason Alexander, nGallery.org
Design work copyright Thomas Johansen (http://www.aylarsolutions.com/)

GOTDOTNET WORKSPACES COMMERCIAL DERIVATIVES LICENSE
Copyright (C) 2003 Microsoft Corporation

You can use this Software for any commercial or noncommercial purpose, 
including distributing derivative works.

In return, we simply require that you agree:

1. Not to remove any copyright notices from the Software. 
2. That if you distribute the Software in source code form you do so only 
   under this License (i.e. you must include a complete copy of this License 
   with your distribution), and if you distribute the Software solely in 
   object form you only do so under a license that complies with this License. 
3. That the Software comes "as is", with no warranties. None whatsoever. This 
   means no express, implied or statutory warranty, including without 
   limitation, warranties of merchantability or fitness for a particular 
   purpose or any warranty of noninfringement. Also, you must pass this 
   disclaimer on whenever you distribute the Software.
4. That neither Microsoft nor any contributor to the Software will be liable 
   for any of those types of damages known as indirect, special, consequential, 
   or incidental related to the Software or this License, to the maximum extent 
   the law permits, no matter what legal theory it�s based on. Also, you must 
   pass this limitation of liability on whenever you distribute the Software.
5. That if you sue anyone over patents that you think may apply to the 
   Software for a person's use of the Software, your license to the Software 
   ends automatically. 
6. That the patent rights, if any, licensed hereunder only apply to the 
   Software, not to any derivative works you make. 
7. That your rights under this License end automatically if you breach it in 
   any way.
*/
#endregion
using System;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.ComponentModel;


namespace nGallery.Lib
{


	/// <summary>
	/// This control is used to display the navigation of each page in nGallery.
	/// </summary>
	public class ControlNavigation : System.Web.UI.WebControls.WebControl
	{

		#region Private Members


		private nGallery.Lib.Definitions.NavigationType _navType;
		private int		_recordCount;
		private int		_currentPage;
		private int		_totalPages;
		private int		_nextPage;
		private int		_previousPage;
		private int		_pictureCount;
		private string	_albumName;
		private int		_albumID;
		private int		_parentAlbumID;
		private string	_parentAlbumName;
		private string	_pictureTitle;


		#endregion


		#region Constructors


		/// <summary>
		/// ControlNavigation's constructor.
		/// </summary>
		/// <param name="navType">The type of navigation this control is to act as in this instance.</param>
		public ControlNavigation(nGallery.Lib.Definitions.NavigationType navType)
		{
			_navType		= navType;
			_currentPage	= 1;
			_totalPages		= 1;
			_recordCount	= 0;
		}


		#endregion


		#region Public Properties


		/// <summary>
		/// The current page number.
		/// </summary>
		public int CurrentPage
		{
			get
			{
				return _currentPage;
			}
			set
			{
				_currentPage = value;
				this.RecalculateStats();
			}
		}


		/// <summary>
		/// The ID of the parent album, if applicable.
		/// </summary>
		public int ParentAlbumID
		{
			get
			{
				return _parentAlbumID;
			}
			set
			{
				_parentAlbumID = value;
			}
		}


		/// <summary>
		/// The name of the parent album, if applicable.
		/// </summary>
		public string ParentAlbumName
		{
			get
			{
				return _parentAlbumName;
			}
			set
			{
				_parentAlbumName = value;
			}
		}


		/// <summary>
		/// The total number of pages.
		/// </summary>
		public int TotalPages
		{
			get
			{
				return _totalPages;
			}
		}


		/// <summary>
		/// The total number of records to account for.
		/// </summary>
		public int RecordCount
		{
			get
			{
				return _recordCount;
			}
			set
			{
				_recordCount = value;
				this.RecalculateStats();
			}
		}


		/// <summary>
		/// The name of the album.
		/// </summary>
		public string AlbumName
		{
			get
			{
				return _albumName;
			}
			set
			{
				_albumName = value;
			}
		}


		/// <summary>
		/// The total number of pictures in the gallery. Only applicable for the album list nav.
		/// </summary>
		public int PictureCount
		{
			get
			{
				return _pictureCount;
			}
			set
			{
				_pictureCount = value;
			}
		}


		/// <summary>
		/// The title of the current picture, when in picture details.
		/// </summary>
		public string PictureTitle
		{
			get
			{
				return _pictureTitle;
			}
			set
			{
				_pictureTitle = value;
			}
		}


		/// <summary>
		/// The ID of the album you're currently in. Only applicable for picture details.
		/// </summary>
		public int AlbumID
		{
			get
			{
				return _albumID;
			}
			set
			{
				_albumID = value;
			}
		}


		#endregion


		#region Private Methods


		private void RecalculateStats()
		{
			int recordsPerPage = nGallery.Lib.Configuration.Instance().AlbumListRecordsPerPage;


			if (recordsPerPage != 0)
			{
				_totalPages = (_recordCount / recordsPerPage);
				_totalPages = ((_recordCount % recordsPerPage) != 0 ? _totalPages + 1 : _totalPages);
				_totalPages = (_totalPages == 0 ? 1 : _totalPages);


				if ((_recordCount - (_currentPage * recordsPerPage)) > 0)
				{
					_nextPage = _currentPage + 1;
				}

				if (_currentPage != 1)
				{
					_previousPage = _currentPage - 1;
				}
			}

		}


		#endregion


		#region Protected Methods


		/// <summary>
		/// Renders out the control
		/// </summary>
		/// <param name="writer">HtmlTextWriter</param>
		protected override void Render(HtmlTextWriter writer)
		{
			Template htmlTemplate;
			string basePage;
			string nextPageURL;
			string previousPageURL;
			StringBuilder parentAlbumLink = new StringBuilder();


			switch (_navType)
			{
				case Definitions.NavigationType.NAV_ALBUM_LIST:
					htmlTemplate = new Template(Definitions.Templates.T_ALBUM_LISTING_NAV, this.Page);
					basePage = "default.aspx";
					break;
				case Definitions.NavigationType.NAV_PICTURE_LIST:
					htmlTemplate = new Template(Definitions.Templates.T_PICTURE_LISTING_NAV, this.Page);
					basePage = "albumListing.aspx";
					break;
				case Definitions.NavigationType.NAV_PICTURE_DETAILS:
					htmlTemplate = new Template(Definitions.Templates.T_PICTURE_DETAILS_NAV, this.Page);
					basePage = "";
					break;
				default:
					htmlTemplate = new Template(Definitions.Templates.T_ALBUM_LISTING_NAV, this.Page);
					basePage = "default.aspx";
					break;
			}

			if (_nextPage != 0)
			{
				nextPageURL = basePage + "?page=" + _nextPage;

				if (_navType == Definitions.NavigationType.NAV_PICTURE_LIST)
				{
					nextPageURL += "&albumID=" + this.Page.Request["albumID"] + "&albumName=" + this.Page.Server.UrlEncode(_albumName);
				}
			}
			else
			{
				nextPageURL = "#";
			}

			if (_previousPage != 0)
			{
				previousPageURL = basePage + "?page=" + _previousPage;

				if (_navType == Definitions.NavigationType.NAV_PICTURE_LIST)
				{
					previousPageURL += "&albumID=" + this.Page.Request["albumID"] + "&albumName=" + this.Page.Server.UrlEncode(_albumName);

				}
			}
			else
			{
				previousPageURL = "#";
			}

			// Template variable replacements
			if (_navType == Definitions.NavigationType.NAV_ALBUM_LIST)
			{
				htmlTemplate.ProcessesVariable(Definitions.TemplateVariables.Albums.T_CURRENT_PAGE,	_currentPage.ToString());
				htmlTemplate.ProcessesVariable(Definitions.TemplateVariables.Albums.T_TOTAL_PAGES,	_totalPages.ToString());
				htmlTemplate.ProcessesVariable(Definitions.TemplateVariables.Albums.T_NEXT_PAGE,	nextPageURL);
				htmlTemplate.ProcessesVariable(Definitions.TemplateVariables.Albums.T_PREVIOUS_PAGE,previousPageURL);
				htmlTemplate.ProcessesVariable(Definitions.TemplateVariables.Albums.T_ALBUM_COUNT,	_recordCount.ToString());
				htmlTemplate.ProcessesVariable(Definitions.TemplateVariables.Albums.T_TOTAL_PICTURE_COUNT, _pictureCount.ToString());
			}
			else if (_navType == Definitions.NavigationType.NAV_PICTURE_LIST)
			{
				if (_parentAlbumID != 0 && _parentAlbumName != null && _parentAlbumName != "")
				{
					if (Configuration.Instance().AlbumRewriting == RewriteType.ById)
					{
						parentAlbumLink.Append("<b>Parent Album:</b> <a href=\"" + _parentAlbumID + ".aspx\">");
					}
					else if (Configuration.Instance().AlbumRewriting == RewriteType.ByName)
					{
						parentAlbumLink.Append("<b>Parent Album:</b> <a href=\"" + this.Page.Server.UrlEncode(_parentAlbumName) + ".aspx\">");
					}
					parentAlbumLink.Append(_parentAlbumName);
					parentAlbumLink.Append("</a>&nbsp;&nbsp;&nbsp;");
				}

				htmlTemplate.ProcessesVariable(Definitions.TemplateVariables.Pictures.T_CURRENT_PAGE,		_currentPage.ToString());
				htmlTemplate.ProcessesVariable(Definitions.TemplateVariables.Pictures.T_TOTAL_PAGES,		_totalPages.ToString());
				htmlTemplate.ProcessesVariable(Definitions.TemplateVariables.Pictures.T_NEXT_PAGE,			nextPageURL);
				htmlTemplate.ProcessesVariable(Definitions.TemplateVariables.Pictures.T_PREVIOUS_PAGE,		previousPageURL);
				htmlTemplate.ProcessesVariable(Definitions.TemplateVariables.Pictures.T_PICTURE_ALBUM_NAME,	_albumName);
				htmlTemplate.ProcessesVariable(Definitions.TemplateVariables.Albums.T_ALBUM_COUNT,			_recordCount.ToString());
				htmlTemplate.ProcessesVariable(Definitions.TemplateVariables.Pictures.T_PICTURE_COUNT,		_pictureCount.ToString());
				htmlTemplate.ProcessesVariable(Definitions.TemplateVariables.Pictures.T_PARENT_ALBUM_LINK,	parentAlbumLink.ToString());
			}
			else if (_navType == Definitions.NavigationType.NAV_PICTURE_DETAILS)
			{
				string albumURL = "";


				if (Configuration.Instance().AlbumRewriting == RewriteType.ById)
				{
					albumURL = "../" + _albumID + ".aspx";
				}
				else if (Configuration.Instance().AlbumRewriting == RewriteType.ByName)
				{
					albumURL = "../" + this.Page.Server.UrlEncode(_albumName) + ".aspx";
				}

				htmlTemplate.ProcessesVariable(Definitions.TemplateVariables.Pictures.T_PICTURE_ALBUM_NAME,	_albumName);
				htmlTemplate.ProcessesVariable(Definitions.TemplateVariables.Albums.T_ALBUM_ID,				_albumID.ToString());
				htmlTemplate.ProcessesVariable(Definitions.TemplateVariables.Pictures.T_PICTURE_TITLE,		_pictureTitle);
				htmlTemplate.ProcessesVariable(Definitions.TemplateVariables.Albums.T_ALBUM_URL,			albumURL);
			}


			writer.WriteLine(htmlTemplate.GetString());

		}


		#endregion



	}


}
