#region Copyright and License
/*
Copyright 2003 Jason Alexander, nGallery.org
Design work copyright Thomas Johansen (http://www.aylarsolutions.com/)

GOTDOTNET WORKSPACES COMMERCIAL DERIVATIVES LICENSE
Copyright (C) 2003 Microsoft Corporation

You can use this Software for any commercial or noncommercial purpose, 
including distributing derivative works.

In return, we simply require that you agree:

1. Not to remove any copyright notices from the Software. 
2. That if you distribute the Software in source code form you do so only 
   under this License (i.e. you must include a complete copy of this License 
   with your distribution), and if you distribute the Software solely in 
   object form you only do so under a license that complies with this License. 
3. That the Software comes "as is", with no warranties. None whatsoever. This 
   means no express, implied or statutory warranty, including without 
   limitation, warranties of merchantability or fitness for a particular 
   purpose or any warranty of noninfringement. Also, you must pass this 
   disclaimer on whenever you distribute the Software.
4. That neither Microsoft nor any contributor to the Software will be liable 
   for any of those types of damages known as indirect, special, consequential, 
   or incidental related to the Software or this License, to the maximum extent 
   the law permits, no matter what legal theory it�s based on. Also, you must 
   pass this limitation of liability on whenever you distribute the Software.
5. That if you sue anyone over patents that you think may apply to the 
   Software for a person's use of the Software, your license to the Software 
   ends automatically. 
6. That the patent rights, if any, licensed hereunder only apply to the 
   Software, not to any derivative works you make. 
7. That your rights under this License end automatically if you breach it in 
   any way.
*/
#endregion
using System;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.ComponentModel;
using System.Configuration;

namespace nGallery.Lib
{
	/// <summary>
	/// This control handles all aspects of the slideshow functionality in nGallery, including
	/// building all the Javascript image swapping arrays and functions, as well as all supporting
	/// HTML. This control is truly self contained.
	/// </summary>
	public class ControlSlideShow : System.Web.UI.Control
	{


		#region Private Members


		private int _albumID;
		private PictureCollection _pictures;
		private Album _album;


		#endregion


		#region Public Properties


		/// <summary>
		/// The ID of the album to display.
		/// </summary>
		public int AlbumID
		{
			get
			{
				return _albumID;
			}
			set
			{
				_albumID = value;
			}
		}


		#endregion


		#region Overrides


		/// <summary>
		/// Create any child controls necessary for this control.
		/// </summary>
		protected override void CreateChildControls()
		{
			BL galleryBL = new BL(this.Page.Server.MapPath(nGallery.Lib.Configuration.Instance().DataDirectory), this.Page.Server.MapPath(nGallery.Lib.Configuration.Instance().PhotosDirectory));
			StringBuilder js = new StringBuilder();			


			// Retrieve the album, as well.
			_album = galleryBL.GetAlbum(_albumID);

			// Retrieve all the pictures for the given album ID.
			_pictures = galleryBL.GetAlbumPictures(_albumID);

			// Start building the javascript.
			js.Append("<script language=\"javascript\" type=\"text/javascript\">" + Environment.NewLine);
			js.Append("var slideShowDelay = " + nGallery.Lib.Configuration.Instance().SlideShowDelay + ";" + Environment.NewLine);
			js.Append("var maxPictureCount = " + _pictures.Count + ";" + Environment.NewLine);
			js.Append("var currentPictureIndex = -1;" + Environment.NewLine);
			js.Append("var continueSlideShow = true;" + Environment.NewLine);
			js.Append("var asImages = new Array(" + _pictures.Count + ");" + Environment.NewLine);
			js.Append(Environment.NewLine);
			js.Append(Environment.NewLine);
			
			// Loop through the pictures building the client side array.
			for (int i = 0; i < _pictures.Count; i++)
			{
				PhotoCache pictureCache = galleryBL.CreatePhotoCache(_albumID, _pictures[i].ID);
				js.Append("asImages[" + i + "] = '" + pictureCache.GetSlideShow() + "';" + Environment.NewLine);
			}

			js.Append(Environment.NewLine);
			js.Append(Environment.NewLine);
			js.Append("setTimeout('PlaySlideShow()', 1000);");
			js.Append(Environment.NewLine);
			js.Append(Environment.NewLine);

			// Function: StopSlideShow()
			js.Append("function StopSlideShow()" + Environment.NewLine);
			js.Append("{" + Environment.NewLine);
			js.Append("    document.getElementById('imgPlay').src = 'photos/play_off.gif';" + Environment.NewLine);
			js.Append("    document.getElementById('imgStop').src = 'photos/stop_on.gif';" + Environment.NewLine);
			js.Append("    continueSlideShow = false;" + Environment.NewLine);
			js.Append("}" + Environment.NewLine);
			js.Append(Environment.NewLine);
			js.Append(Environment.NewLine);

			// Function: PlaySlideShow()
			js.Append("function PlaySlideShow()" + Environment.NewLine);
			js.Append("{" + Environment.NewLine);
			js.Append("    document.getElementById('imgStop').src = 'photos/stop_off.gif';" + Environment.NewLine);
			js.Append("    document.getElementById('imgPlay').src = 'photos/play_on.gif';" + Environment.NewLine);
			js.Append("    continueSlideShow = true;" + Environment.NewLine);
			js.Append("    setTimeout('ChangeSlide()', slideShowDelay);" + Environment.NewLine);
			js.Append("}" + Environment.NewLine);
			js.Append(Environment.NewLine);
			js.Append(Environment.NewLine);

			// Function: ChangeSlide()
			js.Append("function ChangeSlide()" + Environment.NewLine);
			js.Append("{" + Environment.NewLine);
			js.Append("    if (!continueSlideShow) return;" + Environment.NewLine);
			js.Append(Environment.NewLine);
			js.Append("    NextImage();" + Environment.NewLine);
			js.Append("    setTimeout('ChangeSlide()', slideShowDelay);" + Environment.NewLine);
			js.Append("}" + Environment.NewLine);
			js.Append(Environment.NewLine);
			js.Append(Environment.NewLine);

			// Function: NextImage()
			js.Append("function NextImage()" + Environment.NewLine);
			js.Append("{" + Environment.NewLine);
			js.Append("    currentPictureIndex++;" + Environment.NewLine);
			js.Append(Environment.NewLine);
			js.Append("    if (currentPictureIndex >= maxPictureCount) currentPictureIndex = 0;" + Environment.NewLine);
			js.Append(Environment.NewLine);
			js.Append("    document.getElementsByName('divPictureInfo').innerHTML = 'Picture ' + (currentPictureIndex + 1) + ' of ' + maxPictureCount;" + Environment.NewLine);
			js.Append(Environment.NewLine);
			js.Append("    document.getElementById('imgSlideShow').src = asImages[currentPictureIndex];" + Environment.NewLine);
			js.Append(Environment.NewLine);
			js.Append("}" + Environment.NewLine);

			// Function: PrevImage()
			js.Append("function PrevImage()" + Environment.NewLine);
			js.Append("{" + Environment.NewLine);
			js.Append("    currentPictureIndex--;" + Environment.NewLine);
			js.Append(Environment.NewLine);
			js.Append("    if (currentPictureIndex < 0) currentPictureIndex = (maxPictureCount - 1);" + Environment.NewLine);
			js.Append(Environment.NewLine);
			js.Append("    document.getElementsByName('divPictureInfo').innerHTML = 'Picture ' + (currentPictureIndex + 1) + ' of ' + maxPictureCount;" + Environment.NewLine);
			js.Append(Environment.NewLine);
			js.Append("    document.getElementById('imgSlideShow').src = asImages[currentPictureIndex];" + Environment.NewLine);
			js.Append(Environment.NewLine);
			js.Append("}" + Environment.NewLine);
			js.Append(Environment.NewLine);
			js.Append(Environment.NewLine);

			// Function: SwitchNextImage()
			js.Append("function SwitchNextImage()" + Environment.NewLine);
			js.Append("{" + Environment.NewLine);
			js.Append("    StopSlideShow();" + Environment.NewLine);
			js.Append("    NextImage();" + Environment.NewLine);
			js.Append("}" + Environment.NewLine);
			js.Append(Environment.NewLine);
			js.Append(Environment.NewLine);

			// Function: SwitchPrevImage()
			js.Append("function SwitchPrevImage()" + Environment.NewLine);
			js.Append("{" + Environment.NewLine);
			js.Append("    StopSlideShow();" + Environment.NewLine);
			js.Append("    PrevImage();" + Environment.NewLine);
			js.Append("}" + Environment.NewLine);
			js.Append(Environment.NewLine);
			js.Append(Environment.NewLine);

			js.Append("</script>");

			this.Page.RegisterClientScriptBlock("ImageSwappingLogic", js.ToString());
		}

		/// <summary> 
		/// Render this control to the output parameter specified.
		/// </summary>
		/// <param name="output"> The HTML writer to write out to </param>
		protected override void Render(HtmlTextWriter output)
		{
			StringBuilder html = new StringBuilder();


			html.Append("<table border=\"0\" width=\"100%\">" + Environment.NewLine);
			html.Append("<tr>" + Environment.NewLine);
			html.Append("    <td align=\"center\" valign=\"middle\" width=\"50%\">" + Environment.NewLine);
			html.Append("        <img id=\"imgSlideShow\" src=\"photos/default_slideshow_image.jpg\" alt=\"Slideshow Picture\">");
			html.Append("    </td>" + Environment.NewLine);
			html.Append("    <td align=\"center\" valign=\"top\" width=\"50%\">" + Environment.NewLine);
			html.Append("        <span style=\"font-family: Arial; font-size: 10pt;\">" + Environment.NewLine);
			html.Append("        <b>" + nGallery.Lib.Configuration.Instance().SiteTitle + "</b><br>" + Environment.NewLine);
			html.Append("        " + _album.Name + "</span><br>" + Environment.NewLine);
			html.Append("        <br>" + Environment.NewLine);
			html.Append("        <div id=\"divPictureInfo\" name=\"divPictureInfo\" style=\"font-family: Arial; font-size: 10pt; font-weight: bolder;\"></div>" + Environment.NewLine);
			html.Append("        <br>" + Environment.NewLine);
			html.Append("        <img id=\"imgPlay\" src=\"photos/play_off.gif\" onclick=\"javascript: PlaySlideShow();\" alt=\"Play Slideshow\"><img id=\"imgStop\" src=\"photos/stop_off.gif\" onclick=\"javascript: StopSlideShow();\" alt=\"Stop Slideshow\"><img id=\"imgPrev\" src=\"photos/prev_off.gif\" onclick=\"javascript: SwitchPrevImage();\" alt=\"Previous Slide\"><img id=\"imgNext\" src=\"photos/next_off.gif\" onclick=\"javascript: SwitchNextImage();\" alt=\"Next Slide\">" + Environment.NewLine);
			html.Append("    </td>" + Environment.NewLine);
			html.Append("</tr>" + Environment.NewLine);
			html.Append("</table>" + Environment.NewLine);

			output.Write(html.ToString());

		}


		#endregion


	}
}
