#region Copyright and License
/*
Copyright 2003 Jason Alexander, nGallery.org
Design work copyright Thomas Johansen (http://www.aylarsolutions.com/)

GOTDOTNET WORKSPACES COMMERCIAL DERIVATIVES LICENSE
Copyright (C) 2003 Microsoft Corporation

You can use this Software for any commercial or noncommercial purpose, 
including distributing derivative works.

In return, we simply require that you agree:

1. Not to remove any copyright notices from the Software. 
2. That if you distribute the Software in source code form you do so only 
   under this License (i.e. you must include a complete copy of this License 
   with your distribution), and if you distribute the Software solely in 
   object form you only do so under a license that complies with this License. 
3. That the Software comes "as is", with no warranties. None whatsoever. This 
   means no express, implied or statutory warranty, including without 
   limitation, warranties of merchantability or fitness for a particular 
   purpose or any warranty of noninfringement. Also, you must pass this 
   disclaimer on whenever you distribute the Software.
4. That neither Microsoft nor any contributor to the Software will be liable 
   for any of those types of damages known as indirect, special, consequential, 
   or incidental related to the Software or this License, to the maximum extent 
   the law permits, no matter what legal theory it�s based on. Also, you must 
   pass this limitation of liability on whenever you distribute the Software.
5. That if you sue anyone over patents that you think may apply to the 
   Software for a person's use of the Software, your license to the Software 
   ends automatically. 
6. That the patent rights, if any, licensed hereunder only apply to the 
   Software, not to any derivative works you make. 
7. That your rights under this License end automatically if you breach it in 
   any way.
*/
#endregion
using System;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.ComponentModel;
using System.Configuration;

namespace nGallery.Lib
{
	/// <summary>
	/// This control is used when there are no items in a specific display.
	/// </summary>
	public class ControlNoItems : System.Web.UI.WebControls.WebControl
	{

		#region Private Members


		private Definitions.ListType _listType;

		
		#endregion


		#region Constructor


		/// <summary>
		/// Constructor for the no items display. 
		/// </summary>
		/// <param name="listType">The type of list that is trying to be displayed.</param>
		public ControlNoItems(Definitions.ListType listType)
		{
			_listType = listType;
		}


		#endregion


		/// <summary> 
		/// Render this control to the output parameter specified.
		/// </summary>
		/// <param name="output"> The HTML writer to write out to </param>
		protected override void Render(HtmlTextWriter output)
		{
			Template template = new Template();
			

			if (_listType == Definitions.ListType.ALBUM_LIST)
			{
				template = new Template(Definitions.Templates.T_ALBUM_LISTING_NO_ITEMS, this.Page);
			}
			else if (_listType == Definitions.ListType.PICTURE_LIST)
			{
				template = new Template(Definitions.Templates.T_PICTURE_LISTING_NO_ITEMS, this.Page);
			}
			else if (_listType == Definitions.ListType.SUBALBUM_LIST)
			{
				template = new Template(Definitions.Templates.T_SUBALBUM_LISTING_NO_ITEMS, this.Page);
			}
			else if (_listType == Definitions.ListType.COMMENT_LIST)
			{
				string commentType;
				string commentTypeTitle = "Unknown";


				commentType = nGallery.Lib.Configuration.Instance().CommentType;
				if (commentType == "Comment")
				{
					commentTypeTitle= "Comment";
				}
				else if (commentType == "Caption")
				{
					commentTypeTitle = "Caption";
				}

				template = new Template(Definitions.Templates.T_COMMENT_LISTING_NO_ITEMS, this.Page);

				template.ProcessesVariable(Definitions.TemplateVariables.Comments.T_COMMENT_TYPE_TITLE, commentTypeTitle);
				
			}


			output.Write(template.GetString());
		}

	}
}
