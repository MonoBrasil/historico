#region Copyright and License
/*
Copyright 2003 Jason Alexander, nGallery.org
Design work copyright Thomas Johansen (http://www.aylarsolutions.com/)

GOTDOTNET WORKSPACES COMMERCIAL DERIVATIVES LICENSE
Copyright (C) 2003 Microsoft Corporation

You can use this Software for any commercial or noncommercial purpose, 
including distributing derivative works.

In return, we simply require that you agree:

1. Not to remove any copyright notices from the Software. 
2. That if you distribute the Software in source code form you do so only 
   under this License (i.e. you must include a complete copy of this License 
   with your distribution), and if you distribute the Software solely in 
   object form you only do so under a license that complies with this License. 
3. That the Software comes "as is", with no warranties. None whatsoever. This 
   means no express, implied or statutory warranty, including without 
   limitation, warranties of merchantability or fitness for a particular 
   purpose or any warranty of noninfringement. Also, you must pass this 
   disclaimer on whenever you distribute the Software.
4. That neither Microsoft nor any contributor to the Software will be liable 
   for any of those types of damages known as indirect, special, consequential, 
   or incidental related to the Software or this License, to the maximum extent 
   the law permits, no matter what legal theory it�s based on. Also, you must 
   pass this limitation of liability on whenever you distribute the Software.
5. That if you sue anyone over patents that you think may apply to the 
   Software for a person's use of the Software, your license to the Software 
   ends automatically. 
6. That the patent rights, if any, licensed hereunder only apply to the 
   Software, not to any derivative works you make. 
7. That your rights under this License end automatically if you breach it in 
   any way.
*/
#endregion
using System;
using System.Text;


namespace nGallery.Lib
{
	/// <summary>
	/// This control is typically used in the ControlCommentListing control. This control is responsible
	/// for displaying one specific Comment object.
	/// </summary>
	public class ControlCommentItem : System.Web.UI.Control
	{


		#region Private Members


		private Comment _comment;


		#endregion


		#region Constructor(s)


		/// <summary>
		/// The main constructor for ControlCommentItem.
		/// </summary>
		public ControlCommentItem()
		{
			_comment = new Comment();
		}


		#endregion


		#region Public Properties


		/// <summary>
		/// The Comment object to be displayed.
		/// </summary>
		public Comment Comment
		{
			get
			{
				return _comment;
			}
			set
			{
				_comment = value;
			}
		}


		#endregion


		#region Protected Methods


		/// <summary>
		/// This method is responsible for rendering out the control.
		/// </summary>
		/// <param name="writer">The HtmlTextWriter to write the output to.</param>
		protected override void Render(System.Web.UI.HtmlTextWriter writer)
		{
			Template template = new Template(Definitions.Templates.T_COMMENT_ITEM, this.Page);
			string fromName;
			string commentText;
			string webURL;


			// If no from name is specified use "Anonymous".
			fromName = _comment.FromName;

			if (fromName == null || fromName.Trim() == "")
			{
				fromName = "Anonymous";
			}

			// Let's just be safe and strip all HTML from comment text.
			commentText = _comment.CommentText;

			if (commentText != null && commentText.Trim() != "")
			{
				commentText = Util.StripHTML(commentText);

				// And, let's respect carriage returns.
				commentText = commentText.Replace("\n", "<br>");
			}

			// Let's just make sure they have a "http://" in front of the address. If not, we'll add it on display.
			webURL = _comment.FromWebURL;

			if (webURL != null && webURL.Trim() != "")
			{
				if (webURL.Length >= 7)
				{
					if (webURL.Substring(0, 7) != "http://")
					{
						webURL = "http://" + webURL;
					}
				}
				else
				{
					webURL = "http://" + webURL;
				}
			}

			// Template Variable Replacements
			template.ProcessesVariable(Definitions.TemplateVariables.Comments.T_COMMENT_FROM_NAME,			fromName);
			template.ProcessesVariable(Definitions.TemplateVariables.Comments.T_COMMENT_FROM_EMAIL_ADDR,	_comment.FromEmailAddr);
			template.ProcessesVariable(Definitions.TemplateVariables.Comments.T_COMMENT_FROM_WEB_URL,		webURL);
			template.ProcessesVariable(Definitions.TemplateVariables.Comments.T_COMMENT_CREATE_DATE,		_comment.CreateDate.ToString());
			template.ProcessesVariable(Definitions.TemplateVariables.Comments.T_COMMENT_TEXT,				commentText);


			writer.Write(template.GetString());

		}


		#endregion


	}
}
