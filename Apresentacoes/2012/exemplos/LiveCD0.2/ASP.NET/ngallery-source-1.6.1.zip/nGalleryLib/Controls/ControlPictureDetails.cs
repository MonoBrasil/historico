#region Copyright and License
/*
Copyright 2003 Jason Alexander, nGallery.org
Design work copyright Thomas Johansen (http://www.aylarsolutions.com/)

GOTDOTNET WORKSPACES COMMERCIAL DERIVATIVES LICENSE
Copyright (C) 2003 Microsoft Corporation

You can use this Software for any commercial or noncommercial purpose, 
including distributing derivative works.

In return, we simply require that you agree:

1. Not to remove any copyright notices from the Software. 
2. That if you distribute the Software in source code form you do so only 
   under this License (i.e. you must include a complete copy of this License 
   with your distribution), and if you distribute the Software solely in 
   object form you only do so under a license that complies with this License. 
3. That the Software comes "as is", with no warranties. None whatsoever. This 
   means no express, implied or statutory warranty, including without 
   limitation, warranties of merchantability or fitness for a particular 
   purpose or any warranty of noninfringement. Also, you must pass this 
   disclaimer on whenever you distribute the Software.
4. That neither Microsoft nor any contributor to the Software will be liable 
   for any of those types of damages known as indirect, special, consequential, 
   or incidental related to the Software or this License, to the maximum extent 
   the law permits, no matter what legal theory it�s based on. Also, you must 
   pass this limitation of liability on whenever you distribute the Software.
5. That if you sue anyone over patents that you think may apply to the 
   Software for a person's use of the Software, your license to the Software 
   ends automatically. 
6. That the patent rights, if any, licensed hereunder only apply to the 
   Software, not to any derivative works you make. 
7. That your rights under this License end automatically if you breach it in 
   any way.
*/
#endregion
using System;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.ComponentModel;
using System.Drawing;

namespace nGallery.Lib
{
	/// <summary>
	/// This control is used to display the details of a Picture object. This control is used when clicking
	/// into a picture from the picture listing page.
	/// </summary>
	public class ControlPictureDetails : System.Web.UI.WebControls.WebControl
	{


		#region Private Members


		private BL		_galleryBL;
		private int		_albumID;
		private int		_prevPictureID;
		private int		_nextPictureID;
		private string	_albumName;
		private Picture _picture;



		#endregion
	

		#region Public Properties


		/// <summary>
		/// The ID of the album in which this picture resides.
		/// </summary>
		public int AlbumID
		{
			get
			{
				return _albumID;
			}
			set
			{
				_albumID = value;
			}
		}


		/// <summary>
		/// The ID of the previous picture in the "logical" order of the given album.
		/// </summary>
		public int PrevPictureID
		{
			get
			{
				return _prevPictureID;
			}
			set
			{
				_prevPictureID = value;
			}
		}


		/// <summary>
		/// The ID of the next picture in the "logical" order of the given album.
		/// </summary>
		public int NextPictureID
		{
			get
			{
				return _nextPictureID;
			}
			set
			{
				_nextPictureID = value;
			}
		}


		/// <summary>
		/// The name of the album in which this picture resides.
		/// </summary>
		public string AlbumName
		{
			get
			{
				return _albumName;
			}
			set
			{
				_albumName = value;
			}
		}


		/// <summary>
		/// The Picture object to be displayed.
		/// </summary>
		public Picture Picture
		{
			get
			{
				return _picture;
			}
			set
			{
				_picture = value;
			}
		}


		#endregion


		#region Protected Methods


		/// <summary> 
		/// Render this control to the output parameter specified.
		/// </summary>
		/// <param name="output"> The HTML writer to write out to </param>
		protected override void Render(HtmlTextWriter output)
		{
			Template template = new Template(Definitions.Templates.T_PICTURE_DETAILS, this.Page);
			string imageHTML;
			StringBuilder baseURL	= new StringBuilder();
			StringBuilder returnURL	= new StringBuilder();
			StringBuilder prevPicURL = new StringBuilder();
			StringBuilder nextPicURL = new StringBuilder();


			
			_galleryBL = new nGallery.Lib.BL(this.Page.Server.MapPath(nGallery.Lib.Configuration.Instance().DataDirectory), this.Page.Server.MapPath(nGallery.Lib.Configuration.Instance().PhotosDirectory));
			
			PhotoCache pictureCache = _galleryBL.CreatePhotoCache(_albumID, _picture.ID);

			// Build the image HTML.
			imageHTML = "<a href=\"" + pictureCache.GetOriginalPicture() + 
				"\" target=\"_blank\">" +
				"<img src=\"" + pictureCache.GetPictureDetails() +
				"\" border=\"0\" alt=\"Picture: " + _picture.Title + "\" width=\"" + pictureCache.Width + "\" height=\"" + pictureCache.Height + "\">" +
				"</a>";

			// Build the base URL.
			baseURL.Append("http://");
			baseURL.Append(this.Page.Request.ServerVariables["SERVER_NAME"]);
			baseURL.Append(this.Page.Request.ServerVariables["SERVER_PORT"] != "80" ? ":" + this.Page.Request.ServerVariables["SERVER_PORT"] : "");

			// Create the return URL.
			returnURL.Append(baseURL + this.Page.Request.ServerVariables["SCRIPT_NAME"].Replace("viewPicture.aspx", ""));

			// Create the previous picture URL.
			if (_prevPictureID != 0)
			{
				prevPicURL.Append("<a href=\"" + _prevPictureID + ".aspx\">");
				prevPicURL.Append("Previous Picture");
				prevPicURL.Append("</a>&nbsp;|");
			}
			else
			{
				if (nGallery.Lib.Configuration.Instance().PictureListPagingDisplayType == "disable")
				{
					prevPicURL.Append("Previous Picture&nbsp;|");
				}
				else if (nGallery.Lib.Configuration.Instance().PictureListPagingDisplayType == "disappear")
				{
					prevPicURL.Append("");
				}
				else
				{
					prevPicURL.Append("");
				}
			}

			// Create the next picture URL.
			if (_nextPictureID != 0)
			{
				nextPicURL.Append("<a href=\"" + _nextPictureID + ".aspx\">");
				nextPicURL.Append("Next Picture");
				nextPicURL.Append("</a>&nbsp;|");
			}
			else
			{
				if (nGallery.Lib.Configuration.Instance().PictureListPagingDisplayType == "disable")
				{
					nextPicURL.Append("Next Picture&nbsp;|");
				}
				else if (nGallery.Lib.Configuration.Instance().PictureListPagingDisplayType == "disappear")
				{
					nextPicURL.Append("");
				}
				else
				{
					nextPicURL.Append("");
				}
			}

			string photoUrl = baseURL.ToString() + pictureCache.GetOriginalPicture();
			string thumbUrl = baseURL.ToString() + pictureCache.GetThumbnail();
																							   

			// And, finally, we need to load up the Image object to get height and width.
			System.Drawing.Image photoImage = System.Drawing.Image.FromFile(this.Page.Server.MapPath(nGallery.Lib.Configuration.Instance().PhotosDirectory + _albumID + "/" + _picture.ID));

			// Do the template replacements.
			template.ProcessesVariable(Definitions.TemplateVariables.Pictures.T_PICTURE_ID,			_picture.ID.ToString());
			template.ProcessesVariable(Definitions.TemplateVariables.Pictures.T_PICTURE_FILE_NAME,	_picture.FileName);
			template.ProcessesVariable(Definitions.TemplateVariables.Pictures.T_PICTURE_ALBUM_ID,	_albumID.ToString());
			template.ProcessesVariable(Definitions.TemplateVariables.Pictures.T_PICTURE_ALBUM_NAME,	_albumName);
			template.ProcessesVariable(Definitions.TemplateVariables.Pictures.T_PICTURE_TITLE,		_picture.Title);
			template.ProcessesVariable(Definitions.TemplateVariables.Pictures.T_PICTURE_CREATE_DT,	_picture.CreateDate.ToString());
			template.ProcessesVariable(Definitions.TemplateVariables.Pictures.T_PICTURE_CAPTION,	_picture.Caption);
			template.ProcessesVariable(Definitions.TemplateVariables.Pictures.T_PICTURE_VIEW_COUNT,	_picture.ViewCount);
			template.ProcessesVariable(Definitions.TemplateVariables.Pictures.T_PICTURE_IMAGE,		imageHTML);
			template.ProcessesVariable(Definitions.TemplateVariables.Pictures.T_RETURN_URL,			this.Page.Server.UrlEncode(returnURL.ToString()));
			template.ProcessesVariable(Definitions.TemplateVariables.Pictures.T_PHOTO_URL,			photoUrl);
			template.ProcessesVariable(Definitions.TemplateVariables.Pictures.T_THUMBNAIL_URL,		thumbUrl);	
			template.ProcessesVariable(Definitions.TemplateVariables.Pictures.T_PREV_PICTURE_URL,	prevPicURL.ToString());
			template.ProcessesVariable(Definitions.TemplateVariables.Pictures.T_NEXT_PICTURE_URL,	nextPicURL.ToString());
			template.ProcessesVariable(Definitions.TemplateVariables.Pictures.T_PICTURE_HEIGHT,		photoImage.Height.ToString());
			template.ProcessesVariable(Definitions.TemplateVariables.Pictures.T_PICTURE_WIDTH,		photoImage.Width.ToString());



			// Write out the template.
			output.Write(template.GetString());
		}


		#endregion


	}
}
