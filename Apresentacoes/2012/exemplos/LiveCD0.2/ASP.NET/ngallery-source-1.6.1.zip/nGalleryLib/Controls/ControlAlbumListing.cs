#region Copyright and License
/*
Copyright 2003 Jason Alexander, nGallery.org
Design work copyright Thomas Johansen (http://www.aylarsolutions.com/)

GOTDOTNET WORKSPACES COMMERCIAL DERIVATIVES LICENSE
Copyright (C) 2003 Microsoft Corporation

You can use this Software for any commercial or noncommercial purpose, 
including distributing derivative works.

In return, we simply require that you agree:

1. Not to remove any copyright notices from the Software. 
2. That if you distribute the Software in source code form you do so only 
   under this License (i.e. you must include a complete copy of this License 
   with your distribution), and if you distribute the Software solely in 
   object form you only do so under a license that complies with this License. 
3. That the Software comes "as is", with no warranties. None whatsoever. This 
   means no express, implied or statutory warranty, including without 
   limitation, warranties of merchantability or fitness for a particular 
   purpose or any warranty of noninfringement. Also, you must pass this 
   disclaimer on whenever you distribute the Software.
4. That neither Microsoft nor any contributor to the Software will be liable 
   for any of those types of damages known as indirect, special, consequential, 
   or incidental related to the Software or this License, to the maximum extent 
   the law permits, no matter what legal theory it�s based on. Also, you must 
   pass this limitation of liability on whenever you distribute the Software.
5. That if you sue anyone over patents that you think may apply to the 
   Software for a person's use of the Software, your license to the Software 
   ends automatically. 
6. That the patent rights, if any, licensed hereunder only apply to the 
   Software, not to any derivative works you make. 
7. That your rights under this License end automatically if you breach it in 
   any way.
*/
#endregion
using System;
using System.Configuration;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.ComponentModel;

namespace nGallery.Lib
{
	/// <summary>
	/// This control is used to display a listing of AlbumCollection. This control does not do
	/// any output rendering, but sets up the control tree based on the collection passed in, and
	/// any paging parameters.
	/// </summary>
	public class ControlAlbumListing : System.Web.UI.Control
	{


		#region Private Members


		private System.Web.UI.WebControls.ListBox _ddSortOrder = new System.Web.UI.WebControls.ListBox();
		private Definitions.SortOrder _sortOrder = Definitions.SortOrder.DATE_DESCENDING;
		private AlbumCollection _albums;
		private int _pageNumber;
		private int _totalPages;
		private int _recordsPerPage;
		private int _startRecordRange;
		private int _endRecordRange;
		private StringBuilder _pagingNavigation;


		#endregion


		#region Constructor(s)


		/// <summary>
		/// The main constructor for the ControlAlbumListing control.
		/// </summary>
		public ControlAlbumListing()
		{
			_pagingNavigation = new StringBuilder();
		}


		#endregion


		#region Public Properties


		public Definitions.SortOrder SortOrder
		{
			get
			{
				return _sortOrder;
			}
			set
			{
				_sortOrder = value;
			}
		}


		/// <summary>
		/// The AlbumCollection to set up the display for.
		/// </summary>
		public AlbumCollection Albums
		{
			get
			{
				return _albums;
			}
			set
			{
				_albums = value;
			}
		}


		/// <summary>
		/// The current page number that this listing is to display.
		/// </summary>
		public int PageNumber
		{
			get
			{
				return _pageNumber;
			}
			set
			{
				_pageNumber = value;
				this.RecalculatePagingStats();
			}
		}


		/// <summary>
		/// The number of albums to displayed on each page.
		/// </summary>
		public int RecordsPerPage
		{
			get
			{
				return _recordsPerPage;
			}
			set
			{
				_recordsPerPage = value;
				this.RecalculatePagingStats();
			}
		}


		#endregion


		#region Public Overrides


		/// <summary>
		/// This method displays anything before the album listing.
		/// </summary>
		/// <param name="writer">The HtmlTextWriter to write to.</param>
		public void RenderBeginTag(HtmlTextWriter writer)
		{
			Template tagTemplate = new Template(Definitions.Templates.T_ALBUM_LISTING_BEGIN_TAG, this.Page);
			System.Text.StringBuilder controlText   = new System.Text.StringBuilder();
			System.IO.StringWriter stringWriter		= new System.IO.StringWriter(controlText);
			HtmlTextWriter htmlWriter				= new HtmlTextWriter(stringWriter);
			string sortOrderDD = "";

			
			// Render any controls to strings that are needed.
			_ddSortOrder.RenderControl(htmlWriter);
			sortOrderDD = controlText.ToString();
			controlText.Remove(0, controlText.Length);
			
			// Do any template replacements.
			tagTemplate.ProcessesVariable(Definitions.TemplateVariables.Albums.T_SORT_ORDER_DROP_DOWN, sortOrderDD);
			tagTemplate.ProcessesVariable(Definitions.TemplateVariables.Albums.T_CURRENT_PAGE, _pageNumber.ToString());
			tagTemplate.ProcessesVariable(Definitions.TemplateVariables.Albums.T_TOTAL_PAGES, _totalPages.ToString());
			tagTemplate.ProcessesVariable(Definitions.TemplateVariables.Albums.T_PAGING_NAVIGATION, _pagingNavigation.ToString());

			writer.Write(tagTemplate.GetString());
		}


		/// <summary>
		/// This method displays anything after the album listing.
		/// </summary>
		/// <param name="writer">The HtmlTextWriter to write to.</param>
		public void RenderEndTag(HtmlTextWriter writer)
		{
			Template tagTemplate = new Template(Definitions.Templates.T_ALBUM_LISTING_END_TAG, this.Page);


			// Do any template replacements.
			tagTemplate.ProcessesVariable(Definitions.TemplateVariables.Albums.T_CURRENT_PAGE, _pageNumber.ToString());
			tagTemplate.ProcessesVariable(Definitions.TemplateVariables.Albums.T_TOTAL_PAGES, _totalPages.ToString());
			tagTemplate.ProcessesVariable(Definitions.TemplateVariables.Albums.T_PAGING_NAVIGATION, _pagingNavigation.ToString());

			writer.WriteLine(tagTemplate.GetString());
		}


		protected override void Render(HtmlTextWriter writer)
		{
			StringBuilder outputHTML = new StringBuilder();
			System.Text.StringBuilder controlText   = new System.Text.StringBuilder();
			System.IO.StringWriter stringWriter		= new System.IO.StringWriter(controlText);
			HtmlTextWriter htmlWriter				= new HtmlTextWriter(stringWriter);


			// Render the begin tag.
			this.RenderBeginTag(htmlWriter);
			outputHTML.Append(controlText.ToString());
			controlText.Remove(0, controlText.Length);

			for (int i = 0; i < this.Controls.Count; i++)
			{
				if (this.Controls[i] as ControlAlbumItem != null)
				{
					this.Controls[i].RenderControl(htmlWriter);
					outputHTML.Append(controlText.ToString());
					controlText.Remove(0, controlText.Length);
				}
			}


			// Render the end tag.
			this.RenderEndTag(htmlWriter);
			outputHTML.Append(controlText.ToString());
			controlText.Remove(0, controlText.Length);

			writer.WriteLine(outputHTML.ToString());

		}

		#endregion


		#region Private Methods


		private void RecalculatePagingStats()
		{
			int recordCount = 0;


			recordCount = _albums.Count;

			// The starting record range.
			_startRecordRange	= (_pageNumber - 1) * _recordsPerPage;

			// The ending record range.
			_endRecordRange		= _startRecordRange + (_recordsPerPage - 1);
			_endRecordRange		= (_endRecordRange > (recordCount - 1) ? (recordCount - 1) : _endRecordRange);

			if (_recordsPerPage != 0)
			{
				_totalPages = (recordCount / _recordsPerPage);
				_totalPages = ((recordCount % _recordsPerPage) != 0 ? _totalPages + 1 : _totalPages);
				_totalPages = (_totalPages == 0 ? 1 : _totalPages);
			}

			_pagingNavigation = new StringBuilder();
			_pagingNavigation.Append("Page(s):&nbsp;&nbsp;");
			for (int i = 1; i <= _totalPages; i++)
			{
				if (i == _pageNumber)
				{
					_pagingNavigation.Append("<span class=\"currentPageHighlight\">" + i + "</span>&nbsp;&nbsp;");
				}
				else
				{
					_pagingNavigation.Append("<a href=\"default.aspx?so=" + ((int) _sortOrder).ToString() + "&page=" + i + "\">" + i + "</a>&nbsp;&nbsp;");
				}
			}

		}


		#endregion


		#region Protected Overrides


		/// <summary>
		/// This method sets up the control tree for this control, taking into account the paging parameters,
		/// if applicable.
		/// </summary>
		protected override void CreateChildControls()
		{
			
			if (_albums.Count == 0)
			{
				ControlNoItems noItems = new ControlNoItems(Definitions.ListType.ALBUM_LIST);

				this.Controls.Add(noItems);
			}
			else
			{

				// Configure the sort by drop down.
				ListItem liDateDesc = new ListItem("Date (Descending)", ((int) Definitions.SortOrder.DATE_DESCENDING).ToString());
				ListItem liDateAsc	= new ListItem("Date (Ascending)", ((int) Definitions.SortOrder.DATE_ASCENDING).ToString());
				ListItem liNameDesc = new ListItem("Name (Descending)", ((int) Definitions.SortOrder.NAME_DESCENDING).ToString());
				ListItem liNameAsc	= new ListItem("Name (Ascending)", ((int) Definitions.SortOrder.NAME_ASCENDING).ToString());

				if (!this.Page.IsPostBack)
				{
					liDateDesc.Selected	= (_sortOrder == Definitions.SortOrder.DATE_DESCENDING ? true : false);
					liDateAsc.Selected	= (_sortOrder == Definitions.SortOrder.DATE_ASCENDING ? true : false);
					liNameDesc.Selected = (_sortOrder == Definitions.SortOrder.NAME_DESCENDING ? true : false);
					liNameAsc.Selected	= (_sortOrder == Definitions.SortOrder.NAME_ASCENDING ? true : false);
				}

				_ddSortOrder.ID						= "ddSortOrder";
				_ddSortOrder.CssClass				= "sortOrder";
				_ddSortOrder.Attributes.Add("onChange", "javascript: DoSortOrder();");
				_ddSortOrder.Rows = 1;

				_ddSortOrder.Items.Add(liDateDesc);
				_ddSortOrder.Items.Add(liDateAsc);
				_ddSortOrder.Items.Add(liNameDesc);
				_ddSortOrder.Items.Add(liNameAsc);

				this.Controls.Add(_ddSortOrder);	

				// Handle the album sorting.
				_albums.Sort(new GenericSorter(_sortOrder));

				if (_albums.Count == 0)
				{
					for (int i = 0; i < this.Controls.Count; i++)
					{
						ControlNoItems noItems = new ControlNoItems(Definitions.ListType.ALBUM_LIST);

						this.Controls.Add(noItems);
					}
				}
				else
				{
					if (_pageNumber == 0 || _recordsPerPage == 0)
					{
						foreach (Album currentAlbum in _albums)
						{
							ControlAlbumItem albumItem = new ControlAlbumItem();

							albumItem.Album = currentAlbum;

							this.Controls.Add(albumItem);
						}
					}
					else
					{

						for (int i = _startRecordRange; i <= _endRecordRange; i++)
						{
							ControlAlbumItem albumItem = new ControlAlbumItem();

							albumItem.Album = _albums[i];

							this.Controls.Add(albumItem);
						}

					}

				}
				

			}
			
			
		}


		#endregion

	}
}
