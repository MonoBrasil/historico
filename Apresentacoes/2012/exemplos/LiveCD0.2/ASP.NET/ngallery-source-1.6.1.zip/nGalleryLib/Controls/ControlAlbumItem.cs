#region Copyright and License
/*
Copyright 2003 Jason Alexander, nGallery.org
Design work copyright Thomas Johansen (http://www.aylarsolutions.com/)

GOTDOTNET WORKSPACES COMMERCIAL DERIVATIVES LICENSE
Copyright (C) 2003 Microsoft Corporation

You can use this Software for any commercial or noncommercial purpose, 
including distributing derivative works.

In return, we simply require that you agree:

1. Not to remove any copyright notices from the Software. 
2. That if you distribute the Software in source code form you do so only 
   under this License (i.e. you must include a complete copy of this License 
   with your distribution), and if you distribute the Software solely in 
   object form you only do so under a license that complies with this License. 
3. That the Software comes "as is", with no warranties. None whatsoever. This 
   means no express, implied or statutory warranty, including without 
   limitation, warranties of merchantability or fitness for a particular 
   purpose or any warranty of noninfringement. Also, you must pass this 
   disclaimer on whenever you distribute the Software.
4. That neither Microsoft nor any contributor to the Software will be liable 
   for any of those types of damages known as indirect, special, consequential, 
   or incidental related to the Software or this License, to the maximum extent 
   the law permits, no matter what legal theory it�s based on. Also, you must 
   pass this limitation of liability on whenever you distribute the Software.
5. That if you sue anyone over patents that you think may apply to the 
   Software for a person's use of the Software, your license to the Software 
   ends automatically. 
6. That the patent rights, if any, licensed hereunder only apply to the 
   Software, not to any derivative works you make. 
7. That your rights under this License end automatically if you breach it in 
   any way.
*/
#endregion
using System;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.ComponentModel;
using System.Configuration;


namespace nGallery.Lib
{
	/// <summary>
	/// Summary description for ControlAlbumItem.
	/// </summary>
	public class ControlAlbumItem : System.Web.UI.WebControls.WebControl
	{

		#region Private Members


		private Album _album;
		private BL _galleryBL;


		#endregion


		#region Public Properties


		/// <summary>
		/// The specific album that this control should display.
		/// </summary>
		public Album Album
		{
			get
			{
				return _album;
			}
			set
			{
				_album = value;
			}
		}


		#endregion


		#region Render Override


		/// <summary> 
		/// Render this control to the output parameter specified.
		/// </summary>
		/// <param name="output"> The HTML writer to write out to </param>
		protected override void Render(HtmlTextWriter output)
		{
			Template htmlTemplate = new Template(Definitions.Templates.T_ALBUM_ITEM, this.Page);
			string highlightedPictureImage;
			string albumDesc;
			PhotoCache pictureCache;
			int totalPictureCount;
			string albumURL = "";


			_galleryBL = new BL(this.Page.Server.MapPath(nGallery.Lib.Configuration.Instance().DataDirectory), this.Page.Server.MapPath(nGallery.Lib.Configuration.Instance().PhotosDirectory));

			if(_album.HighlightedPicture != null)
				pictureCache = _galleryBL.CreatePhotoCache(_album.ID, _album.HighlightedPicture.ID);
			else
				pictureCache = _galleryBL.CreatePhotoCache(_album.ID, 0);

			highlightedPictureImage = "<img src=\"" + pictureCache.GetFolderPicture() + "\" border=\"0\" alt=\"Album: " + _album.Name + "\" width=\"" + pictureCache.Width + "\" height=\"" + pictureCache.Height + "\">";

			// Determine if we need to truncate the album description.
			if (_album.Description.Length > nGallery.Lib.Configuration.Instance().AlbumListDescLength)
			{
				albumDesc = _album.Description.Substring(0, nGallery.Lib.Configuration.Instance().AlbumListDescLength) + "...";
			}
			else
			{
				albumDesc = _album.Description;
			}
			
			albumDesc = Util.StripHTML(albumDesc);

			// Now, build the album URL respective to the configuration.
			if (Configuration.Instance().AlbumRewriting == RewriteType.ById)
			{
				albumURL = "albums/" + _album.ID + ".aspx";
			}
			else if (Configuration.Instance().AlbumRewriting == RewriteType.ByName)
			{
				albumURL = "albums/" + this.Page.Server.UrlEncode(_album.Name) + ".aspx";
			}

			totalPictureCount = _galleryBL.GetTotalPictureCount(_album.ID);

			// Do any template replacements.
			htmlTemplate.ProcessesVariable(Definitions.TemplateVariables.Albums.T_ALBUM_URL,			albumURL);
			htmlTemplate.ProcessesVariable(Definitions.TemplateVariables.Albums.T_ALBUM_ID,				_album.ID);
			htmlTemplate.ProcessesVariable(Definitions.TemplateVariables.Albums.T_ALBUM_NAME,			_album.Name);
			htmlTemplate.ProcessesVariable(Definitions.TemplateVariables.Albums.T_ALBUM_DESC,			albumDesc);
			htmlTemplate.ProcessesVariable(Definitions.TemplateVariables.Albums.T_ALBUM_CREATE_DT,		_album.CreateDate.ToString());
			htmlTemplate.ProcessesVariable(Definitions.TemplateVariables.Albums.T_ALBUM_HIGHLIGHT_IMAGE, highlightedPictureImage);
			htmlTemplate.ProcessesVariable(Definitions.TemplateVariables.Albums.T_ALBUM_PICTURE_COUNT,	_album.Pictures.Count);
			htmlTemplate.ProcessesVariable(Definitions.TemplateVariables.Albums.T_GRAND_TOTAL_PICTURE_COUNT, totalPictureCount.ToString());



			// Write out the template
			output.Write(htmlTemplate.GetString());

		}


		#endregion


	}
}
