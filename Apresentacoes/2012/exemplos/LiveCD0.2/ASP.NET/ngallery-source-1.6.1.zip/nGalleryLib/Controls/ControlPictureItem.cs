#region Copyright and License
/*
Copyright 2003 Jason Alexander, nGallery.org
Design work copyright Thomas Johansen (http://www.aylarsolutions.com/)

GOTDOTNET WORKSPACES COMMERCIAL DERIVATIVES LICENSE
Copyright (C) 2003 Microsoft Corporation

You can use this Software for any commercial or noncommercial purpose, 
including distributing derivative works.

In return, we simply require that you agree:

1. Not to remove any copyright notices from the Software. 
2. That if you distribute the Software in source code form you do so only 
   under this License (i.e. you must include a complete copy of this License 
   with your distribution), and if you distribute the Software solely in 
   object form you only do so under a license that complies with this License. 
3. That the Software comes "as is", with no warranties. None whatsoever. This 
   means no express, implied or statutory warranty, including without 
   limitation, warranties of merchantability or fitness for a particular 
   purpose or any warranty of noninfringement. Also, you must pass this 
   disclaimer on whenever you distribute the Software.
4. That neither Microsoft nor any contributor to the Software will be liable 
   for any of those types of damages known as indirect, special, consequential, 
   or incidental related to the Software or this License, to the maximum extent 
   the law permits, no matter what legal theory it�s based on. Also, you must 
   pass this limitation of liability on whenever you distribute the Software.
5. That if you sue anyone over patents that you think may apply to the 
   Software for a person's use of the Software, your license to the Software 
   ends automatically. 
6. That the patent rights, if any, licensed hereunder only apply to the 
   Software, not to any derivative works you make. 
7. That your rights under this License end automatically if you breach it in 
   any way.
*/
#endregion
using System;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.ComponentModel;
using System.Configuration;


namespace nGallery.Lib
{
	/// <summary>
	/// Summary description for ControlPhotoItem.
	/// </summary>
	public class ControlPictureItem : System.Web.UI.WebControls.WebControl
	{


		#region Private Members


		private Picture		_picture;
		private PhotoCache	_pictureCache;
		private int			_albumID;
		private string		_albumName;


		#endregion


		#region Public Properties


		/// <summary>
		/// The Picture object to display.
		/// </summary>
		public Picture Picture
		{
			get
			{
				return _picture;
			}
			set
			{
				_picture = value;
			}
		}


		/// <summary>
		/// The PhotoCache object to scale the image to be displayed.
		/// </summary>
		public PhotoCache PictureCache
		{
			get
			{
				return _pictureCache;
			}
			set
			{
				_pictureCache = value;
			}
		}


		/// <summary>
		/// The ID of the album in which this picture resides.
		/// </summary>
		public int AlbumID
		{
			get
			{
				return _albumID;
			}
			set
			{
				_albumID = value;
			}
		}


		/// <summary>
		/// The name of the album in which this picture resides.
		/// </summary>
		public string AlbumName
		{
			get
			{
				return _albumName;
			}
			set
			{
				_albumName = value;
			}
		}


		#endregion


		#region Protected Methods


		/// <summary>
		/// This method handles how to render out what a picture looks like in nGallery. Currently, it simply
		/// loads up an HTML template, and does any replacements necessary.
		/// </summary>
		/// <param name="writer">The HtmlTextWriter to write the finished output to.</param>
		protected override void Render(HtmlTextWriter writer)
		{
			Template template	= new Template(Definitions.Templates.T_PICTURE_ITEM, this.Page);
			string imageHTML;
			string pictureURL = "";


			// Build the image thumbnail HTML.
			imageHTML = "<img src=\"" + _pictureCache.GetThumbnail() + "\" border=\"0\" alt=\"Picture: " + _picture.Title + "\" width=\"" + _pictureCache.Width + "\" height=\"" + _pictureCache.Height + "\">";

			if (Configuration.Instance().AlbumRewriting == RewriteType.ById)
			{
				pictureURL = _albumID + "/" + _picture.ID + ".aspx";
			}
			else if (Configuration.Instance().AlbumRewriting == RewriteType.ByName)
			{
				pictureURL = this.Page.Server.UrlEncode(_albumName) + "/" + _picture.ID + ".aspx";
			}

			// Do the template variable replacements
			template.ProcessesVariable(Definitions.TemplateVariables.Albums.T_ALBUM_NAME,			_albumName);
			template.ProcessesVariable(Definitions.TemplateVariables.Pictures.T_PICTURE_ALBUM_ID,	_albumID.ToString());
			template.ProcessesVariable(Definitions.TemplateVariables.Pictures.T_PICTURE_ID,			_picture.ID.ToString());
			template.ProcessesVariable(Definitions.TemplateVariables.Pictures.T_PICTURE_FILE_NAME,	_picture.FileName);
			template.ProcessesVariable(Definitions.TemplateVariables.Pictures.T_PICTURE_CREATE_DT,	_picture.CreateDate.ToString());
			template.ProcessesVariable(Definitions.TemplateVariables.Pictures.T_PICTURE_TITLE,		_picture.Title);
			template.ProcessesVariable(Definitions.TemplateVariables.Pictures.T_PICTURE_CAPTION,	_picture.Caption);
			template.ProcessesVariable(Definitions.TemplateVariables.Pictures.T_PICTURE_VIEW_COUNT,	_picture.ViewCount);
			template.ProcessesVariable(Definitions.TemplateVariables.Pictures.T_PICTURE_THUMBNAIL,	imageHTML);
			template.ProcessesVariable(Definitions.TemplateVariables.Pictures.T_PICTURE_URL,		pictureURL);
			template.ProcessesVariable(Definitions.TemplateVariables.Pictures.T_PICTURE_VIEW_COUNT, _picture.ViewCount);
			

			// Write out the templates.
			writer.Write(template.GetString());

		}


		#endregion


	}
}
