#region Copyright and License
/*
Copyright 2003 Jason Alexander, nGallery.org
Design work copyright Thomas Johansen (http://www.aylarsolutions.com/)

GOTDOTNET WORKSPACES COMMERCIAL DERIVATIVES LICENSE
Copyright (C) 2003 Microsoft Corporation

You can use this Software for any commercial or noncommercial purpose, 
including distributing derivative works.

In return, we simply require that you agree:

1. Not to remove any copyright notices from the Software. 
2. That if you distribute the Software in source code form you do so only 
   under this License (i.e. you must include a complete copy of this License 
   with your distribution), and if you distribute the Software solely in 
   object form you only do so under a license that complies with this License. 
3. That the Software comes "as is", with no warranties. None whatsoever. This 
   means no express, implied or statutory warranty, including without 
   limitation, warranties of merchantability or fitness for a particular 
   purpose or any warranty of noninfringement. Also, you must pass this 
   disclaimer on whenever you distribute the Software.
4. That neither Microsoft nor any contributor to the Software will be liable 
   for any of those types of damages known as indirect, special, consequential, 
   or incidental related to the Software or this License, to the maximum extent 
   the law permits, no matter what legal theory it�s based on. Also, you must 
   pass this limitation of liability on whenever you distribute the Software.
5. That if you sue anyone over patents that you think may apply to the 
   Software for a person's use of the Software, your license to the Software 
   ends automatically. 
6. That the patent rights, if any, licensed hereunder only apply to the 
   Software, not to any derivative works you make. 
7. That your rights under this License end automatically if you breach it in 
   any way.
*/
#endregion
using System;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.ComponentModel;
using System.Configuration;

namespace nGallery.Lib
{

	
	/// <summary>
	/// This control is used to display the basic listing of a PictureCollection.
	/// </summary>
	public class ControlPictureListing : System.Web.UI.WebControls.WebControl
	{


		#region Private Members


		private BL _galleryBL;
		private int _prevAlbumID;
		private int _nextAlbumID;
		private string _prevAlbumName;
		private string _nextAlbumName;
		private Album _album;
		private AlbumCollection _subAlbums;
		private PictureCollection _pictures;
		private int _pageNumber;
		private int _totalPages;
		private int _recordsPerPage;
		private int _columnsPerPage;
		private int _startRecordRange;
		private int _endRecordRange;
		private int _albumID;
		private string _albumName;
		private StringBuilder _pagingNavigation;
		private ControlSubAlbumListing _subAlbumListing;


		#endregion


		#region Constructor(s)


		/// <summary>
		/// This is the main constructor for ControlPictureListing.
		/// </summary>
		public ControlPictureListing()
		{
			_pagingNavigation = new StringBuilder();
		}


		#endregion


		#region Public Properties


		/// <summary>
		/// The PictureCollection this control will be displaying.
		/// </summary>
		public PictureCollection Pictures
		{
			get
			{
				return _pictures;
			}
			set
			{
				_pictures = value;
			}
		}


		/// <summary>
		/// Read-only property that returns the total number of sub-albums for this album.
		/// </summary>
		public int SubAlbumsCount
		{
			get
			{
				EnsureChildControls();
				return _subAlbums.Count;
			}
		}


		/// <summary>
		/// Read-only property that returns the total number of pictures in this control.
		/// </summary>
		public int TotalPictureCount
		{
			get
			{
				int totalCount = 0;


				EnsureChildControls();

				totalCount = _pictures.Count;

				for (int i = 0; i < _subAlbums.Count; i++)
				{
					totalCount += _subAlbums[i].Pictures.Count;
				}

				return totalCount;
			}
		}


		/// <summary>
		/// The page number that the control should be displayed.
		/// </summary>
		public int PageNumber
		{
			get
			{
				return _pageNumber;
			}
			set
			{
				_pageNumber = value;
				this.RecalculatePagingStats();
			}
		}


		/// <summary>
		/// The ControlSubAlbumListing that is to be displayed within the picture listing context.
		/// </summary>
		public ControlSubAlbumListing SubAlbumListing
		{
			get
			{
				return _subAlbumListing;
			}
			set
			{
				_subAlbumListing = value;
			}
		}


		/// <summary>
		/// The number of records per page to be displayed.
		/// </summary>
		public int RecordsPerPage
		{
			get
			{
				return _recordsPerPage;
			}
			set
			{
				_recordsPerPage = value;
				this.RecalculatePagingStats();
			}
		}

		/// <summary>
		/// The number of columns displayed in a row.
		/// </summary>
		public int ColumnsPerPage
		{
			get
			{
				return _columnsPerPage;
			}
			set
			{
				_columnsPerPage = value;
			}
		}

		/// <summary>
		/// The ID of the album that you are currently displaying pictures for.
		/// </summary>
		public int AlbumID
		{
			get
			{
				return _albumID;
			}
			set
			{
				_albumID = value;
			}
		}


		/// <summary>
		/// The name of the album that you are current displaying the pictures for.
		/// </summary>
		public string AlbumName
		{
			get
			{
				return _albumName;
			}
			set
			{
				_albumName = value;
			}
		}
        

		#endregion


		#region Public Overrides


//		protected override void Render(HtmlTextWriter writer)
//		{
//			System.Text.StringBuilder controlText   = new System.Text.StringBuilder();
//			System.IO.StringWriter stringWriter		= new System.IO.StringWriter(controlText);
//			HtmlTextWriter htmlWriter				= new HtmlTextWriter(stringWriter);
//
//			base.Render(writer);
//
//			for (int i = 0; i < this.Controls.Count; i++)
//			{
//				if (this.Controls[i] as ControlPictureItem != null)
//				{
//					ControlPictureItem pictureItem = (ControlPictureItem) this.Controls[i];
//
//					pictureItem.RenderControl(htmlWriter);
//					writer.Write(controlText.ToString());
//					controlText.Remove(0, controlText.Length);
//				}
//			}
//		}

		
		/// <summary>
		/// This method sets up what is displayed before each picture listing.
		/// </summary>
		/// <param name="writer">The HtmlTextWriter that you wish to write to.</param>
		public override void RenderBeginTag(HtmlTextWriter writer)
		{
			System.Text.StringBuilder controlText   = new System.Text.StringBuilder();
			System.IO.StringWriter stringWriter		= new System.IO.StringWriter(controlText);
			HtmlTextWriter htmlWriter				= new HtmlTextWriter(stringWriter);
			string subAlbumText = "";
			StringBuilder prevAlbumURL = new StringBuilder();
			StringBuilder nextAlbumURL = new StringBuilder();
			StringBuilder imageURL = new StringBuilder();
			Template tagTemplate = new Template(Definitions.Templates.T_PICTURE_LISTING_BEGIN_TAG, this.Page);


			// Recalculate the paging stats, just in case.
			RecalculatePagingStats();


			// Handle previous album support.
			if (_prevAlbumID != 0)
			{
				if (Configuration.Instance().AlbumRewriting == RewriteType.ById)
				{
					prevAlbumURL.Append("<a href=\"" + _prevAlbumID + ".aspx\">");
				}
				else if (Configuration.Instance().AlbumRewriting == RewriteType.ByName)
				{
					prevAlbumURL.Append("<a href=\"" + this.Page.Server.UrlEncode(_prevAlbumName) + ".aspx\">");
				}
				prevAlbumURL.Append("Previous Album");
				prevAlbumURL.Append("</a>&nbsp;|");
			}
			else
			{
				if (nGallery.Lib.Configuration.Instance().AlbumListPagingDisplayType == "disable")
				{
					prevAlbumURL.Append("Previous Album&nbsp;|");
				}
				else if (nGallery.Lib.Configuration.Instance().AlbumListPagingDisplayType == "disappear")
				{
					prevAlbumURL.Append("");
				}
				else
				{
					prevAlbumURL.Append("");
				}
			}

			// Handle next album support.
			if (_nextAlbumID != 0)
			{
				if (Configuration.Instance().AlbumRewriting == RewriteType.ById)
				{
					nextAlbumURL.Append("<a href=\"" + _nextAlbumID + ".aspx\">");
				}
				else if (Configuration.Instance().AlbumRewriting == RewriteType.ByName)
				{
					nextAlbumURL.Append("<a href=\"" + this.Page.Server.UrlEncode(_nextAlbumName) + ".aspx\">");
				}
				nextAlbumURL.Append("Next Album");
				nextAlbumURL.Append("</a>&nbsp;|");
			}
			else
			{
				if (nGallery.Lib.Configuration.Instance().AlbumListPagingDisplayType == "disable")
				{
					nextAlbumURL.Append("Next Album&nbsp;|");
				}
				else if (nGallery.Lib.Configuration.Instance().AlbumListPagingDisplayType == "disappear")
				{
					nextAlbumURL.Append("");
				}
				else
				{
					nextAlbumURL.Append("");
				}
			}

			// Handle highlighted picture support.
			if (_album != null)
			{
				PhotoCache highlightedPictureCache;

				if(_album.HighlightedPicture != null)
				{
					highlightedPictureCache = _galleryBL.CreatePhotoCache(_album.ID, _album.HighlightedPicture.ID);

					if (Configuration.Instance().AlbumRewriting == RewriteType.ById)
					{
						imageURL.Append("<a href=\"" + _album.ID + "/" + _album.HighlightedPicture.ID + ".aspx\">");
					}
					else if (Configuration.Instance().AlbumRewriting == RewriteType.ByName)
					{
						imageURL.Append("<a href=\"" + this.Page.Server.UrlEncode(_album.Name) + "/" + _album.HighlightedPicture.ID + ".aspx\">");
					}
				}
				else
				{
					highlightedPictureCache = _galleryBL.CreatePhotoCache(_album.ID, 0);
				}


				
				imageURL.Append("<img src=\"" + highlightedPictureCache.GetSummary() + "\" border=\"0\" alt=\"" + _album.Name + "\" width=\"" + highlightedPictureCache.Width + "\" height=\"" + highlightedPictureCache.Height + "\">");

				if (_album.HighlightedPicture != null) imageURL.Append("</a>");
			}

			// Force render the sub-album control listing control.
			if (_subAlbumListing != null)
			{
				_subAlbumListing.RenderControl(htmlWriter);
			}
			subAlbumText = controlText.ToString();

			// Do any template variable replacements.
			tagTemplate.ProcessesVariable(Definitions.TemplateVariables.Pictures.T_PICTURE_ALBUM_ID,	_albumID.ToString());
			tagTemplate.ProcessesVariable(Definitions.TemplateVariables.Pictures.T_PICTURE_ALBUM_NAME,	_albumName);
			tagTemplate.ProcessesVariable(Definitions.TemplateVariables.Pictures.T_PICTURE_ALBUM_DESC,	_album.Description.Replace("\n", "<br>"));
			tagTemplate.ProcessesVariable(Definitions.TemplateVariables.Pictures.T_SUMMARY_HIGHLIGHT_PICTURE, imageURL.ToString());
			tagTemplate.ProcessesVariable(Definitions.TemplateVariables.Albums.T_PAGING_NAVIGATION,		_pagingNavigation.ToString());
			tagTemplate.ProcessesVariable(Definitions.TemplateVariables.Pictures.T_PREVIOUS_ALBUM,		prevAlbumURL.ToString());
			tagTemplate.ProcessesVariable(Definitions.TemplateVariables.Pictures.T_NEXT_ALBUM,			nextAlbumURL.ToString());
			tagTemplate.ProcessesVariable(Definitions.TemplateVariables.Pictures.T_SUBALBUM_LISTING,	subAlbumText);

			// Write out the final output.
			writer.Write(tagTemplate.GetString());
		}


		/// <summary>
		/// This method sets up what is displayed after each picture listing.
		/// </summary>
		/// <param name="writer">The HtmlTextWriter that you wish to write to.</param>
		public override void RenderEndTag(HtmlTextWriter writer)
		{
			System.Text.StringBuilder controlText   = new System.Text.StringBuilder();
			System.IO.StringWriter stringWriter		= new System.IO.StringWriter(controlText);
			HtmlTextWriter htmlWriter				= new HtmlTextWriter(stringWriter);
			string subAlbumText = "";
			Template tagTemplate = new Template(Definitions.Templates.T_PICTURE_LISTING_END_TAG, this.Page);


			RecalculatePagingStats();

			// Force render the sub-album control listing control.
			if (_subAlbumListing != null)
			{
				_subAlbumListing.RenderControl(htmlWriter);
			}
			subAlbumText = controlText.ToString();

			// Do any template variable replacements.
			tagTemplate.ProcessesVariable(Definitions.TemplateVariables.Pictures.T_PICTURE_ALBUM_ID,	_albumID.ToString());
			tagTemplate.ProcessesVariable(Definitions.TemplateVariables.Pictures.T_PICTURE_ALBUM_NAME,	_albumName);
			tagTemplate.ProcessesVariable(Definitions.TemplateVariables.Pictures.T_PICTURE_ALBUM_DESC,	_album.Description);
			tagTemplate.ProcessesVariable(Definitions.TemplateVariables.Albums.T_PAGING_NAVIGATION,		_pagingNavigation.ToString());
			tagTemplate.ProcessesVariable(Definitions.TemplateVariables.Pictures.T_SUBALBUM_LISTING,	subAlbumText);

			writer.WriteLine(tagTemplate.GetString());
		}

		#endregion


		#region Private Methods


		private void RecalculatePagingStats()
		{
			int recordCount;


			recordCount = _pictures.Count;

			// The starting record range.
			_startRecordRange	= (_pageNumber - 1) * _recordsPerPage;

			// The ending record range.
			_endRecordRange		= _startRecordRange + (_recordsPerPage - 1);
			_endRecordRange		= (_endRecordRange > (recordCount - 1) ? (recordCount - 1) : _endRecordRange);

			// Calculate the total number of pages.
			if (_recordsPerPage != 0)
			{
				_totalPages = (recordCount / _recordsPerPage);
				_totalPages = ((recordCount % _recordsPerPage) != 0 ? _totalPages + 1 : _totalPages);
				_totalPages = (_totalPages == 0 ? 1 : _totalPages);
			}

			_pagingNavigation = new StringBuilder();
			_pagingNavigation.Append("Page(s):&nbsp;&nbsp;");
			for (int i = 1; i <= _totalPages; i++)
			{
				if (i == _pageNumber)
				{
					_pagingNavigation.Append("<span class=\"currentPageHighlight\">" + i + "</span>&nbsp;&nbsp;");
				}
				else
				{
					if (this.Page == null)
					{
						if (Configuration.Instance().AlbumRewriting == RewriteType.ById)
							_pagingNavigation.Append("<a href=\"" + _albumID.ToString() + ".aspx?page=" + i + "\">" + i + "</a>&nbsp;&nbsp;");
						else if (Configuration.Instance().AlbumRewriting == RewriteType.ByName)
							_pagingNavigation.Append("<a href=\"" + _albumName + ".aspx?page=" + i + "\">" + i + "</a>&nbsp;&nbsp;");
					}
					else
					{
						if (Configuration.Instance().AlbumRewriting == RewriteType.ById)
							_pagingNavigation.Append("<a href=\"" + _albumID.ToString() + ".aspx?page=" + i + "\">" + i + "</a>&nbsp;&nbsp;");
						else if (Configuration.Instance().AlbumRewriting == RewriteType.ByName)
							_pagingNavigation.Append("<a href=\"" + this.Page.Server.UrlEncode(_albumName) + ".aspx?page=" + i + "\">" + i + "</a>&nbsp;&nbsp;");
					}
				}
			}

		}


		#endregion


		#region Protected Overrides


		/// <summary>
		/// This method simply renders the begin and end tag, and force renders the control tree
		/// that was created.
		/// </summary>
		/// <param name="writer">The HtmlTextWriter instance to write to.</param>
		protected override void Render(HtmlTextWriter writer)
		{
			EnsureChildControls();

			this.RenderBeginTag(writer);

			for (int i = 0; i < Controls.Count; i++)
			{
				if (Controls[i] as ControlSubAlbumListing == null)
					Controls[i].RenderControl(writer);
			}

			this.RenderEndTag(writer);

		}

		/// <summary>
		/// This method creates the control tree for this control. In our implementation, it handles paging
		/// (if necessary), and proxing information to the ControlPictureItem object.
		/// </summary>
		protected override void CreateChildControls()
		{

			_galleryBL = new nGallery.Lib.BL(this.Page.Server.MapPath(nGallery.Lib.Configuration.Instance().DataDirectory), this.Page.Server.MapPath(nGallery.Lib.Configuration.Instance().PhotosDirectory));

			_album		= _galleryBL.GetAlbum(_albumID);

			// Setup the framework for the sub-albums.
			// Get this albums sub-albums, if applicable.
			_subAlbums = _galleryBL.GetSubAlbums(_albumID);
				
			// Instantiate the sub-album listing control.
			_subAlbumListing = new nGallery.Lib.ControlSubAlbumListing();

			// Assign over the sub-albums.
			_subAlbumListing.Albums = _subAlbums;

			this.Controls.Add(_subAlbumListing);

			// Get the next/previous albums' IDs.
			_prevAlbumID = _galleryBL.GetPreviousAlbumID(_albumID);
			_nextAlbumID = _galleryBL.GetNextActualAlbumID(_albumID);

			// Also, get their names.
			if (_prevAlbumID != 0)
				_prevAlbumName = _galleryBL.GetAlbum(_prevAlbumID).Name;

			if (_nextAlbumID != 0)
				_nextAlbumName = _galleryBL.GetAlbum(_nextAlbumID).Name;

			if (_pictures.Count == 0)
			{
				ControlNoItems noItems = new ControlNoItems(Definitions.ListType.PICTURE_LIST);

				this.Controls.Add(noItems);
			}
			else
			{
				int columns = 0;



				if(_columnsPerPage > 0)
				{
					this.Controls.Add(new LiteralControl(Template.GetTemplate(Definitions.Templates.T_PICTURE_LISTING_BEGIN_TABLE, this.Page)));
				}

				if (_pageNumber == 0 || _recordsPerPage == 0)
				{
					foreach (Picture currentPicture in _pictures)
					{
						ControlPictureItem pictureItem = new ControlPictureItem();

						pictureItem.Picture		= currentPicture;
						pictureItem.PictureCache = _galleryBL.CreatePhotoCache(_albumID, currentPicture.ID);
						pictureItem.AlbumID		= _albumID;
						pictureItem.AlbumName	= _albumName;

						if(_columnsPerPage > 0) 
						{
							if(columns == 0)
							{
								this.Controls.Add(new LiteralControl(Template.GetTemplate(Definitions.Templates.T_PICTURE_LISTING_BEGIN_ROW, this.Page)));
							}

							this.Controls.Add(new LiteralControl(Template.GetTemplate(Definitions.Templates.T_PICTURE_LISTING_BEGIN_COLUMN, this.Page)));
							this.Controls.Add(pictureItem);
							this.Controls.Add(new LiteralControl(Template.GetTemplate(Definitions.Templates.T_PICTURE_LISTING_END_COLUMN, this.Page)));
							columns++;

							if(columns == _columnsPerPage)
							{
								this.Controls.Add(new LiteralControl(Template.GetTemplate(Definitions.Templates.T_PICTURE_LISTING_END_ROW, this.Page)));
								columns = 0;
							}
						}
						else
						{
							this.Controls.Add(pictureItem);
						}
					}

					if((_columnsPerPage > 0) && (columns != 0))
					{
						this.Controls.Add(new LiteralControl(Template.GetTemplate(Definitions.Templates.T_PICTURE_LISTING_END_ROW, this.Page)));
					}
				}
				else
				{
					for (int i = _startRecordRange; i <= _endRecordRange; i++)
					{
						ControlPictureItem pictureItem = new ControlPictureItem();

						pictureItem.Picture		= (Picture) _pictures[i];
						pictureItem.PictureCache = _galleryBL.CreatePhotoCache(_albumID, _pictures[i].ID);
						pictureItem.AlbumID		= _albumID;
						pictureItem.AlbumName	= _albumName;
						
						if(_columnsPerPage > 0) 
						{
							if(columns == 0)
							{
								this.Controls.Add(new LiteralControl(Template.GetTemplate(Definitions.Templates.T_PICTURE_LISTING_BEGIN_ROW, this.Page)));
							}

							this.Controls.Add(new LiteralControl(Template.GetTemplate(Definitions.Templates.T_PICTURE_LISTING_BEGIN_COLUMN, this.Page)));
							this.Controls.Add(pictureItem);
							this.Controls.Add(new LiteralControl(Template.GetTemplate(Definitions.Templates.T_PICTURE_LISTING_END_COLUMN, this.Page)));
							columns++;

							if(columns == _columnsPerPage)
							{
								this.Controls.Add(new LiteralControl(Template.GetTemplate(Definitions.Templates.T_PICTURE_LISTING_END_ROW, this.Page)));
								columns = 0;
							}
						}
						else
						{
							this.Controls.Add(pictureItem);
						}
					}

					if((_columnsPerPage > 0) && (columns != 0))
					{
						this.Controls.Add(new LiteralControl(Template.GetTemplate(Definitions.Templates.T_PICTURE_LISTING_END_ROW, this.Page)));
					}
				}

				if(_columnsPerPage > 0)
				{
					this.Controls.Add(new LiteralControl(Template.GetTemplate(Definitions.Templates.T_PICTURE_LISTING_END_TABLE, this.Page)));
				}
			}
		}


		#endregion


	}
}
