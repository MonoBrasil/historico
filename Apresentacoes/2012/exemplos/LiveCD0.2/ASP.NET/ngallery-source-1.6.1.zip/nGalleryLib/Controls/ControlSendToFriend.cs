#region Copyright and License
/*
Copyright 2003 Jason Alexander, nGallery.org
Design work copyright Thomas Johansen (http://www.aylarsolutions.com/)

GOTDOTNET WORKSPACES COMMERCIAL DERIVATIVES LICENSE
Copyright (C) 2003 Microsoft Corporation

You can use this Software for any commercial or noncommercial purpose, 
including distributing derivative works.

In return, we simply require that you agree:

1. Not to remove any copyright notices from the Software. 
2. That if you distribute the Software in source code form you do so only 
   under this License (i.e. you must include a complete copy of this License 
   with your distribution), and if you distribute the Software solely in 
   object form you only do so under a license that complies with this License. 
3. That the Software comes "as is", with no warranties. None whatsoever. This 
   means no express, implied or statutory warranty, including without 
   limitation, warranties of merchantability or fitness for a particular 
   purpose or any warranty of noninfringement. Also, you must pass this 
   disclaimer on whenever you distribute the Software.
4. That neither Microsoft nor any contributor to the Software will be liable 
   for any of those types of damages known as indirect, special, consequential, 
   or incidental related to the Software or this License, to the maximum extent 
   the law permits, no matter what legal theory it�s based on. Also, you must 
   pass this limitation of liability on whenever you distribute the Software.
5. That if you sue anyone over patents that you think may apply to the 
   Software for a person's use of the Software, your license to the Software 
   ends automatically. 
6. That the patent rights, if any, licensed hereunder only apply to the 
   Software, not to any derivative works you make. 
7. That your rights under this License end automatically if you breach it in 
   any way.
*/
#endregion
using System;
using System.Configuration;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.ComponentModel;
using System.Web.Mail;

namespace nGallery.Lib
{
	/// <summary>
	/// This control handles the "Send to Friend" form, functionality and templating.
	/// </summary>
	public class ControlSendToFriend : System.Web.UI.WebControls.WebControl, INamingContainer
	{


		#region Private Members


		private Definitions.ListType _listType;
		private TextBox _yourEmailAddr;
		private TextBox _toEmailAddr;
		private TextBox _emailSubject;
		private TextBox _emailBody;
		private Button	_btnSubmit;
		private Label	_lblStatus;
		private int		_albumID;
		private string	_albumName;
		private int		_pictureID;
		private string	_pictureName;


		#endregion


		#region Constructor(s)


		/// <summary>
		/// Base constructor.
		/// </summary>
		/// <param name="listType">The type of list that this control will be used for.</param>
		public ControlSendToFriend(Definitions.ListType listType)
		{
			this.ID = "ControlSendToFriend";


			_listType		= listType;
			_yourEmailAddr	= new TextBox();
			_toEmailAddr	= new TextBox();
			_emailSubject	= new TextBox();
			_emailBody		= new TextBox();
			_btnSubmit		= new Button();
			_lblStatus		= new Label();
			_albumID		= 0;
			_albumName		= "";
			_pictureID		= 0;
			_pictureName	= "";
		}


		#endregion


		#region Public Properties


		/// <summary>
		/// The ID of the given album. This property is only required when sending an album to a friend.
		/// </summary>
		public int AlbumID
		{
			get
			{
				return _albumID;
			}
			set
			{
				_albumID = value;
			}
		}


		/// <summary>
		/// The name of the album. This property is only required when sending an album to a friend.
		/// </summary>
		public string AlbumName
		{
			get
			{
				return _albumName;
			}
			set
			{
				_albumName = value;
			}
		}


		/// <summary>
		/// The ID of the picture. This is only applicable when sending a picture to a friend.
		/// </summary>
		public int PictureID
		{
			get
			{
				return _pictureID;
			}
			set
			{
				_pictureID = value;
			}
		}


		/// <summary>
		/// The name of the picture. This is only applicable when sending a picture to a friend.
		/// </summary>
		public string PictureName
		{
			get
			{
				return _pictureName;
			}
			set
			{
				_pictureName = value;
			}
		}


		#endregion


		#region Protected Control Methods


		/// <summary>
		/// This method handles create the control tree for all child controls.
		/// </summary>
		protected override void CreateChildControls()
		{
		
			_lblStatus.ForeColor = System.Drawing.Color.Red;

			_emailBody.TextMode = TextBoxMode.MultiLine;
			_emailBody.Rows		= 15;
			_emailBody.Columns	= 50;

			_btnSubmit.Text		= "Send";
			_btnSubmit.Style.Add("width", "80px");
			_btnSubmit.Click	+= new EventHandler(btnSubmit_Click);



			this.Controls.Add(_yourEmailAddr);
			this.Controls.Add(_toEmailAddr);
			this.Controls.Add(_emailSubject);
			this.Controls.Add(_emailBody);
			this.Controls.Add(_btnSubmit);			
			this.Controls.Add(_lblStatus);
		}


		/// <summary> 
		/// Render this control to the output parameter specified.
		/// </summary>
		/// <param name="output"> The HTML writer to write out to </param>
		protected override void Render(HtmlTextWriter output)
		{
			EnsureChildControls();


			Template template = new Template(Definitions.Templates.T_SEND_TO_FRIEND, this.Page);
			System.Text.StringBuilder controlText   = new System.Text.StringBuilder();
			System.IO.StringWriter stringWriter		= new System.IO.StringWriter(controlText);
			HtmlTextWriter htmlWriter				= new HtmlTextWriter(stringWriter);
			string yourEmailAddrText	= "";
			string toEmailAddrText		= "";
			string emailSubjectText		= "";
			string emailBodyText		= "";
			string btnSubmitText		= "";
			string statusLabelText		= "";


			// Render my controls to a string variable.
			_yourEmailAddr.RenderControl(htmlWriter);
			yourEmailAddrText = controlText.ToString();
			controlText.Remove(0, controlText.Length);

			_toEmailAddr.RenderControl(htmlWriter);
			toEmailAddrText = controlText.ToString();
			controlText.Remove(0, controlText.Length);

			_emailSubject.RenderControl(htmlWriter);
			emailSubjectText = controlText.ToString();
			controlText.Remove(0, controlText.Length);

			_emailBody.RenderControl(htmlWriter);
			emailBodyText = controlText.ToString();
			controlText.Remove(0, controlText.Length);

			_btnSubmit.RenderControl(htmlWriter);
			btnSubmitText = controlText.ToString();
			controlText.Remove(0, controlText.Length);

			_lblStatus.RenderControl(htmlWriter);
			statusLabelText = controlText.ToString();
			controlText.Remove(0, controlText.Length);


			// Do any template variable replacements.
			template.ProcessesVariable(Definitions.TemplateVariables.SendToFriend.T_YOUR_EMAIL_ADDR,	yourEmailAddrText);
			template.ProcessesVariable(Definitions.TemplateVariables.SendToFriend.T_TO_EMAIL_ADDR,	toEmailAddrText);
			template.ProcessesVariable(Definitions.TemplateVariables.SendToFriend.T_EMAIL_SUBJECT,	emailSubjectText);
			template.ProcessesVariable(Definitions.TemplateVariables.SendToFriend.T_EMAIL_BODY,		emailBodyText);
			template.ProcessesVariable(Definitions.TemplateVariables.SendToFriend.T_SUBMIT_BUTTON,	btnSubmitText);
			template.ProcessesVariable(Definitions.TemplateVariables.SendToFriend.T_STATUS_LABEL,		statusLabelText);

			output.Write(template.GetString());
			
		}


		#endregion


		#region Private Method - btnSubmit_Click()


		/// <summary>
		/// This method is the main method that is called when the form is to be processed.
		/// </summary>
		/// <param name="sender">The sending object.</param>
		/// <param name="e">Any EventArgs, if applicable.</param>
		private void btnSubmit_Click(object sender, EventArgs e)
		{
			EnsureChildControls();


			Template mailTemplate = new Template();
			StringBuilder targetURL	= new StringBuilder();
			MailMessage mail		= new MailMessage();


			if (_yourEmailAddr.Text == "")
			{
				_lblStatus.Text = "You must enter a e-mail address in the \"From\" field.";
				return;
			}

			if (_toEmailAddr.Text == "")
			{
				_lblStatus.Text = "You must enter an e-mail address in the \"To\" field.";
				return;
			}


			// Load up the email HTML template.
			if (_listType == Definitions.ListType.ALBUM_LIST)
			{
				mailTemplate = new Template(Definitions.Templates.T_SEND_TO_FRIEND_GALLERY_EMAIL, this.Page);

				targetURL.Append("http://");
				targetURL.Append(this.Page.Request.ServerVariables["SERVER_NAME"]);
				targetURL.Append(this.Page.Request.ServerVariables["SERVER_PORT"] != "80" ? ":" + this.Page.Request.ServerVariables["SERVER_PORT"] : "");
				targetURL.Append(this.Page.Request.ServerVariables["SCRIPT_NAME"].Replace("sendToFriend.aspx", ""));
			}
			else if (_listType == Definitions.ListType.PICTURE_LIST)
			{
				mailTemplate = new Template(Definitions.Templates.T_SEND_TO_FRIEND_PIC_LIST_EMAIL, this.Page);

				targetURL.Append("http://");
				targetURL.Append(this.Page.Request.ServerVariables["SERVER_NAME"]);
				targetURL.Append(this.Page.Request.ServerVariables["SERVER_PORT"] != "80" ? ":" + this.Page.Request.ServerVariables["SERVER_PORT"] : "");

				if (Configuration.Instance().AlbumRewriting == RewriteType.ById)
				{
					targetURL.Append(this.Page.Request.ServerVariables["SCRIPT_NAME"].Replace("sendToFriend.aspx", "albums/" + _albumID + ".aspx"));
				}
				else if (Configuration.Instance().AlbumRewriting == RewriteType.ByName)
				{
					targetURL.Append(this.Page.Request.ServerVariables["SCRIPT_NAME"].Replace("sendToFriend.aspx", "albums/" + this.Page.Server.UrlEncode(_albumName) + ".aspx"));
				}
								

				mailTemplate.ProcessesVariable(Definitions.TemplateVariables.SendToFriend.T_ALBUM_ID,	_albumID.ToString());
				mailTemplate.ProcessesVariable(Definitions.TemplateVariables.SendToFriend.T_ALBUM_NAME, _albumName);

			}
			else if (_listType == Definitions.ListType.COMMENT_LIST)
			{
				mailTemplate = new Template(Definitions.Templates.T_SEND_TO_FRIEND_PIC_DETAILS_EMAIL, this.Page);

				targetURL.Append("http://");
				targetURL.Append(this.Page.Request.ServerVariables["SERVER_NAME"]);
				targetURL.Append(this.Page.Request.ServerVariables["SERVER_PORT"] != "80" ? ":" + this.Page.Request.ServerVariables["SERVER_PORT"] : "");

				if (Configuration.Instance().AlbumRewriting == RewriteType.ById)
				{
					targetURL.Append(this.Page.Request.ServerVariables["SCRIPT_NAME"].Replace("sendToFriend.aspx", "albums/" + _albumID + "/" + _pictureID + ".aspx"));
				}
				else if (Configuration.Instance().AlbumRewriting == RewriteType.ByName)
				{
					targetURL.Append(this.Page.Request.ServerVariables["SCRIPT_NAME"].Replace("sendToFriend.aspx", "albums/" + this.Page.Server.UrlEncode(_albumName) + "/" + _pictureID + ".aspx"));
				}

				mailTemplate.ProcessesVariable(Definitions.TemplateVariables.SendToFriend.T_ALBUM_ID,		_albumID.ToString());
				mailTemplate.ProcessesVariable(Definitions.TemplateVariables.SendToFriend.T_ALBUM_NAME,		_albumName);
				mailTemplate.ProcessesVariable(Definitions.TemplateVariables.SendToFriend.T_PICTURE_ID,		_pictureID.ToString());
				mailTemplate.ProcessesVariable(Definitions.TemplateVariables.SendToFriend.T_PICTURE_NAME,	_pictureName);
			}
			else
			{
				mailTemplate = new Template(Definitions.Templates.T_SEND_TO_FRIEND_GALLERY_EMAIL, this.Page);

				targetURL.Append("http://");
				targetURL.Append(this.Page.Request.ServerVariables["SERVER_NAME"]);
				targetURL.Append(this.Page.Request.ServerVariables["SERVER_PORT"] != "80" ? ":" + this.Page.Request.ServerVariables["SERVER_PORT"] : "");
				targetURL.Append(this.Page.Request.ServerVariables["SCRIPT_NAME"].Replace("sendToFriend.aspx", ""));

			}


			mailTemplate.ProcessesVariable(Definitions.TemplateVariables.SendToFriend.T_YOUR_EMAIL_ADDR,	_yourEmailAddr.Text);
			mailTemplate.ProcessesVariable(Definitions.TemplateVariables.SendToFriend.T_EMAIL_BODY,			_emailBody.Text);
			mailTemplate.ProcessesVariable(Definitions.TemplateVariables.SendToFriend.T_TARGET_URL,			targetURL.ToString());
			mailTemplate.ProcessesVariable(Definitions.GlobalTemplateVariables.T_SITE_TITLE,				nGallery.Lib.Configuration.Instance().SiteTitle);


			// Add the nGallery footer to the outgoing message.
			mailTemplate.Append("<table border=\"0\" width=\"100%\">");
			mailTemplate.Append("<tr>");
			mailTemplate.Append("		<td>");
			mailTemplate.Append("		&nbsp;");
			mailTemplate.Append("		</td>");
			mailTemplate.Append("	</tr>");
			mailTemplate.Append("	<tr>");
			mailTemplate.Append("		<td>");
			mailTemplate.Append("			<hr width=\"100%\">");
			mailTemplate.Append("			<i><b>Powered by <a href=\"http://www.ngallery.org\">nGallery</a>");
			mailTemplate.Append("		</td>");
			mailTemplate.Append("	</tr>");
			mailTemplate.Append("</table>");


			// Build the mail message.
			mail.To			= _toEmailAddr.Text;
			mail.From		= _yourEmailAddr.Text;
			mail.Subject	= _emailSubject.Text;
			mail.Body		= mailTemplate.GetString();
			mail.BodyFormat = MailFormat.Html;
	

			SmtpMail.SmtpServer = Configuration.Instance().SmtpServer;


			try
			{
				SmtpMail.Send(mail);
			}
			catch (Exception exc)
			{
				_lblStatus.Text = "There was an error while attempting to send your message: " + exc.Message;

				if (exc.InnerException != null)
				{
					_lblStatus.Text = _lblStatus.Text + "<br>Some additional info, if necessary: " + exc.InnerException.Message;

					if (exc.InnerException.InnerException != null)
					{
					_lblStatus.Text = _lblStatus.Text + "<br>Some additional info, if necessary: " + exc.InnerException.InnerException.Message;
					}
				}

				return;
			}


			_toEmailAddr.Text	= "";
			_yourEmailAddr.Text = "";
			_emailSubject.Text	= "";
			_emailBody.Text		= "";

			_lblStatus.Text = "Message sent!";

		}

		#endregion


	}
}
