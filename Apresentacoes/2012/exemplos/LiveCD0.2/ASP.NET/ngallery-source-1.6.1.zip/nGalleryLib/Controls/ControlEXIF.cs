#region Copyright and License
/*
Copyright 2003 Jason Alexander, nGallery.org
Design work copyright Thomas Johansen (http://www.aylarsolutions.com/)

GOTDOTNET WORKSPACES COMMERCIAL DERIVATIVES LICENSE
Copyright (C) 2003 Microsoft Corporation

You can use this Software for any commercial or noncommercial purpose, 
including distributing derivative works.

In return, we simply require that you agree:

1. Not to remove any copyright notices from the Software. 
2. That if you distribute the Software in source code form you do so only 
   under this License (i.e. you must include a complete copy of this License 
   with your distribution), and if you distribute the Software solely in 
   object form you only do so under a license that complies with this License. 
3. That the Software comes "as is", with no warranties. None whatsoever. This 
   means no express, implied or statutory warranty, including without 
   limitation, warranties of merchantability or fitness for a particular 
   purpose or any warranty of noninfringement. Also, you must pass this 
   disclaimer on whenever you distribute the Software.
4. That neither Microsoft nor any contributor to the Software will be liable 
   for any of those types of damages known as indirect, special, consequential, 
   or incidental related to the Software or this License, to the maximum extent 
   the law permits, no matter what legal theory it�s based on. Also, you must 
   pass this limitation of liability on whenever you distribute the Software.
5. That if you sue anyone over patents that you think may apply to the 
   Software for a person's use of the Software, your license to the Software 
   ends automatically. 
6. That the patent rights, if any, licensed hereunder only apply to the 
   Software, not to any derivative works you make. 
7. That your rights under this License end automatically if you breach it in 
   any way.
*/
#endregion

using System;
using System.Text;
using System.Configuration;

namespace nGallery.Lib
{
	/// <summary>
	/// Renders EXIF property values to the browser.
	/// </summary>
	public class ControlEXIF : System.Web.UI.Control
	{

		#region Private Members


		private EXIF _exif;


		#endregion


		#region Constructor(s)


		/// <summary>
		/// The default constructor.
		/// </summary>
		/// <param name="filePath">The path and file of which to analyze.</param>
		public ControlEXIF(string filePath)
		{
			_exif = new EXIF(filePath);
		}


		#endregion


		#region Render Overrides


		/// <summary>
		/// This method takes care of rendering the output for the EXIF information.
		/// </summary>
		/// <param name="writer">The HtmlTextWriter to write the output to.</param>
		protected override void Render(System.Web.UI.HtmlTextWriter writer)
		{
			// Declare local variables.
			StringBuilder exifHTML = new StringBuilder();
			Definitions.exifCode codetemp= new Definitions.exifCode();
			
			string[] displayEXIFProperties = Configuration.Instance().EXIFProperties.Split((char)';'); 
			Definitions.exifCode codes;

			for(int x = 0; x < displayEXIFProperties.Length; x++)
			{
				// Get the enum value for this EXIF property.
				codes = (Definitions.exifCode) Enum.Parse(codetemp.GetType(), displayEXIFProperties[x]);
				
				// Create the template.
				Template template	= new Template(Definitions.Templates.T_EXIF_ITEM, this.Page);
		
				// Do the template variable replacements.
				template.ProcessesVariable(Definitions.TemplateVariables.EXIF.T_EXIFPROPERTY, displayEXIFProperties[x]);
				template.ProcessesVariable(Definitions.TemplateVariables.EXIF.T_EXIFVALUE, _exif.GetEXIFProperty(codes));

				// Add it to the string builder.
				exifHTML.Append(template.GetString());
			}
			
			if(exifHTML.Length > 0)
			{
				// Write out the templates.
				// Get the beginning tag.
				Template startTemplate = new Template(Definitions.Templates.T_EXIF_BEGIN_TAG, this.Page);
				exifHTML.Insert(0, startTemplate.GetString());

				// Get the end tag.
				Template endTemplate = new Template(Definitions.Templates.T_EXIF_END_TAG, this.Page);
				exifHTML.Append(endTemplate.GetString());

				// Write the output.
				writer.Write(exifHTML.ToString());
			}
			
		}


		#endregion


	}
}
