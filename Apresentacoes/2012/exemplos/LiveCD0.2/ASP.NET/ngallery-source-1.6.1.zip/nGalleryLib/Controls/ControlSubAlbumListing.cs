#region Copyright and License
/*
Copyright 2003 Jason Alexander, nGallery.org
Design work copyright Thomas Johansen (http://www.aylarsolutions.com/)

GOTDOTNET WORKSPACES COMMERCIAL DERIVATIVES LICENSE
Copyright (C) 2003 Microsoft Corporation

You can use this Software for any commercial or noncommercial purpose, 
including distributing derivative works.

In return, we simply require that you agree:

1. Not to remove any copyright notices from the Software. 
2. That if you distribute the Software in source code form you do so only 
   under this License (i.e. you must include a complete copy of this License 
   with your distribution), and if you distribute the Software solely in 
   object form you only do so under a license that complies with this License. 
3. That the Software comes "as is", with no warranties. None whatsoever. This 
   means no express, implied or statutory warranty, including without 
   limitation, warranties of merchantability or fitness for a particular 
   purpose or any warranty of noninfringement. Also, you must pass this 
   disclaimer on whenever you distribute the Software.
4. That neither Microsoft nor any contributor to the Software will be liable 
   for any of those types of damages known as indirect, special, consequential, 
   or incidental related to the Software or this License, to the maximum extent 
   the law permits, no matter what legal theory it�s based on. Also, you must 
   pass this limitation of liability on whenever you distribute the Software.
5. That if you sue anyone over patents that you think may apply to the 
   Software for a person's use of the Software, your license to the Software 
   ends automatically. 
6. That the patent rights, if any, licensed hereunder only apply to the 
   Software, not to any derivative works you make. 
7. That your rights under this License end automatically if you breach it in 
   any way.
*/
#endregion
using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.ComponentModel;

namespace nGallery.Lib
{
	/// <summary>
	/// This control is used to display any specific sub-albums for a given album. This control
	/// is pretty "dumb" in that it doesn't know it's parent album association. It simply lists the
	/// given AlbumCollection that it's given.
	/// </summary>
	public class ControlSubAlbumListing : System.Web.UI.WebControls.WebControl
	{


		#region Private Members


		private AlbumCollection _albums;


		#endregion


		#region Public Properties


		/// <summary>
		/// The specific sub-albums AlbumCollection that this listing should attempt to render.
		/// </summary>
		public AlbumCollection Albums
		{
			get
			{
				return _albums;
			}
			set
			{
				_albums = value;
			}
		}


		#endregion

		
		#region Overrides


		/// <summary>
		/// This method sets up the control tree for this composite control. In this case, for every instance of an Album
		/// object in the Albums collection, it creates a ControlSubAlbumItem instance, passes it the current Album instance and
		/// adds it to it's own control tree.
		/// </summary>
		protected override void CreateChildControls()
		{
			if (_albums.Count != 0)
			{
				for (int i = 0; i < _albums.Count; i++)
				{
					ControlSubAlbumItem albumItem = new ControlSubAlbumItem();

					albumItem.Album = _albums[i];

					this.Controls.Add(albumItem);
				}
			}
			else
			{
				// Do nothing.
			}
		}

		
		/// <summary>
		/// This method renders the template "template.subalbumlisting.begintag.html" for your specific skin.
		/// </summary>
		/// <param name="writer">The HtmlTextWriter instance to write to.</param>
		public override void RenderBeginTag(HtmlTextWriter writer)
		{
			if (_albums.Count != 0)
			{
				Template template = new Template(Definitions.Templates.T_SUBALBUM_LISTING_BEGIN_TAG, this.Page);


				writer.Write(template.GetString());
			}
		}


		/// <summary>
		/// This method renders the template "template.subalbumlisting.endtag.html" for your specific skin.
		/// </summary>
		/// <param name="writer">The HtmlTextWriter instance to write to.</param>
		public override void RenderEndTag(HtmlTextWriter writer)
		{
			if (_albums.Count != 0)
			{
				Template template = new Template(Definitions.Templates.T_SUBALBUM_LISTING_END_TAG, this.Page);


				writer.Write(template.GetString());
			}

		}


		#endregion


	}
}
