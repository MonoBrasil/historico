#region Copyright and License
/*
Copyright 2003 Jason Alexander, nGallery.org
Design work copyright Thomas Johansen (http://www.aylarsolutions.com/)

GOTDOTNET WORKSPACES COMMERCIAL DERIVATIVES LICENSE
Copyright (C) 2003 Microsoft Corporation

You can use this Software for any commercial or noncommercial purpose, 
including distributing derivative works.

In return, we simply require that you agree:

1. Not to remove any copyright notices from the Software. 
2. That if you distribute the Software in source code form you do so only 
   under this License (i.e. you must include a complete copy of this License 
   with your distribution), and if you distribute the Software solely in 
   object form you only do so under a license that complies with this License. 
3. That the Software comes "as is", with no warranties. None whatsoever. This 
   means no express, implied or statutory warranty, including without 
   limitation, warranties of merchantability or fitness for a particular 
   purpose or any warranty of noninfringement. Also, you must pass this 
   disclaimer on whenever you distribute the Software.
4. That neither Microsoft nor any contributor to the Software will be liable 
   for any of those types of damages known as indirect, special, consequential, 
   or incidental related to the Software or this License, to the maximum extent 
   the law permits, no matter what legal theory it�s based on. Also, you must 
   pass this limitation of liability on whenever you distribute the Software.
5. That if you sue anyone over patents that you think may apply to the 
   Software for a person's use of the Software, your license to the Software 
   ends automatically. 
6. That the patent rights, if any, licensed hereunder only apply to the 
   Software, not to any derivative works you make. 
7. That your rights under this License end automatically if you breach it in 
   any way.
*/
#endregion
using System;
using System.Configuration;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace nGallery.Lib
{
	/// <summary>
	/// This control is responsible for handling the Comment submission form.
	/// </summary>
	public class ControlCommentForm : System.Web.UI.Control, INamingContainer
	{


		#region Private Members


		private int _albumID;
		private int _pictureID;
		private TextBox _fromName;
		private TextBox _fromEmailAddr;
		private TextBox _fromWebURL;
		private TextBox _comments;
		private Button  _submitButton = new Button();


		#endregion


		#region Constructor(s)


		/// <summary>
		/// The main constructor for ControlCommentForm.
		/// </summary>
		public ControlCommentForm()
		{
			this.ID = "CommentForm";

			_fromName		= new TextBox();
			_fromEmailAddr	= new TextBox();
			_fromWebURL		= new TextBox();
			_comments		= new TextBox();
		}


		#endregion


		#region Public Properties


		/// <summary>
		/// The ID of the album of the respective picture that is being commented on.
		/// </summary>
		public int AlbumID
		{
			get
			{
				return _albumID;
			}
			set
			{
				_albumID = value;
			}
		}


		/// <summary>
		/// The ID of the picture that is being commented on.
		/// </summary>
		public int PictureID
		{
			get
			{
				return _pictureID;
			}
			set
			{
				_pictureID = value;
			}
		}


		#endregion


		#region Protected Methods


		/// <summary>
		/// This method is responsible for setting up the control tree for all child controls.
		/// </summary>
		protected override void CreateChildControls()
		{
			
			// Configure any of the above controls here.
			_fromName.MaxLength = 150;

			_fromEmailAddr.MaxLength = 150;

			_fromWebURL.MaxLength = 150;

			_comments.TextMode	= TextBoxMode.MultiLine;
			_comments.Rows		= 15;
			_comments.Columns	= 50;

			_submitButton.ID = "btnSubmit";
			_submitButton.Text = "Add Comment";
			_submitButton.CommandArgument = "AddComment";
			_submitButton.Click += new EventHandler(submitButton_Click);


			// Add them to the control tree.
			this.Controls.Add(_fromName);
			this.Controls.Add(_fromEmailAddr);
			this.Controls.Add(_fromWebURL);
			this.Controls.Add(_comments);
			this.Controls.Add(_submitButton);
			
		}


		/// <summary>
		/// This method is responsible for rendering out the output of the actual control.
		/// </summary>
		/// <param name="writer">The HtmlTextWriter object to write to.</param>
		protected override void Render(System.Web.UI.HtmlTextWriter writer)
		{
			EnsureChildControls();


			Template template = new Template(Definitions.Templates.T_COMMENT_FORM, this.Page);
			string fromNameText			= "";
			string fromEmailAddrText	= "";
			string fromWebURLText		= "";
			string commentsText			= "";
			string submitButtonText		= "";
			System.Text.StringBuilder controlText   = new System.Text.StringBuilder();
			System.IO.StringWriter stringWriter		= new System.IO.StringWriter(controlText);
			HtmlTextWriter htmlWriter				= new HtmlTextWriter(stringWriter);
			string commentType;
			string commentTypeTitle = "Unknown";


			commentType = nGallery.Lib.Configuration.Instance().CommentType;
			if (commentType == "Comment")
			{
				commentTypeTitle= "Comment";
			}
			else if (commentType == "Caption")
			{
				commentTypeTitle = "Caption";
			}			


			// Render out the controls into strings so we maintain the built-in postback code and wireups.
			// From Name Text Box
			_fromName.RenderControl(htmlWriter);
			fromNameText = controlText.ToString();
			controlText.Remove(0, controlText.Length);

			// From Email Address Text Box
			_fromEmailAddr.RenderControl(htmlWriter);
			fromEmailAddrText = controlText.ToString();
			controlText.Remove(0, controlText.Length);

			// From Web URL Text Box
			_fromWebURL.RenderControl(htmlWriter);
			fromWebURLText = controlText.ToString();
			controlText.Remove(0, controlText.Length);

			// Comments Text Box
			_comments.RenderControl(htmlWriter);
			commentsText = controlText.ToString();
			controlText.Remove(0, controlText.Length);

			// Submit Button
			_submitButton.RenderControl(htmlWriter);
			submitButtonText = controlText.ToString();
			
			

			// Template Variable Replacements
			template.ProcessesVariable(Definitions.TemplateVariables.Comments.T_COMMENT_FRM_NAME_TXT,		fromNameText);
			template.ProcessesVariable(Definitions.TemplateVariables.Comments.T_COMMENT_FRM_EMAIL_ADDR_TXT,	fromEmailAddrText);
			template.ProcessesVariable(Definitions.TemplateVariables.Comments.T_COMMENT_FRM_WEBSITE_URL_TXT,fromWebURLText);
			template.ProcessesVariable(Definitions.TemplateVariables.Comments.T_COMMENT_FRM_TEXT_AREA,		commentsText);
			template.ProcessesVariable(Definitions.TemplateVariables.Comments.T_COMMENT_FRM_SUBMIT_BUTTON,	submitButtonText);
			template.ProcessesVariable(Definitions.TemplateVariables.Comments.T_COMMENT_TYPE_TITLE,			commentTypeTitle);
			template.ProcessesVariable(Definitions.TemplateVariables.Albums.T_ALBUM_ID, _albumID.ToString());
			template.ProcessesVariable(Definitions.TemplateVariables.Pictures.T_PICTURE_ID, _pictureID.ToString());


			// Write out the template.
			writer.Write(template.GetString());
		}

		#endregion


		#region Private Methods


		/// <summary>
		/// This method handles the main processing of the form.
		/// </summary>
		/// <param name="sender">The object that is sending the call.</param>
		/// <param name="e">Any EventArgs being passed.</param>
		private void submitButton_Click(object sender, System.EventArgs e)
		{
			EnsureChildControls();


			nGallery.Lib.BL galleryBL = new nGallery.Lib.BL(this.Page.Server.MapPath(nGallery.Lib.Configuration.Instance().DataDirectory));
			string albumName = galleryBL.GetAlbum(_albumID).Name;
			Comment newComment = new Comment();


			newComment.ID				= galleryBL.GetNextCommentID(_albumID, _pictureID);
			newComment.FromName			= _fromName.Text;
			newComment.FromEmailAddr	= _fromEmailAddr.Text;
			newComment.FromWebURL		= _fromWebURL.Text;
			newComment.CommentText		= _comments.Text;
			newComment.CreateDate		= DateTime.Now;

			galleryBL.CreateComment(_albumID, _pictureID, newComment);

			if (Configuration.Instance().AlbumRewriting == RewriteType.ById)
				this.Page.Response.Redirect("~/albums/" + _albumID.ToString() + "/" + _pictureID + ".aspx");
			else if (Configuration.Instance().AlbumRewriting == RewriteType.ByName)
				this.Page.Response.Redirect("~/albums/" + this.Page.Server.UrlEncode(albumName) + "/" + _pictureID + ".aspx");

		}


		#endregion


	}
}
